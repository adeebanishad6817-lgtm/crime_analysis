-- Generated from database/models.py by scripts/init_db.py --print-sql

CREATE TABLE users (
	user_id SERIAL NOT NULL, 
	username VARCHAR(50) NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	role VARCHAR(20) DEFAULT 'analyst' NOT NULL, 
	is_active BOOLEAN DEFAULT 'true' NOT NULL, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	last_login TIMESTAMP WITH TIME ZONE, 
	PRIMARY KEY (user_id), 
	CONSTRAINT ck_users_role CHECK (role IN ('admin', 'analyst')), 
	UNIQUE (username)
);


CREATE TABLE dataset_uploads (
	upload_id SERIAL NOT NULL, 
	uploaded_by INTEGER, 
	file_name VARCHAR(255) NOT NULL, 
	dataset_type VARCHAR(20) NOT NULL, 
	source_name VARCHAR(200), 
	source_note TEXT, 
	is_synthetic BOOLEAN DEFAULT 'false' NOT NULL, 
	rows_received INTEGER, 
	rows_saved INTEGER, 
	rows_excluded INTEGER, 
	column_mapping JSONB, 
	preprocessing_log JSONB, 
	status VARCHAR(20) DEFAULT 'processing' NOT NULL, 
	uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (upload_id), 
	CONSTRAINT ck_upload_type CHECK (dataset_type IN ('incidents', 'aggregate')), 
	CONSTRAINT ck_upload_status CHECK (status IN ('processing', 'completed', 'failed')), 
	FOREIGN KEY(uploaded_by) REFERENCES users (user_id) ON DELETE SET NULL
);


CREATE TABLE aggregate_crime_stats (
	stat_id SERIAL NOT NULL, 
	upload_id INTEGER NOT NULL, 
	region VARCHAR(100) DEFAULT 'Karnataka' NOT NULL, 
	report_month DATE NOT NULL, 
	sl_no INTEGER, 
	head_of_crime VARCHAR(60) NOT NULL, 
	major_head VARCHAR(150) NOT NULL, 
	major_head_raw TEXT, 
	legal_sections TEXT, 
	minor_head VARCHAR(200), 
	count_current_month INTEGER, 
	count_previous_month INTEGER, 
	count_same_month_prev_year INTEGER, 
	count_ytd INTEGER, 
	ytd_consistent BOOLEAN, 
	PRIMARY KEY (stat_id), 
	FOREIGN KEY(upload_id) REFERENCES dataset_uploads (upload_id) ON DELETE CASCADE
);

CREATE INDEX idx_agg_head ON aggregate_crime_stats (head_of_crime);
CREATE INDEX idx_agg_major ON aggregate_crime_stats (major_head);

CREATE TABLE analysis_history (
	analysis_id SERIAL NOT NULL, 
	user_id INTEGER, 
	upload_id INTEGER, 
	analysis_type VARCHAR(30) NOT NULL, 
	parameters JSONB, 
	filters JSONB, 
	result_summary JSONB, 
	created_at TIMESTAMP WITH TIME ZONE DEFAULT now() NOT NULL, 
	PRIMARY KEY (analysis_id), 
	CONSTRAINT ck_analysis_type CHECK (analysis_type IN ('dbscan', 'isolation_forest', 'trend', 'report')), 
	FOREIGN KEY(user_id) REFERENCES users (user_id) ON DELETE SET NULL, 
	FOREIGN KEY(upload_id) REFERENCES dataset_uploads (upload_id) ON DELETE CASCADE
);


CREATE TABLE crime_records (
	record_id BIGSERIAL NOT NULL, 
	upload_id INTEGER NOT NULL, 
	source_crime_id VARCHAR(50), 
	crime_type VARCHAR(100) NOT NULL, 
	crime_code VARCHAR(20), 
	crime_domain VARCHAR(60), 
	occurred_at TIMESTAMP WITHOUT TIME ZONE NOT NULL, 
	date_reported TIMESTAMP WITHOUT TIME ZONE, 
	latitude NUMERIC(9, 6), 
	longitude NUMERIC(9, 6), 
	coord_source VARCHAR(20), 
	location VARCHAR(150), 
	severity VARCHAR(10), 
	police_station VARCHAR(100), 
	weapon_used VARCHAR(60), 
	victim_age SMALLINT, 
	victim_gender VARCHAR(10), 
	age_group VARCHAR(10), 
	police_deployed SMALLINT, 
	case_closed BOOLEAN, 
	date_case_closed TIMESTAMP WITHOUT TIME ZONE, 
	resolution_days FLOAT, 
	year SMALLINT, 
	month SMALLINT, 
	day SMALLINT, 
	hour SMALLINT, 
	day_of_week SMALLINT, 
	is_weekend BOOLEAN, 
	time_period VARCHAR(12), 
	PRIMARY KEY (record_id), 
	CONSTRAINT uq_record_source_id UNIQUE (upload_id, source_crime_id), 
	CONSTRAINT ck_lat CHECK (latitude BETWEEN -90 AND 90), 
	CONSTRAINT ck_lon CHECK (longitude BETWEEN -180 AND 180), 
	CONSTRAINT ck_severity CHECK (severity IN ('High', 'Medium', 'Low')), 
	FOREIGN KEY(upload_id) REFERENCES dataset_uploads (upload_id) ON DELETE CASCADE
);

CREATE INDEX idx_crime_latlon ON crime_records (latitude, longitude);
CREATE INDEX idx_crime_location ON crime_records (location);
CREATE INDEX idx_crime_occurred ON crime_records (occurred_at);
CREATE INDEX idx_crime_station ON crime_records (police_station);
CREATE INDEX idx_crime_type ON crime_records (crime_type);
CREATE INDEX idx_crime_upload ON crime_records (upload_id);

CREATE TABLE hotspot_clusters (
	cluster_id SERIAL NOT NULL, 
	analysis_id INTEGER NOT NULL, 
	cluster_label INTEGER NOT NULL, 
	rank INTEGER NOT NULL, 
	incident_count INTEGER NOT NULL, 
	location_count INTEGER, 
	centroid_lat NUMERIC(9, 6) NOT NULL, 
	centroid_lon NUMERIC(9, 6) NOT NULL, 
	radius_km NUMERIC(10, 3), 
	member_locations TEXT, 
	top_crime_type VARCHAR(100), 
	high_severity_share FLOAT, 
	first_incident TIMESTAMP WITHOUT TIME ZONE, 
	last_incident TIMESTAMP WITHOUT TIME ZONE, 
	PRIMARY KEY (cluster_id), 
	CONSTRAINT uq_cluster_label UNIQUE (analysis_id, cluster_label), 
	FOREIGN KEY(analysis_id) REFERENCES analysis_history (analysis_id) ON DELETE CASCADE
);

