"""Database connection management.

A single SQLAlchemy engine is created per process (connection pooling is
handled by SQLAlchemy). Use ``get_connection()`` for reads and
``transaction()`` for writes so commits/rollbacks are always handled.
"""
from __future__ import annotations

from contextlib import contextmanager
from functools import lru_cache
from typing import Iterator

from sqlalchemy import create_engine, text
from sqlalchemy.engine import Connection, Engine
from sqlalchemy.exc import SQLAlchemyError

import config


@lru_cache(maxsize=4)
def get_engine(url: str | None = None) -> Engine:
    """Return a pooled engine for ``url`` (defaults to config.DATABASE_URL)."""
    url = url or config.DATABASE_URL
    kwargs: dict = {"future": True}
    if url.startswith("postgresql"):
        kwargs.update(pool_size=5, max_overflow=5, pool_pre_ping=True)
    return create_engine(url, **kwargs)


@contextmanager
def get_connection(url: str | None = None) -> Iterator[Connection]:
    """Read-only style connection (no explicit commit)."""
    with get_engine(url).connect() as conn:
        yield conn


@contextmanager
def transaction(url: str | None = None) -> Iterator[Connection]:
    """Connection inside a transaction: commits on success, rolls back on error."""
    with get_engine(url).begin() as conn:
        yield conn


def check_connection(url: str | None = None) -> tuple[bool, str]:
    """Return (ok, message). Used by the UI and tests to verify connectivity."""
    try:
        with get_connection(url) as conn:
            conn.execute(text("SELECT 1"))
        return True, "Database connection OK"
    except SQLAlchemyError as exc:  # pragma: no cover - message depends on env
        return False, f"Database connection failed: {exc.__class__.__name__}: {exc.orig if hasattr(exc, 'orig') else exc}"
