"""Table definitions and all database access functions.

Tables are declared once with SQLAlchemy Core (``metadata``). ``schema.sql``
is generated from these definitions (``python scripts/init_db.py --print-sql``)
so the documentation and the live database never drift apart.

Every query below uses SQLAlchemy expressions or bound parameters, so user
input is never concatenated into SQL (protection against SQL injection).
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Iterable

import numpy as np
import pandas as pd
from sqlalchemy import (
    JSON, BigInteger, Boolean, CheckConstraint, Column, Date, DateTime, Float,
    ForeignKey, Index, Integer, MetaData, Numeric, SmallInteger, String, Table,
    Text, UniqueConstraint, delete, func, insert, select, update,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.engine import Connection, Engine

JSONType = JSON().with_variant(JSONB(), "postgresql")
metadata = MetaData()

# ---------------------------------------------------------------------------
# Tables
# ---------------------------------------------------------------------------
users = Table(
    "users", metadata,
    Column("user_id", Integer, primary_key=True, autoincrement=True),
    Column("username", String(50), nullable=False, unique=True),
    Column("password_hash", String(255), nullable=False),
    Column("role", String(20), nullable=False, server_default="analyst"),
    Column("is_active", Boolean, nullable=False, server_default="true"),
    Column("created_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
    Column("last_login", DateTime(timezone=True)),
    CheckConstraint("role IN ('admin', 'analyst')", name="ck_users_role"),
)

dataset_uploads = Table(
    "dataset_uploads", metadata,
    Column("upload_id", Integer, primary_key=True, autoincrement=True),
    Column("uploaded_by", Integer, ForeignKey("users.user_id", ondelete="SET NULL")),
    Column("file_name", String(255), nullable=False),
    Column("dataset_type", String(20), nullable=False),
    Column("source_name", String(200)),
    Column("source_note", Text),
    Column("is_synthetic", Boolean, nullable=False, server_default="false"),
    Column("rows_received", Integer),
    Column("rows_saved", Integer),
    Column("rows_excluded", Integer),
    Column("column_mapping", JSONType),
    Column("preprocessing_log", JSONType),
    Column("status", String(20), nullable=False, server_default="processing"),
    Column("uploaded_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
    CheckConstraint("dataset_type IN ('incidents', 'aggregate')", name="ck_upload_type"),
    CheckConstraint("status IN ('processing', 'completed', 'failed')", name="ck_upload_status"),
)

crime_records = Table(
    "crime_records", metadata,
    Column("record_id", BigInteger().with_variant(Integer, "sqlite"), primary_key=True, autoincrement=True),
    Column("upload_id", Integer, ForeignKey("dataset_uploads.upload_id", ondelete="CASCADE"), nullable=False),
    Column("source_crime_id", String(50)),
    Column("crime_type", String(100), nullable=False),
    Column("crime_code", String(20)),
    Column("crime_domain", String(60)),
    Column("occurred_at", DateTime, nullable=False),
    Column("date_reported", DateTime),
    Column("latitude", Numeric(9, 6)),
    Column("longitude", Numeric(9, 6)),
    Column("coord_source", String(20)),          # 'record' or 'city_centroid'
    Column("location", String(150)),
    Column("severity", String(10)),
    Column("police_station", String(100)),
    Column("weapon_used", String(60)),
    Column("victim_age", SmallInteger),
    Column("victim_gender", String(10)),
    Column("age_group", String(10)),
    Column("police_deployed", SmallInteger),
    Column("case_closed", Boolean),
    Column("date_case_closed", DateTime),
    Column("resolution_days", Float),
    Column("year", SmallInteger),
    Column("month", SmallInteger),
    Column("day", SmallInteger),
    Column("hour", SmallInteger),
    Column("day_of_week", SmallInteger),          # 0 = Monday
    Column("is_weekend", Boolean),
    Column("time_period", String(12)),
    UniqueConstraint("upload_id", "source_crime_id", name="uq_record_source_id"),
    CheckConstraint("latitude BETWEEN -90 AND 90", name="ck_lat"),
    CheckConstraint("longitude BETWEEN -180 AND 180", name="ck_lon"),
    CheckConstraint("severity IN ('High', 'Medium', 'Low')", name="ck_severity"),
)
Index("idx_crime_occurred", crime_records.c.occurred_at)
Index("idx_crime_type", crime_records.c.crime_type)
Index("idx_crime_location", crime_records.c.location)
Index("idx_crime_station", crime_records.c.police_station)
Index("idx_crime_latlon", crime_records.c.latitude, crime_records.c.longitude)
Index("idx_crime_upload", crime_records.c.upload_id)

aggregate_crime_stats = Table(
    "aggregate_crime_stats", metadata,
    Column("stat_id", Integer, primary_key=True, autoincrement=True),
    Column("upload_id", Integer, ForeignKey("dataset_uploads.upload_id", ondelete="CASCADE"), nullable=False),
    Column("region", String(100), nullable=False, server_default="Karnataka"),
    Column("report_month", Date, nullable=False),
    Column("sl_no", Integer),
    Column("head_of_crime", String(60), nullable=False),
    Column("major_head", String(150), nullable=False),
    Column("major_head_raw", Text),
    Column("legal_sections", Text),
    Column("minor_head", String(200)),
    Column("count_current_month", Integer),
    Column("count_previous_month", Integer),
    Column("count_same_month_prev_year", Integer),
    Column("count_ytd", Integer),
    Column("ytd_consistent", Boolean),
)
Index("idx_agg_head", aggregate_crime_stats.c.head_of_crime)
Index("idx_agg_major", aggregate_crime_stats.c.major_head)

analysis_history = Table(
    "analysis_history", metadata,
    Column("analysis_id", Integer, primary_key=True, autoincrement=True),
    Column("user_id", Integer, ForeignKey("users.user_id", ondelete="SET NULL")),
    Column("upload_id", Integer, ForeignKey("dataset_uploads.upload_id", ondelete="CASCADE")),
    Column("analysis_type", String(30), nullable=False),
    Column("parameters", JSONType),
    Column("filters", JSONType),
    Column("result_summary", JSONType),
    Column("created_at", DateTime(timezone=True), nullable=False, server_default=func.now()),
    CheckConstraint("analysis_type IN ('dbscan', 'isolation_forest', 'trend', 'report')",
                    name="ck_analysis_type"),
)

hotspot_clusters = Table(
    "hotspot_clusters", metadata,
    Column("cluster_id", Integer, primary_key=True, autoincrement=True),
    Column("analysis_id", Integer, ForeignKey("analysis_history.analysis_id", ondelete="CASCADE"), nullable=False),
    Column("cluster_label", Integer, nullable=False),
    Column("rank", Integer, nullable=False),
    Column("incident_count", Integer, nullable=False),
    Column("location_count", Integer),
    Column("centroid_lat", Numeric(9, 6), nullable=False),
    Column("centroid_lon", Numeric(9, 6), nullable=False),
    Column("radius_km", Numeric(10, 3)),
    Column("member_locations", Text),
    Column("top_crime_type", String(100)),
    Column("high_severity_share", Float),
    Column("first_incident", DateTime),
    Column("last_incident", DateTime),
    UniqueConstraint("analysis_id", "cluster_label", name="uq_cluster_label"),
)

CRIME_RECORD_COLUMNS = [c.name for c in crime_records.columns if c.name not in ("record_id",)]
AGGREGATE_COLUMNS = [c.name for c in aggregate_crime_stats.columns if c.name != "stat_id"]


def create_all(engine: Engine) -> None:
    """Create every table and index (idempotent)."""
    metadata.create_all(engine)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _clean_value(value: Any) -> Any:
    """Convert pandas/numpy scalars to plain Python types the DB driver accepts."""
    if value is None:
        return None
    if isinstance(value, float) and np.isnan(value):
        return None
    if value is pd.NaT:
        return None
    if isinstance(value, pd.Timestamp):
        return value.to_pydatetime()
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, np.floating):
        return None if np.isnan(value) else float(value)
    if isinstance(value, np.bool_):
        return bool(value)
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    return value


def _records(df: pd.DataFrame, columns: Iterable[str]) -> list[dict]:
    cols = [c for c in columns if c in df.columns]
    return [{c: _clean_value(v) for c, v in zip(cols, row)} for row in df[cols].itertuples(index=False, name=None)]


def to_jsonable(obj: Any) -> Any:
    """Recursively convert numpy/pandas objects so they can be stored as JSON."""
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_jsonable(v) for v in obj]
    if isinstance(obj, (pd.Timestamp, datetime)):
        return obj.isoformat()
    return _clean_value(obj)


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------
def create_user(conn: Connection, username: str, password_hash: str, role: str = "analyst") -> int:
    result = conn.execute(
        insert(users).values(username=username, password_hash=password_hash, role=role)
        .returning(users.c.user_id)
    )
    return int(result.scalar_one())


def get_user_by_username(conn: Connection, username: str) -> dict | None:
    row = conn.execute(select(users).where(users.c.username == username)).mappings().first()
    return dict(row) if row else None


def list_users(conn: Connection) -> pd.DataFrame:
    stmt = select(users.c.user_id, users.c.username, users.c.role, users.c.is_active,
                  users.c.created_at, users.c.last_login).order_by(users.c.user_id)
    return pd.DataFrame(conn.execute(stmt).mappings().all())


def update_last_login(conn: Connection, user_id: int) -> None:
    conn.execute(update(users).where(users.c.user_id == user_id)
                 .values(last_login=datetime.now(timezone.utc)))


def set_user_active(conn: Connection, user_id: int, active: bool) -> None:
    conn.execute(update(users).where(users.c.user_id == user_id).values(is_active=active))


# ---------------------------------------------------------------------------
# Uploads
# ---------------------------------------------------------------------------
def create_upload(conn: Connection, *, file_name: str, dataset_type: str, uploaded_by: int | None,
                  source_name: str | None = None, source_note: str | None = None,
                  is_synthetic: bool = False, column_mapping: dict | None = None,
                  rows_received: int | None = None) -> int:
    result = conn.execute(
        insert(dataset_uploads).values(
            file_name=file_name, dataset_type=dataset_type, uploaded_by=uploaded_by,
            source_name=source_name, source_note=source_note, is_synthetic=is_synthetic,
            column_mapping=to_jsonable(column_mapping), rows_received=rows_received,
        ).returning(dataset_uploads.c.upload_id)
    )
    return int(result.scalar_one())


def finalize_upload(conn: Connection, upload_id: int, *, status: str, rows_saved: int,
                    rows_excluded: int, preprocessing_log: list | dict | None) -> None:
    conn.execute(
        update(dataset_uploads).where(dataset_uploads.c.upload_id == upload_id).values(
            status=status, rows_saved=rows_saved, rows_excluded=rows_excluded,
            preprocessing_log=to_jsonable(preprocessing_log),
        )
    )


def list_uploads(conn: Connection, dataset_type: str | None = None,
                 completed_only: bool = False) -> pd.DataFrame:
    stmt = select(dataset_uploads).order_by(dataset_uploads.c.upload_id.desc())
    if dataset_type:
        stmt = stmt.where(dataset_uploads.c.dataset_type == dataset_type)
    if completed_only:
        stmt = stmt.where(dataset_uploads.c.status == "completed")
    return pd.DataFrame(conn.execute(stmt).mappings().all())


def get_upload(conn: Connection, upload_id: int) -> dict | None:
    row = conn.execute(select(dataset_uploads).where(dataset_uploads.c.upload_id == upload_id)).mappings().first()
    return dict(row) if row else None


def delete_upload(conn: Connection, upload_id: int) -> None:
    """Delete an upload; its records, stats and analyses cascade."""
    # Explicit child deletes keep SQLite (tests) consistent with PostgreSQL cascades.
    analysis_ids = select(analysis_history.c.analysis_id).where(analysis_history.c.upload_id == upload_id)
    conn.execute(delete(hotspot_clusters).where(hotspot_clusters.c.analysis_id.in_(analysis_ids)))
    conn.execute(delete(analysis_history).where(analysis_history.c.upload_id == upload_id))
    conn.execute(delete(crime_records).where(crime_records.c.upload_id == upload_id))
    conn.execute(delete(aggregate_crime_stats).where(aggregate_crime_stats.c.upload_id == upload_id))
    conn.execute(delete(dataset_uploads).where(dataset_uploads.c.upload_id == upload_id))


# ---------------------------------------------------------------------------
# Crime records
# ---------------------------------------------------------------------------
def insert_crime_records(conn: Connection, upload_id: int, df: pd.DataFrame, chunk_size: int = 5000) -> int:
    """Bulk insert cleaned incidents (parameterised executemany in chunks)."""
    data = df.copy()
    data["upload_id"] = upload_id
    rows = _records(data, CRIME_RECORD_COLUMNS)
    for start in range(0, len(rows), chunk_size):
        conn.execute(insert(crime_records), rows[start:start + chunk_size])
    return len(rows)


def load_crime_records(conn: Connection, upload_id: int) -> pd.DataFrame:
    stmt = select(crime_records).where(crime_records.c.upload_id == upload_id)
    df = pd.read_sql(stmt, conn)
    for col in ("latitude", "longitude"):
        if col in df:
            df[col] = pd.to_numeric(df[col], errors="coerce").astype(float)
    for col in ("occurred_at", "date_reported", "date_case_closed"):
        if col in df:
            df[col] = pd.to_datetime(df[col], errors="coerce")
    return df


# ---------------------------------------------------------------------------
# Aggregate statistics
# ---------------------------------------------------------------------------
def insert_aggregate_stats(conn: Connection, upload_id: int, df: pd.DataFrame) -> int:
    data = df.copy()
    data["upload_id"] = upload_id
    rows = _records(data, AGGREGATE_COLUMNS)
    if rows:
        conn.execute(insert(aggregate_crime_stats), rows)
    return len(rows)


def load_aggregate_stats(conn: Connection, upload_id: int) -> pd.DataFrame:
    stmt = (select(aggregate_crime_stats).where(aggregate_crime_stats.c.upload_id == upload_id)
            .order_by(aggregate_crime_stats.c.sl_no))
    return pd.read_sql(stmt, conn)


# ---------------------------------------------------------------------------
# Analysis history and hotspots
# ---------------------------------------------------------------------------
def save_analysis(conn: Connection, *, analysis_type: str, upload_id: int | None,
                  user_id: int | None, parameters: dict, filters: dict | None,
                  result_summary: dict) -> int:
    result = conn.execute(
        insert(analysis_history).values(
            analysis_type=analysis_type, upload_id=upload_id, user_id=user_id,
            parameters=to_jsonable(parameters), filters=to_jsonable(filters),
            result_summary=to_jsonable(result_summary),
        ).returning(analysis_history.c.analysis_id)
    )
    return int(result.scalar_one())


def save_hotspot_clusters(conn: Connection, analysis_id: int, clusters: pd.DataFrame) -> int:
    if clusters.empty:
        return 0
    data = clusters.copy()
    data["analysis_id"] = analysis_id
    cols = [c.name for c in hotspot_clusters.columns if c.name != "cluster_id"]
    rows = _records(data, cols)
    conn.execute(insert(hotspot_clusters), rows)
    return len(rows)


def list_analysis_history(conn: Connection, limit: int = 50) -> pd.DataFrame:
    stmt = (select(analysis_history.c.analysis_id, analysis_history.c.analysis_type,
                   analysis_history.c.upload_id, users.c.username,
                   analysis_history.c.parameters, analysis_history.c.result_summary,
                   analysis_history.c.created_at)
            .select_from(analysis_history.outerjoin(users, analysis_history.c.user_id == users.c.user_id))
            .order_by(analysis_history.c.analysis_id.desc()).limit(limit))
    return pd.DataFrame(conn.execute(stmt).mappings().all())


def load_hotspot_clusters(conn: Connection, analysis_id: int) -> pd.DataFrame:
    stmt = (select(hotspot_clusters).where(hotspot_clusters.c.analysis_id == analysis_id)
            .order_by(hotspot_clusters.c.rank))
    return pd.read_sql(stmt, conn)
