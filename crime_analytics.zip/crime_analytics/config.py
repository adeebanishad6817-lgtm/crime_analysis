"""Central configuration, loaded from environment variables / a .env file.

Every other module imports settings from here so that nothing (database
password, admin bootstrap credentials, limits) is hard-coded elsewhere.
"""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

# --- Database -------------------------------------------------------------
DATABASE_URL: str = os.getenv(
    "DATABASE_URL",
    "postgresql+psycopg2://crime_admin:crime_pass@localhost:5432/crime_analytics",
)

# --- First administrator (created by scripts/init_db.py) ------------------
ADMIN_USERNAME: str = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD: str = os.getenv("ADMIN_PASSWORD", "ChangeMe@123")

# --- Paths ------------------------------------------------------------------
DATA_DIR = BASE_DIR / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
REFERENCE_DIR = DATA_DIR / "reference"
CITY_COORDS_FILE = REFERENCE_DIR / "india_city_coordinates.csv"
ASSETS_DIR = BASE_DIR / "assets"

# --- Upload rules -----------------------------------------------------------
MAX_UPLOAD_MB: int = int(os.getenv("MAX_UPLOAD_MB", "200"))
ALLOWED_EXTENSIONS = {".csv", ".xlsx", ".xls"}
EXCLUSION_WARNING_SHARE = 0.10  # warn if preprocessing would drop >10% of rows

# --- Analysis defaults ------------------------------------------------------
EARTH_RADIUS_KM = 6371.0088
DBSCAN_MAX_POINTS = 50_000          # unique locations passed to DBSCAN
DBSCAN_DEFAULT_EPS_KM = 60.0
DBSCAN_DEFAULT_MIN_SAMPLES = 2000   # weighted: incidents, not locations
ISOLATION_DEFAULT_CONTAMINATION = 0.05
RANDOM_STATE = 42

# --- Session ------------------------------------------------------------------
SESSION_TIMEOUT_MINUTES: int = int(os.getenv("SESSION_TIMEOUT_MINUTES", "60"))

APP_TITLE = "Crime Pattern Analytics & Hotspot Detection"
