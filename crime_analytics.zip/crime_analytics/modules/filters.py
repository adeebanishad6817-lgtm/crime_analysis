"""Global dashboard filters (sidebar) and the pure function that applies them."""
from __future__ import annotations

from datetime import date

import pandas as pd

from modules.crime_analysis import MONTH_NAMES, WEEKDAYS

FILTER_KEYS = ["date_range", "years", "months", "crime_types", "locations", "severities", "stations", "weekdays"]


def empty_filters() -> dict:
    return {k: None for k in FILTER_KEYS}


def apply_filters(df: pd.DataFrame, f: dict | None) -> pd.DataFrame:
    """Return the rows matching every active filter. ``None`` / empty = no filter."""
    if df.empty or not f:
        return df
    mask = pd.Series(True, index=df.index)
    dr = f.get("date_range")
    if dr and len(dr) == 2 and dr[0] and dr[1]:
        start, end = pd.Timestamp(dr[0]), pd.Timestamp(dr[1]) + pd.Timedelta(days=1)
        mask &= (df["occurred_at"] >= start) & (df["occurred_at"] < end)
    for key, col in (("years", "year"), ("months", "month"), ("crime_types", "crime_type"),
                     ("locations", "location"), ("severities", "severity"), ("stations", "police_station"),
                     ("weekdays", "day_of_week")):
        values = f.get(key)
        if values and col in df:
            mask &= df[col].isin(values)
    return df[mask]


def describe_filters(f: dict | None) -> str:
    if not f:
        return "No filters (all records)."
    parts = []
    dr = f.get("date_range")
    if dr and len(dr) == 2:
        parts.append(f"Dates {dr[0]} to {dr[1]}")
    labels = {"years": "Years", "crime_types": "Crime types", "locations": "Locations",
              "severities": "Severity", "stations": "Police stations"}
    for key, label in labels.items():
        if f.get(key):
            parts.append(f"{label}: {', '.join(map(str, f[key]))}")
    if f.get("months"):
        parts.append("Months: " + ", ".join(MONTH_NAMES[m - 1] for m in f["months"]))
    if f.get("weekdays"):
        parts.append("Weekdays: " + ", ".join(WEEKDAYS[d] for d in f["weekdays"]))
    return "; ".join(parts) if parts else "No filters (all records)."


def render_filters(df: pd.DataFrame, dataset_key: str) -> dict:
    """Draw the sidebar filters and return the active filter dict."""
    import streamlit as st

    if st.session_state.get("filters_dataset") != dataset_key:
        for k in list(st.session_state.keys()):
            if str(k).startswith("flt_"):
                del st.session_state[k]
        st.session_state["filters_dataset"] = dataset_key

    f = empty_filters()
    if df.empty:
        return f
    with st.sidebar.expander("Filters", expanded=True):
        if st.button("Reset filters", width="stretch"):
            for k in list(st.session_state.keys()):
                if str(k).startswith("flt_"):
                    del st.session_state[k]
            st.rerun()
        lo: date = df["occurred_at"].min().date()
        hi: date = df["occurred_at"].max().date()
        dr = st.date_input("Date range", value=(lo, hi), min_value=lo, max_value=hi, key="flt_dates")
        if isinstance(dr, (tuple, list)) and len(dr) == 2 and (dr[0] != lo or dr[1] != hi):
            f["date_range"] = (dr[0], dr[1])
        f["years"] = st.multiselect("Year", sorted(df["year"].dropna().unique().astype(int).tolist()), key="flt_years") or None
        f["months"] = st.multiselect("Month", list(range(1, 13)), format_func=lambda m: MONTH_NAMES[m - 1],
                                     key="flt_months") or None
        f["crime_types"] = st.multiselect("Crime category", sorted(df["crime_type"].dropna().unique()),
                                          key="flt_types") or None
        if "location" in df and df["location"].notna().any():
            f["locations"] = st.multiselect("Location", sorted(df["location"].dropna().unique()), key="flt_locs") or None
        if "severity" in df:
            f["severities"] = st.multiselect("Severity", ["High", "Medium", "Low"], key="flt_sev") or None
        if "police_station" in df and df["police_station"].notna().any():
            f["stations"] = st.multiselect("Police station", sorted(df["police_station"].dropna().unique()),
                                           key="flt_station") or None
        f["weekdays"] = st.multiselect("Day of week", list(range(7)), format_func=lambda d: WEEKDAYS[d],
                                       key="flt_weekdays") or None
    return f
