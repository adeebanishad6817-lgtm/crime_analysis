"""Authentication: bcrypt password hashing, login, roles and session timeout.

Two roles exist: ``admin`` (manage data and users) and ``analyst``
(view dashboards, run analyses, download reports).
"""
from __future__ import annotations

import re
import time
from datetime import datetime, timedelta

import bcrypt

import config
from database import models
from database.connection import get_connection, transaction

USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,50}$")
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_SECONDS = 60


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt(rounds=12)).decode("utf-8")


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8"))
    except (ValueError, TypeError):
        return False


def validate_username(username: str) -> str | None:
    if not USERNAME_RE.match(username or ""):
        return "Username must be 3-50 characters: letters, digits, '.', '_' or '-'."
    return None


def validate_password_strength(password: str) -> str | None:
    if len(password or "") < 8:
        return "Password must be at least 8 characters."
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        return "Password must contain at least one letter and one digit."
    return None


def authenticate(username: str, password: str, url: str | None = None) -> dict | None:
    """Return the user (without hash) if credentials are valid and the account is active."""
    if validate_username(username):
        return None
    with get_connection(url) as conn:
        user = models.get_user_by_username(conn, username)
    if not user or not user.get("is_active") or not verify_password(password, user["password_hash"]):
        return None
    with transaction(url) as conn:
        models.update_last_login(conn, user["user_id"])
    user.pop("password_hash", None)
    return user


def register_user(username: str, password: str, role: str = "analyst", url: str | None = None) -> int:
    for msg in (validate_username(username), validate_password_strength(password)):
        if msg:
            raise ValueError(msg)
    if role not in ("admin", "analyst"):
        raise ValueError("Role must be 'admin' or 'analyst'.")
    with transaction(url) as conn:
        if models.get_user_by_username(conn, username):
            raise ValueError(f"User '{username}' already exists.")
        return models.create_user(conn, username, hash_password(password), role)


# ---------------------------------------------------------------------------
# Streamlit session helpers
# ---------------------------------------------------------------------------
def _st():
    import streamlit as st  # imported lazily so pure functions are testable without Streamlit
    return st


def current_user() -> dict | None:
    st = _st()
    user = st.session_state.get("user")
    if not user:
        return None
    last = st.session_state.get("last_activity")
    if last and datetime.now() - last > timedelta(minutes=config.SESSION_TIMEOUT_MINUTES):
        logout(message="Your session expired. Please log in again.")
        return None
    st.session_state["last_activity"] = datetime.now()
    return user


def is_admin() -> bool:
    user = current_user()
    return bool(user and user.get("role") == "admin")


def logout(message: str | None = None) -> None:
    st = _st()
    for key in ("user", "last_activity"):
        st.session_state.pop(key, None)
    if message:
        st.session_state["auth_message"] = message


def login_form() -> None:
    st = _st()
    st.markdown("<div class='login-title'>Crime Pattern Analytics</div>", unsafe_allow_html=True)
    st.caption("Sign in to continue. Accounts are created by an administrator.")
    if msg := st.session_state.pop("auth_message", None):
        st.info(msg)
    locked_until = st.session_state.get("locked_until", 0)
    with st.form("login", clear_on_submit=False):
        username = st.text_input("Username", max_chars=50)
        password = st.text_input("Password", type="password", max_chars=128)
        submitted = st.form_submit_button("Sign in", type="primary", width="stretch")
    if not submitted:
        return
    if time.time() < locked_until:
        st.error(f"Too many failed attempts. Try again in {int(locked_until - time.time())} s.")
        return
    try:
        user = authenticate(username.strip(), password)
    except Exception as exc:  # database down etc.
        st.error(f"Could not reach the database: {exc.__class__.__name__}. Check DATABASE_URL in .env.")
        return
    if user is None:
        fails = st.session_state.get("failed_logins", 0) + 1
        st.session_state["failed_logins"] = fails
        if fails >= MAX_FAILED_ATTEMPTS:
            st.session_state["locked_until"] = time.time() + LOCKOUT_SECONDS
            st.session_state["failed_logins"] = 0
        st.error("Invalid username or password.")
        return
    st.session_state["user"] = user
    st.session_state["last_activity"] = datetime.now()
    st.session_state["failed_logins"] = 0
    st.rerun()
