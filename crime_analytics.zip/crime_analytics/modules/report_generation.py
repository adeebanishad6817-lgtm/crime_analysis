"""CSV, PNG and PDF exports.

Static chart images are drawn with Matplotlib/Seaborn so exports work on any
machine (no headless browser needed). Interactive Plotly charts in the app
also have their own "download as PNG" camera button.
"""
from __future__ import annotations

import io
from datetime import datetime

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402
import seaborn as sns  # noqa: E402
from reportlab.lib import colors  # noqa: E402
from reportlab.lib.pagesizes import A4  # noqa: E402
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet  # noqa: E402
from reportlab.lib.units import cm  # noqa: E402
from reportlab.platypus import (Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer,  # noqa: E402
                                Table, TableStyle)

from modules import crime_analysis as ca  # noqa: E402

BLUE = "#2a78d6"
SEV = {"High": "#184f95", "Medium": "#3987e5", "Low": "#9ec5f4"}
EXPORT_DROP = ["record_id", "upload_id"]


# ---------------------------------------------------------------------------
# CSV
# ---------------------------------------------------------------------------
def dataframe_to_csv_bytes(df: pd.DataFrame) -> bytes:
    return df.drop(columns=[c for c in EXPORT_DROP if c in df.columns]).to_csv(index=False).encode("utf-8")


def hotspot_summary_csv(clusters: pd.DataFrame, params: dict) -> bytes:
    out = clusters.copy()
    out.insert(0, "eps_km", params.get("eps_km"))
    out.insert(1, "min_samples", params.get("min_samples"))
    return out.to_csv(index=False).encode("utf-8")


# ---------------------------------------------------------------------------
# Static charts (PNG bytes)
# ---------------------------------------------------------------------------
def _style(ax, title: str, xlabel: str, ylabel: str) -> None:
    ax.set_title(title, loc="left", fontsize=12, fontweight="bold")
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.spines[["top", "right"]].set_visible(False)
    ax.grid(axis="y", alpha=0.25)


def _to_png(fig) -> bytes:
    buf = io.BytesIO()
    fig.tight_layout()
    fig.savefig(buf, format="png", dpi=150)
    plt.close(fig)
    return buf.getvalue()


def _empty_png(title: str) -> bytes:
    fig, ax = plt.subplots(figsize=(8, 3))
    ax.text(0.5, 0.5, "No data for the current filters", ha="center", va="center", color="grey")
    ax.set_axis_off()
    ax.set_title(title, loc="left")
    return _to_png(fig)


def png_monthly_trend(df: pd.DataFrame) -> bytes:
    title = "Monthly incidents"
    m = ca.monthly_counts(df)
    if m.empty:
        return _empty_png(title)
    fig, ax = plt.subplots(figsize=(9, 3.4))
    ax.plot(m["month"], m["incidents"], color=BLUE, linewidth=2)
    ax.set_ylim(bottom=0)
    _style(ax, title, "Month", "Incidents")
    return _to_png(fig)


def png_category_bar(df: pd.DataFrame, top: int = 15) -> bytes:
    title = f"Top {top} crime categories"
    c = ca.counts_by(df, "crime_type", top)
    if c.empty:
        return _empty_png(title)
    fig, ax = plt.subplots(figsize=(9, 0.32 * len(c) + 1.2))
    c = c.iloc[::-1]
    ax.barh(c["crime_type"], c["incidents"], color=BLUE)
    _style(ax, title, "Incidents", "Crime category")
    ax.grid(axis="x", alpha=0.25)
    ax.grid(axis="y", visible=False)
    return _to_png(fig)


def png_severity(df: pd.DataFrame) -> bytes:
    title = "Severity distribution"
    s = ca.counts_by(df, "severity")
    if s.empty:
        return _empty_png(title)
    s = s.set_index("severity").reindex([x for x in ("High", "Medium", "Low") if x in set(s["severity"])])
    fig, ax = plt.subplots(figsize=(4.5, 3.4))
    ax.pie(s["incidents"], labels=[f"{i} ({v:,})" for i, v in s["incidents"].items()],
           colors=[SEV[i] for i in s.index], wedgeprops={"width": 0.45, "edgecolor": "white"}, startangle=90)
    ax.set_title(title, loc="left", fontsize=12, fontweight="bold")
    return _to_png(fig)


def png_weekday_hour(df: pd.DataFrame) -> bytes:
    title = "Incidents by weekday and hour"
    mat = ca.weekday_hour_matrix(df)
    if mat.empty:
        return _empty_png(title)
    fig, ax = plt.subplots(figsize=(10, 3.6))
    sns.heatmap(mat, cmap="Blues", ax=ax, cbar_kws={"label": "Incidents"}, linewidths=0.5, linecolor="white")
    ax.set_title(title, loc="left", fontsize=12, fontweight="bold")
    ax.set_xlabel("Hour of day")
    ax.set_ylabel("Weekday")
    return _to_png(fig)


def png_location_bar(df: pd.DataFrame, top: int = 15) -> bytes:
    title = f"Top {top} locations by incidents"
    c = ca.counts_by(df, "location", top)
    if c.empty:
        return _empty_png(title)
    c = c.iloc[::-1]
    fig, ax = plt.subplots(figsize=(9, 0.32 * len(c) + 1.2))
    ax.barh(c["location"], c["incidents"], color=BLUE)
    _style(ax, title, "Incidents", "Location")
    ax.grid(axis="x", alpha=0.25)
    ax.grid(axis="y", visible=False)
    return _to_png(fig)


def png_hotspots(clusters: pd.DataFrame) -> bytes:
    title = "DBSCAN hotspots by incident count"
    if clusters is None or clusters.empty:
        return _empty_png(title)
    c = clusters.head(15).iloc[::-1]
    fig, ax = plt.subplots(figsize=(9, 0.4 * len(c) + 1.2))
    labels = [f"#{r} {str(m)[:40]}" for r, m in zip(c["rank"], c["member_locations"])]
    ax.barh(labels, c["incident_count"], color=BLUE)
    _style(ax, title, "Incidents", "Hotspot")
    ax.grid(axis="y", visible=False)
    return _to_png(fig)


CHART_BUILDERS = {
    "Monthly trend": png_monthly_trend,
    "Crime categories": png_category_bar,
    "Severity": png_severity,
    "Weekday x hour heatmap": png_weekday_hour,
    "Locations": png_location_bar,
}


# ---------------------------------------------------------------------------
# PDF
# ---------------------------------------------------------------------------
def _styles():
    ss = getSampleStyleSheet()
    ss.add(ParagraphStyle("Small", parent=ss["BodyText"], fontSize=8.5, leading=11))
    ss.add(ParagraphStyle("Cell", parent=ss["BodyText"], fontSize=8, leading=10))
    return ss


def _table(rows: list[list], col_widths: list[float] | None = None, header: bool = True) -> Table:
    ss = _styles()
    data = [[Paragraph(str(c), ss["Cell"]) for c in r] for r in rows]
    t = Table(data, colWidths=col_widths, repeatRows=1 if header else 0)
    style = [("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#cccccc")),
             ("VALIGN", (0, 0), (-1, -1), "TOP")]
    if header:
        style.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e7f1fb")))
    t.setStyle(TableStyle(style))
    return t


def _img(png: bytes, width_cm: float = 17) -> Image:
    img = Image(io.BytesIO(png))
    ratio = img.imageHeight / img.imageWidth
    img.drawWidth = width_cm * cm
    img.drawHeight = width_cm * cm * ratio
    return img


def _footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8)
    canvas.setFillColor(colors.grey)
    canvas.drawString(2 * cm, 1.2 * cm, "Crime Pattern Analytics & Hotspot Detection - generated report")
    canvas.drawRightString(A4[0] - 2 * cm, 1.2 * cm, f"Page {doc.page}")
    canvas.restoreState()


def build_incident_report(upload: dict, df: pd.DataFrame, filters_text: str, observations: list[str],
                          dbscan=None, anomalies=None, preprocessing_log: list | None = None,
                          generated_by: str | None = None) -> bytes:
    ss = _styles()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm,
                            topMargin=1.8 * cm, bottomMargin=2 * cm, title="Crime analysis report")
    s: list = []
    now = datetime.now()
    s.append(Paragraph("Crime Pattern Analysis Report", ss["Title"]))
    s.append(Paragraph(f"Generated {now:%d %b %Y %H:%M}" + (f" by {generated_by}" if generated_by else ""), ss["Small"]))
    s.append(Spacer(1, 8))
    if upload.get("is_synthetic"):
        s.append(Paragraph("<b>Note:</b> this dataset is flagged as synthetic / simulated. Figures describe the "
                           "dataset only and are not real-world crime statistics. "
                           + (upload.get("source_note") or ""), ss["BodyText"]))
        s.append(Spacer(1, 6))

    s.append(Paragraph("1. Dataset information", ss["Heading2"]))
    k = ca.kpis(df)
    info = [["Item", "Value"],
            ["File", upload.get("file_name")],
            ["Source", upload.get("source_name") or "-"],
            ["Upload ID / date", f"#{upload.get('upload_id')} on {pd.Timestamp(upload.get('uploaded_at')):%d %b %Y}"
             if upload.get("uploaded_at") is not None else f"#{upload.get('upload_id')}"],
            ["Rows received / saved / excluded",
             f"{upload.get('rows_received') or 0:,} / {upload.get('rows_saved') or 0:,} / {upload.get('rows_excluded') or 0:,}"],
            ["Filters applied", filters_text],
            ["Records in this report", f"{k.get('total', 0):,}"]]
    if k.get("total"):
        info.append(["Period covered", f"{k['first_date']:%d %b %Y} to {k['last_date']:%d %b %Y}"])
    info.append(["Analysis date", f"{now:%d %b %Y}"])
    s.append(_table(info, [5 * cm, 12 * cm]))

    s.append(Paragraph("2. Key indicators", ss["Heading2"]))
    if k.get("total"):
        rows = [["Indicator", "Value"],
                ["Total incidents", f"{k['total']:,}"],
                ["Most common category", f"{k['top_crime_type']} ({k['top_crime_type_count']:,})"],
                ["Crime categories", str(k["n_crime_types"])]]
        if "top_location" in k:
            rows.append(["Highest incident-count location", f"{k['top_location']} ({k['top_location_count']:,})"])
        if k.get("high_severity_pct") is not None:
            rows.append(["High-severity share", f"{k['high_severity_pct']:.1f}%"])
        if "closure_rate_pct" in k:
            rows.append(["Cases closed", f"{k['closure_rate_pct']:.1f}%"])
        if dbscan is not None:
            rows.append(["DBSCAN hotspots", f"{dbscan.n_clusters} (eps {dbscan.params['eps_km']:g} km, "
                                            f"min_samples {dbscan.params['min_samples']})"])
        s.append(_table(rows, [7 * cm, 10 * cm]))
    else:
        s.append(Paragraph("No records match the filters.", ss["BodyText"]))

    s.append(Paragraph("3. Automatic observations", ss["Heading2"]))
    for o in observations:
        s.append(Paragraph(f"&bull; {o}", ss["BodyText"]))

    s.append(PageBreak())
    s.append(Paragraph("4. Charts", ss["Heading2"]))
    s.append(_img(png_monthly_trend(df)))
    s.append(_img(png_category_bar(df)))
    s.append(_img(png_severity(df), 9))
    s.append(_img(png_weekday_hour(df)))
    if "location" in df:
        s.append(_img(png_location_bar(df)))

    if dbscan is not None:
        s.append(PageBreak())
        s.append(Paragraph("5. Hotspot summary (DBSCAN)", ss["Heading2"]))
        s.append(Paragraph(
            f"Parameters: eps = {dbscan.params['eps_km']:g} km, min_samples = {dbscan.params['min_samples']} "
            f"(weighted by incidents), haversine metric. Clusters: {dbscan.n_clusters}; incidents in clusters: "
            f"{dbscan.clustered_incidents:,}; noise incidents: {dbscan.noise_incidents:,}.", ss["BodyText"]))
        if not dbscan.clusters.empty:
            rows = [["Rank", "Locations", "Incidents", "Radius (km)", "Top crime", "High sev."]]
            for r in dbscan.clusters.head(20).itertuples():
                rows.append([r.rank, r.member_locations, f"{r.incident_count:,}", f"{float(r.radius_km):.1f}",
                             r.top_crime_type, f"{(r.high_severity_share or 0) * 100:.0f}%"])
            s.append(_table(rows, [1.2 * cm, 6.3 * cm, 2 * cm, 2 * cm, 3.5 * cm, 2 * cm]))
            s.append(Spacer(1, 6))
            s.append(_img(png_hotspots(dbscan.clusters)))
        for n in dbscan.notes:
            s.append(Paragraph(f"Note: {n}", ss["Small"]))

    if anomalies is not None and not anomalies.table.empty:
        s.append(Paragraph("6. Unusual periods (Isolation Forest on aggregated counts)", ss["Heading2"]))
        flagged = anomalies.table[anomalies.table["is_anomaly"]].sort_values("score", ascending=False).head(20)
        if flagged.empty:
            s.append(Paragraph("No unusual periods flagged.", ss["BodyText"]))
        else:
            gcol = anomalies.params.get("group_col")
            head = ["Period start"] + ([gcol] if gcol else []) + ["Incidents", "Recent avg", "Direction"]
            rows = [head]
            for r in flagged.to_dict("records"):
                rows.append([f"{pd.Timestamp(r['period']):%d %b %Y}"] + ([r[gcol]] if gcol else [])
                            + [f"{r['count']:.0f}", f"{r['expected']:.1f}", r.get("direction", "")])
            s.append(_table(rows))
        s.append(Paragraph("A flagged period means aggregate activity differed from most other periods. It is not "
                           "evidence about any individual record or person.", ss["Small"]))

    if preprocessing_log:
        s.append(Paragraph("7. Preprocessing log", ss["Heading2"]))
        rows = [["Step", "Before", "After", "Changed", "Detail"]]
        for e in preprocessing_log:
            rows.append([e.get("step"), e.get("rows_before"), e.get("rows_after"), e.get("rows_changed", ""),
                         str(e.get("detail", ""))[:400]])
        s.append(_table(rows, [3.5 * cm, 1.5 * cm, 1.5 * cm, 1.5 * cm, 9 * cm]))

    s.append(Paragraph("Method notes and limitations", ss["Heading2"]))
    for line in (
        "Trends describe observed history (linear regression and Mann-Kendall test); no forecast is made.",
        "Hotspots are density clusters of recorded incidents; they reflect where incidents were recorded, "
        "which can be affected by reporting and policing patterns.",
        "Where the dataset has no coordinates, locations use approximate city-centre coordinates, so maps and "
        "clusters are at city level.",
        "Severity, when not present in the source, is derived from the crime category with a documented rule.",
    ):
        s.append(Paragraph(f"&bull; {line}", ss["Small"]))
    doc.build(s, onFirstPage=_footer, onLaterPages=_footer)
    return buf.getvalue()


def build_karnataka_report(upload: dict, stats: pd.DataFrame, summary: pd.DataFrame,
                           rises: pd.DataFrame, falls: pd.DataFrame, log: list | None) -> bytes:
    ss = _styles()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm,
                            topMargin=1.8 * cm, bottomMargin=2 * cm, title="Karnataka crime review summary")
    month = pd.Timestamp(stats["report_month"].iloc[0]) if not stats.empty else None
    s: list = [Paragraph("Karnataka Crime Review - Summary", ss["Title"]),
               Paragraph(f"Report month: {month:%B %Y}" if month is not None else "", ss["BodyText"]),
               Paragraph(f"Source file: {upload.get('file_name')} (upload #{upload.get('upload_id')}). "
                         f"Generated {datetime.now():%d %b %Y %H:%M}.", ss["Small"]),
               Spacer(1, 8),
               Paragraph("Totals by head of crime", ss["Heading2"])]
    rows = [["Head of crime", "Current month", "Previous month", "Same month last year", "YTD", "MoM %", "YoY %"]]
    for r in summary.itertuples():
        rows.append([r.head_of_crime, f"{r.count_current_month:,}", f"{r.count_previous_month:,}",
                     f"{r.count_same_month_prev_year:,}", f"{r.count_ytd:,}",
                     f"{r.mom_pct:+.1f}%" if pd.notna(r.mom_pct) else "-",
                     f"{r.yoy_pct:+.1f}%" if pd.notna(r.yoy_pct) else "-"])
    s.append(_table(rows))
    s.append(Paragraph("Heads are reported separately because Crimes Against Women can overlap with IPC "
                       "categories; they are not added into one total.", ss["Small"]))
    for title, data in (("Largest year-on-year increases (major heads)", rises),
                        ("Largest year-on-year decreases (major heads)", falls)):
        s.append(Paragraph(title, ss["Heading2"]))
        rows = [["Major head", "Head", "Current", "Same month last year", "Change"]]
        for r in data.itertuples():
            rows.append([r.major_head, r.head_of_crime, f"{r.count_current_month:,}",
                         f"{r.count_same_month_prev_year:,}", f"{r.yoy_change:+,}"])
        s.append(_table(rows, [6 * cm, 3.5 * cm, 2 * cm, 3.3 * cm, 2.2 * cm]))
    if log:
        s.append(Paragraph("Data cleaning log", ss["Heading2"]))
        rows = [["Step", "Before", "After", "Detail"]]
        for e in log:
            rows.append([e.get("step"), e.get("rows_before"), e.get("rows_after"), str(e.get("detail", ""))[:500]])
        s.append(_table(rows, [3.5 * cm, 1.5 * cm, 1.5 * cm, 10.5 * cm]))
    doc.build(s, onFirstPage=_footer, onLaterPages=_footer)
    return buf.getvalue()
