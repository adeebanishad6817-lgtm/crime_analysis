"""File upload, validation and column mapping.

The app never assumes a dataset has every field. Uploaded columns are mapped
onto a set of *standard fields*; only Crime_Type and Date are mandatory.
Geography comes from Latitude/Longitude when present, otherwise from a
Location (city) name matched against a reference table of city coordinates.
"""
from __future__ import annotations

import io
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import BinaryIO

import pandas as pd

import config


@dataclass(frozen=True)
class StandardField:
    name: str
    description: str
    required: bool = False
    aliases: tuple[str, ...] = field(default_factory=tuple)


STANDARD_FIELDS: list[StandardField] = [
    StandardField("Crime_ID", "Unique report / record number",
                  aliases=("crime_id", "report_number", "id", "case_number", "fir_no", "record_id", "incident_id")),
    StandardField("Crime_Type", "Crime category or description", required=True,
                  aliases=("crime_type", "crime_description", "primary_type", "offense", "offence", "category", "crime")),
    StandardField("Date", "Date (or date-time) the crime occurred", required=True,
                  aliases=("date", "date_of_occurrence", "occurrence_date", "incident_date", "crime_date")),
    StandardField("Time", "Time (or full date-time) the crime occurred",
                  aliases=("time", "time_of_occurrence", "occurrence_time", "incident_time")),
    StandardField("Latitude", "Latitude in decimal degrees", aliases=("latitude", "lat", "y")),
    StandardField("Longitude", "Longitude in decimal degrees", aliases=("longitude", "lon", "lng", "long", "x")),
    StandardField("Location", "City / area name (used for maps when no coordinates)",
                  aliases=("location", "city", "area", "district", "community_area", "place")),
    StandardField("Severity", "Severity level (High / Medium / Low)", aliases=("severity", "severity_level")),
    StandardField("Police_Station", "Police station / district office",
                  aliases=("police_station", "station", "ps_name", "police_district")),
    StandardField("Date_Reported", "Date the crime was reported", aliases=("date_reported", "reported_date", "report_date")),
    StandardField("Crime_Code", "Crime code", aliases=("crime_code", "iucr", "code")),
    StandardField("Crime_Domain", "Broad crime domain", aliases=("crime_domain", "domain", "crime_group")),
    StandardField("Weapon_Used", "Weapon used", aliases=("weapon_used", "weapon")),
    StandardField("Victim_Age", "Victim age in years (anonymous)", aliases=("victim_age", "age")),
    StandardField("Victim_Gender", "Victim gender (anonymous)", aliases=("victim_gender", "gender", "sex")),
    StandardField("Police_Deployed", "Number of police deployed", aliases=("police_deployed", "officers_deployed")),
    StandardField("Case_Closed", "Whether the case is closed (Yes/No)", aliases=("case_closed", "closed", "case_status")),
    StandardField("Date_Case_Closed", "Date the case was closed", aliases=("date_case_closed", "closed_date", "closure_date")),
]
FIELD_NAMES = [f.name for f in STANDARD_FIELDS]
REQUIRED_FIELDS = [f.name for f in STANDARD_FIELDS if f.required]

PERSONAL_DATA_PATTERNS = re.compile(
    r"(^|_)(name|names|phone|mobile|email|aadhaar|aadhar|pan|address|accused|suspect|victim_name|offender)(_|$)",
    re.IGNORECASE,
)


class UploadError(ValueError):
    """Raised for files that cannot be accepted, with a user-facing message."""


def normalise(name: str) -> str:
    """'Date of Occurrence ' -> 'date_of_occurrence'."""
    name = str(name).replace("﻿", "").strip().lower()
    return re.sub(r"[^a-z0-9]+", "_", name).strip("_")


# ---------------------------------------------------------------------------
# File checks and reading
# ---------------------------------------------------------------------------
def validate_file(file_name: str, size_bytes: int) -> None:
    ext = Path(file_name).suffix.lower()
    if ext not in config.ALLOWED_EXTENSIONS:
        raise UploadError(f"Unsupported file type '{ext}'. Upload a CSV (.csv) or Excel (.xlsx, .xls) file.")
    if size_bytes == 0:
        raise UploadError("The file is empty (0 bytes). Check that you selected the right file.")
    if size_bytes > config.MAX_UPLOAD_MB * 1024 * 1024:
        raise UploadError(f"File is larger than {config.MAX_UPLOAD_MB} MB. Split it or filter it before uploading.")


def read_uploaded_file(source: BinaryIO | bytes | str | Path, file_name: str | None = None) -> pd.DataFrame:
    """Read CSV/Excel into a DataFrame with tidy column names."""
    if isinstance(source, (str, Path)):
        file_name = file_name or str(source)
        raw = Path(source).read_bytes()
    elif isinstance(source, bytes):
        raw = source
    else:
        raw = source.read()
    if file_name is None:
        raise UploadError("A file name is needed to detect the file type.")
    validate_file(file_name, len(raw))
    ext = Path(file_name).suffix.lower()
    try:
        if ext == ".csv":
            df = None
            for encoding in ("utf-8-sig", "latin-1"):
                try:
                    df = pd.read_csv(io.BytesIO(raw), encoding=encoding, low_memory=False)
                    break
                except UnicodeDecodeError:
                    continue
            if df is None:
                raise UploadError("Could not decode the CSV file. Save it as UTF-8 and try again.")
        else:
            df = pd.read_excel(io.BytesIO(raw))
    except UploadError:
        raise
    except pd.errors.EmptyDataError as exc:
        raise UploadError("The file has no rows or columns.") from exc
    except pd.errors.ParserError as exc:
        raise UploadError(f"The file is not a valid CSV: {exc}") from exc
    except Exception as exc:  # openpyxl / xlrd errors
        raise UploadError(f"Could not read the file: {exc}") from exc

    df.columns = [str(c).replace("﻿", "").strip() for c in df.columns]
    # Drop columns that are completely empty and unnamed (e.g. trailing commas)
    empty_unnamed = [c for c in df.columns if c.startswith("Unnamed") and df[c].isna().all()]
    df = df.drop(columns=empty_unnamed)
    if df.empty or len(df.columns) == 0:
        raise UploadError("The file contains no data rows.")
    return df


# ---------------------------------------------------------------------------
# Dataset type, mapping and checks
# ---------------------------------------------------------------------------
def detect_dataset_type(df: pd.DataFrame) -> str:
    """'aggregate' for monthly crime-review summaries, else 'incidents'."""
    cols = " ".join(normalise(c) for c in df.columns)
    if "heads_of_crime" in cols or ("major_heads" in cols and "current_month" in cols):
        return "aggregate"
    return "incidents"


def suggest_mapping(columns: list[str]) -> dict[str, str | None]:
    """Best-guess mapping {standard field: uploaded column or None}."""
    norm = {normalise(c): c for c in columns}
    mapping: dict[str, str | None] = {}
    used: set[str] = set()
    for f in STANDARD_FIELDS:
        choice = None
        for alias in (normalise(f.name),) + f.aliases:
            if alias in norm and norm[alias] not in used:
                choice = norm[alias]
                break
        mapping[f.name] = choice
        if choice:
            used.add(choice)
    return mapping


def validate_mapping(mapping: dict[str, str | None], df: pd.DataFrame) -> tuple[list[str], list[str]]:
    """Return (errors, warnings). Errors block saving and explain the fix."""
    errors: list[str] = []
    warnings: list[str] = []
    for name in REQUIRED_FIELDS:
        col = mapping.get(name)
        if not col:
            errors.append(
                f"Required field '{name}' is not mapped. Pick the column that holds the "
                f"{next(f.description.lower() for f in STANDARD_FIELDS if f.name == name)}, "
                f"or add such a column to your file and upload it again."
            )
        elif col not in df.columns:
            errors.append(f"Column '{col}' mapped to '{name}' does not exist in the file.")
    chosen = [c for c in mapping.values() if c]
    dupes = sorted({c for c in chosen if chosen.count(c) > 1})
    for c in dupes:
        fields = [k for k, v in mapping.items() if v == c]
        if set(fields) != {"Date", "Time"}:
            warnings.append(f"Column '{c}' is mapped to several fields: {', '.join(fields)}.")
    has_coords = bool(mapping.get("Latitude")) and bool(mapping.get("Longitude"))
    if bool(mapping.get("Latitude")) != bool(mapping.get("Longitude")):
        errors.append("Map both Latitude and Longitude, or neither.")
    if not has_coords and not mapping.get("Location"):
        warnings.append("No coordinates and no Location column: maps and DBSCAN hotspots will be unavailable.")
    elif not has_coords:
        warnings.append("No coordinate columns: maps will use approximate city-centre coordinates "
                        "from the Location column (city-level resolution, not exact incident points).")
    if not mapping.get("Severity"):
        warnings.append("No Severity column: severity will be derived from the crime type using a documented "
                        "mapping and labelled 'derived' in charts.")
    return errors, warnings


def detect_personal_data_columns(columns: list[str]) -> list[str]:
    """Columns that look like personally identifiable information."""
    return [c for c in columns if PERSONAL_DATA_PATTERNS.search(normalise(c))]


def profile_dataframe(df: pd.DataFrame) -> dict:
    """Basic dataset statistics shown before saving."""
    missing = df.isna().sum()
    return {
        "rows": int(len(df)),
        "columns": int(df.shape[1]),
        "duplicate_rows": int(df.duplicated().sum()),
        "missing_by_column": {c: int(v) for c, v in missing.items() if v > 0},
        "missing_cells": int(missing.sum()),
        "dtypes": {c: str(t) for c, t in df.dtypes.items()},
        "memory_mb": round(df.memory_usage(deep=True).sum() / 1e6, 2),
    }


def load_city_coordinates() -> pd.DataFrame:
    """Reference table of approximate city-centre coordinates."""
    ref = pd.read_csv(config.CITY_COORDS_FILE)
    ref["city_key"] = ref["city"].str.strip().str.lower()
    return ref
