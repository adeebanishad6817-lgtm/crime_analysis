"""Shared Streamlit state: dataset selection, cached loading, page header helpers."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from database import models
from database.connection import get_connection
from modules.filters import apply_filters, render_filters


@st.cache_data(ttl=30, show_spinner=False)
def list_uploads(dataset_type: str) -> pd.DataFrame:
    with get_connection() as conn:
        return models.list_uploads(conn, dataset_type=dataset_type, completed_only=True)


@st.cache_data(show_spinner="Loading crime records from PostgreSQL...")
def load_incidents(upload_id: int) -> pd.DataFrame:
    with get_connection() as conn:
        return models.load_crime_records(conn, upload_id)


@st.cache_data(show_spinner="Loading aggregate statistics...")
def load_aggregates(upload_id: int) -> pd.DataFrame:
    with get_connection() as conn:
        return models.load_aggregate_stats(conn, upload_id)


def clear_caches() -> None:
    st.cache_data.clear()


def _label(row) -> str:
    return f"#{row['upload_id']} {row['file_name']} ({int(row['rows_saved'] or 0):,} rows)"


def select_upload(dataset_type: str, label: str) -> dict | None:
    """Sidebar selector for the dataset to analyse; remembers the choice."""
    ups = list_uploads(dataset_type)
    if ups.empty:
        return None
    options = ups["upload_id"].tolist()
    key = f"active_{dataset_type}"
    if st.session_state.get(key) not in options:
        st.session_state[key] = options[0]
    by_id = {int(r["upload_id"]): r for r in ups.to_dict("records")}
    choice = st.sidebar.selectbox(label, options, key=key, format_func=lambda i: _label(by_id[int(i)]))
    return dict(by_id[int(choice)])


def source_text(upload: dict) -> str:
    text = f"Source: {upload.get('source_name') or upload['file_name']} (upload #{upload['upload_id']})"
    if upload.get("is_synthetic"):
        text += " - flagged as synthetic/simulated data, not real-world statistics"
    return text


def provenance_banner(upload: dict) -> None:
    if upload.get("is_synthetic"):
        note = upload.get("source_note") or ""
        st.warning(f"**Dataset flagged as synthetic / simulated.** Results describe this dataset only and are not "
                   f"real-world crime statistics. {note}", icon=":material/science:")


def incident_context(require_data: bool = True) -> tuple[dict | None, pd.DataFrame, pd.DataFrame, dict]:
    """Select dataset, load it, draw filters. Returns (upload, full df, filtered df, filters)."""
    upload = select_upload("incidents", "Incident dataset")
    if upload is None:
        if require_data:
            st.info("No incident dataset has been loaded yet. An administrator can upload one on the "
                    "**Data Management** page, or run `python scripts/load_sample_data.py`.",
                    icon=":material/upload_file:")
        return None, pd.DataFrame(), pd.DataFrame(), {}
    df = load_incidents(upload["upload_id"])
    filters = render_filters(df, f"incidents-{upload['upload_id']}")
    st.session_state["active_filters"] = filters
    filtered = apply_filters(df, filters)
    return upload, df, filtered, filters


def filter_status(full: pd.DataFrame, filtered: pd.DataFrame) -> None:
    if len(filtered) != len(full):
        st.caption(f"Showing {len(filtered):,} of {len(full):,} records after filters.")
    if filtered.empty:
        st.warning("No records match the current filters. Widen the filters in the sidebar.",
                   icon=":material/filter_alt_off:")


def page_header(title: str, subtitle: str) -> None:
    st.title(title)
    st.caption(subtitle)


def kpi_card(col, label: str, value: str, help_text: str | None = None) -> None:
    col.metric(label, value, help=help_text, border=True)
