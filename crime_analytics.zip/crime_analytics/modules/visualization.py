"""Plotly chart builders and Folium map builders.

Every builder:
* takes already-aggregated data from ``crime_analysis`` / ``hotspot_detection``,
* sets a meaningful title, labelled axes and hover tooltips,
* returns a placeholder figure with a message when the data is empty.

Colour rules: categorical hues are assigned in a fixed order (never cycled),
magnitude uses a single blue ramp, and severity (an ordered scale) uses
three steps of that same ramp.
"""
from __future__ import annotations

import html

import folium
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from folium.plugins import HeatMap, MarkerCluster

CATEGORICAL = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
OTHER_GREY = "#9a9994"
SEQUENTIAL = ["#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b"]
SEVERITY_COLORS = {"High": "#184f95", "Medium": "#3987e5", "Low": "#9ec5f4"}
ANOMALY_COLOR = "#e34948"
NOISE_COLOR = "#8a8984"
FONT = "Inter, Segoe UI, Helvetica, Arial, sans-serif"


def _base_layout(fig: go.Figure, title: str, x_title: str | None = None, y_title: str | None = None,
                 height: int = 380, source: str | None = None) -> go.Figure:
    title_cfg = {"text": title, "x": 0.0, "xanchor": "left", "font": {"size": 16}}
    if source:  # source line sits under the title so it never collides with axis labels
        title_cfg["subtitle"] = {"text": source, "font": {"size": 10, "color": "#8a8984"}}
    fig.update_layout(
        title=title_cfg, font={"family": FONT, "size": 12},
        height=height, margin={"l": 10, "r": 10, "t": 72 if source else 56, "b": 40},
        hoverlabel={"font": {"family": FONT}}, legend={"orientation": "h", "y": -0.2, "x": 0},
        bargap=0.25, barcornerradius=4,
    )
    if x_title is not None:
        fig.update_xaxes(title_text=x_title, showgrid=False)
    if y_title is not None:
        fig.update_yaxes(title_text=y_title, gridcolor="rgba(128,128,128,0.15)", zeroline=False)
    return fig


def empty_figure(title: str, message: str = "No data for the current filters.", height: int = 320) -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(text=message, xref="paper", yref="paper", x=0.5, y=0.5, showarrow=False,
                       font={"size": 14, "color": "#8a8984"})
    fig.update_xaxes(visible=False)
    fig.update_yaxes(visible=False)
    return _base_layout(fig, title, height=height)


def color_map(categories: list[str]) -> dict[str, str]:
    """Fixed-order categorical colours; anything past slot 8 is grey 'Other'."""
    return {c: (CATEGORICAL[i] if i < len(CATEGORICAL) else OTHER_GREY) for i, c in enumerate(categories)}


# ---------------------------------------------------------------------------
# Plotly charts
# ---------------------------------------------------------------------------
def line_chart(df: pd.DataFrame, x: str, y: str, title: str, x_title: str, y_title: str,
               group: str | None = None, source: str | None = None, height: int = 380) -> go.Figure:
    if df.empty:
        return empty_figure(title)
    if group:
        order = df.groupby(group)[y].sum().sort_values(ascending=False).index.tolist()
        fig = px.line(df, x=x, y=y, color=group, category_orders={group: order}, color_discrete_map=color_map(order))
    else:
        fig = px.line(df, x=x, y=y, color_discrete_sequence=[CATEGORICAL[0]])
    fig.update_traces(line={"width": 2}, hovertemplate=f"%{{x}}<br>{y_title}: %{{y:,.0f}}<extra>%{{fullData.name}}</extra>")
    fig.update_layout(hovermode="x unified")
    fig.update_yaxes(rangemode="tozero")
    return _base_layout(fig, title, x_title, y_title, height=height, source=source)


def bar_chart(df: pd.DataFrame, x: str, y: str, title: str, x_title: str, y_title: str,
              horizontal: bool = False, color: str | None = None, source: str | None = None,
              height: int = 380, text_fmt: str | None = None) -> go.Figure:
    if df.empty:
        return empty_figure(title)
    if horizontal:
        data = df.sort_values(x, ascending=True)
        fig = go.Figure(go.Bar(x=data[x], y=data[y], orientation="h", marker_color=color or CATEGORICAL[0],
                               hovertemplate=f"%{{y}}<br>{x_title}: %{{x:,.0f}}<extra></extra>"))
        height = max(height, 26 * len(data) + 90)
    else:
        fig = go.Figure(go.Bar(x=df[x], y=df[y], marker_color=color or CATEGORICAL[0],
                               hovertemplate=f"%{{x}}<br>{y_title}: %{{y:,.0f}}<extra></extra>"))
    if text_fmt:
        fig.update_traces(texttemplate=text_fmt, textposition="outside", cliponaxis=False)
    return _base_layout(fig, title, x_title, y_title, height=height, source=source)


def donut_chart(df: pd.DataFrame, names: str, values: str, title: str, colors: dict | None = None,
                source: str | None = None) -> go.Figure:
    if df.empty:
        return empty_figure(title)
    cmap = colors or color_map(df[names].tolist())
    fig = go.Figure(go.Pie(labels=df[names], values=df[values], hole=0.55, sort=False,
                           marker={"colors": [cmap.get(n, OTHER_GREY) for n in df[names]],
                                   "line": {"color": "rgba(255,255,255,0.9)", "width": 2}},
                           textinfo="label+percent", hovertemplate="%{label}: %{value:,} (%{percent})<extra></extra>"))
    return _base_layout(fig, title, source=source)


def heatmap(matrix: pd.DataFrame, title: str, x_title: str, y_title: str, source: str | None = None,
            height: int = 420, colorbar_title: str = "Incidents") -> go.Figure:
    if matrix is None or matrix.empty:
        return empty_figure(title)
    fig = go.Figure(go.Heatmap(
        z=matrix.to_numpy(), x=[str(c) for c in matrix.columns], y=[str(i) for i in matrix.index],
        colorscale=[[i / (len(SEQUENTIAL) - 1), c] for i, c in enumerate(SEQUENTIAL)], xgap=2, ygap=2,
        colorbar={"title": {"text": colorbar_title}},
        hovertemplate=f"{y_title}: %{{y}}<br>{x_title}: %{{x}}<br>{colorbar_title}: %{{z:,}}<extra></extra>"))
    fig.update_yaxes(autorange="reversed")
    return _base_layout(fig, title, x_title, y_title, height=height, source=source)


def correlation_heatmap(corr: pd.DataFrame, title: str, source: str | None = None) -> go.Figure:
    if corr is None or corr.empty:
        return empty_figure(title)
    fig = go.Figure(go.Heatmap(
        z=corr.to_numpy(), x=list(corr.columns), y=list(corr.index), zmin=-1, zmax=1,
        colorscale=[[0, "#eb6834"], [0.5, "#e6e5e1"], [1, "#2a78d6"]], xgap=2, ygap=2,
        text=np.round(corr.to_numpy(), 2), texttemplate="%{text}", colorbar={"title": {"text": "rho"}},
        hovertemplate="%{y} vs %{x}<br>rho = %{z:.3f}<extra></extra>"))
    fig.update_yaxes(autorange="reversed")
    return _base_layout(fig, title, "Variable", "Variable", height=460, source=source)


def anomaly_chart(table: pd.DataFrame, title: str, group_value: str | None = None,
                  group_col: str | None = None, source: str | None = None) -> go.Figure:
    if table.empty:
        return empty_figure(title)
    data = table if not group_col else table[table[group_col] == group_value]
    if data.empty:
        return empty_figure(title)
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=data["period"], y=data["count"], mode="lines", name="Incidents",
                             line={"color": CATEGORICAL[0], "width": 2},
                             hovertemplate="%{x|%d %b %Y}<br>Incidents: %{y:,}<extra></extra>"))
    if "expected" in data:
        fig.add_trace(go.Scatter(x=data["period"], y=data["expected"], mode="lines", name="Recent average",
                                 line={"color": NOISE_COLOR, "width": 1.5, "dash": "dot"},
                                 hovertemplate="%{x|%d %b %Y}<br>Recent average: %{y:,.1f}<extra></extra>"))
    flagged = data[data["is_anomaly"]]
    if len(flagged):
        fig.add_trace(go.Scatter(x=flagged["period"], y=flagged["count"], mode="markers", name="Unusual period",
                                 marker={"color": ANOMALY_COLOR, "size": 10, "symbol": "diamond",
                                         "line": {"color": "white", "width": 2}},
                                 hovertemplate="%{x|%d %b %Y}<br>Incidents: %{y:,}<br>Flagged as unusual<extra></extra>"))
    return _base_layout(fig, title, "Period start", "Incidents", source=source)


def k_distance_chart(distances: np.ndarray, eps_km: float, k: int) -> go.Figure:
    title = f"k-distance plot (k = {k}): distance to {k}th nearest location"
    if len(distances) == 0:
        return empty_figure(title, "Need at least two locations.")
    fig = go.Figure(go.Scatter(x=np.arange(1, len(distances) + 1), y=distances, mode="lines+markers",
                               line={"color": CATEGORICAL[0], "width": 2}, marker={"size": 8},
                               hovertemplate="Location %{x}<br>%{y:,.1f} km<extra></extra>", name="k-distance"))
    fig.add_hline(y=eps_km, line={"color": CATEGORICAL[1], "dash": "dash", "width": 1.5},
                  annotation_text=f"current eps = {eps_km:g} km", annotation_position="top left")
    return _base_layout(fig, title, "Locations sorted by distance", "Distance (km)", height=340)


def severity_donut(df: pd.DataFrame, title: str, source: str | None = None) -> go.Figure:
    order = [s for s in ("High", "Medium", "Low") if s in set(df.get("severity", []))]
    data = df.set_index("severity").reindex(order).reset_index() if not df.empty else df
    return donut_chart(data, "severity", "incidents", title, colors=SEVERITY_COLORS, source=source)


def stacked_severity_bar(matrix: pd.DataFrame, title: str, source: str | None = None) -> go.Figure:
    if matrix is None or matrix.empty:
        return empty_figure(title)
    data = matrix.loc[matrix.sum(axis=1).sort_values().index]
    fig = go.Figure()
    for sev in ("High", "Medium", "Low"):
        if sev in data:
            fig.add_trace(go.Bar(y=data.index, x=data[sev], name=sev, orientation="h",
                                 marker={"color": SEVERITY_COLORS[sev], "line": {"color": "white", "width": 1}},
                                 hovertemplate=f"%{{y}}<br>{sev}: %{{x:,}}<extra></extra>"))
    fig.update_layout(barmode="stack")
    return _base_layout(fig, title, "Incidents", "Crime type", height=max(380, 24 * len(data) + 110), source=source)


# ---------------------------------------------------------------------------
# Folium maps
# ---------------------------------------------------------------------------
def _new_map(points: pd.DataFrame) -> folium.Map:
    if points.empty:
        return folium.Map(location=[22.5, 79.0], zoom_start=4, tiles="OpenStreetMap")
    m = folium.Map(location=[points["latitude"].mean(), points["longitude"].mean()], zoom_start=5,
                   tiles="OpenStreetMap", control_scale=True)
    m.fit_bounds([[points["latitude"].min(), points["longitude"].min()],
                  [points["latitude"].max(), points["longitude"].max()]], padding=(20, 20))
    return m


def _legend(m: folium.Map, title: str, items: list[tuple[str, str]]) -> None:
    rows = "".join(
        f"<div style='display:flex;align-items:center;gap:6px;margin:2px 0'>"
        f"<span style='width:12px;height:12px;border-radius:50%;background:{c};display:inline-block'></span>"
        f"{html.escape(label)}</div>" for label, c in items)
    box = (f"<div style='position:fixed;bottom:24px;left:24px;z-index:9999;background:white;padding:8px 10px;"
           f"border:1px solid #ccc;border-radius:8px;font:12px {FONT};color:#222'>"
           f"<b>{html.escape(title)}</b>{rows}</div>")
    m.get_root().html.add_child(folium.Element(box))


def incident_map(points: pd.DataFrame, mode: str = "markers", city_level: bool = True) -> folium.Map:
    """Locations sized by incident count (markers) or a weighted heatmap."""
    m = _new_map(points)
    if points.empty:
        return m
    if mode == "heatmap":
        mx = points["incident_count"].max()
        HeatMap(points[["latitude", "longitude", "incident_count"]].assign(
            incident_count=lambda d: d["incident_count"] / mx).values.tolist(),
            radius=35 if city_level else 12, blur=25 if city_level else 15, min_opacity=0.3).add_to(m)
        return m
    mx = points["incident_count"].max()
    layer = m if city_level or len(points) < 2000 else MarkerCluster().add_to(m)
    for r in points.itertuples():
        radius = 6 + 24 * np.sqrt(r.incident_count / mx) if city_level else 4
        name = html.escape(str(r.location)) if r.location else f"{r.latitude:.4f}, {r.longitude:.4f}"
        folium.CircleMarker(
            location=[r.latitude, r.longitude], radius=float(radius), color="white", weight=2,
            fill=True, fill_color=CATEGORICAL[0], fill_opacity=0.75,
            tooltip=f"{name}: {r.incident_count:,} incidents",
            popup=folium.Popup(f"<b>{name}</b><br>{r.incident_count:,} incidents", max_width=220),
        ).add_to(layer)
    _legend(m, "Incidents", [("Circle area = incident count", CATEGORICAL[0])])
    return m


def cluster_map(result, city_level: bool = True) -> folium.Map:
    """DBSCAN result: coloured cluster members, grey noise, ranked cluster circles."""
    points = result.points
    m = _new_map(points)
    if points.empty:
        return m
    labels = result.clusters["cluster_label"].tolist() if not result.clusters.empty else []
    colors = {lab: CATEGORICAL[i % len(CATEGORICAL)] for i, lab in enumerate(labels)}
    mx = points["incident_count"].max()
    for r in points.itertuples():
        is_noise = r.cluster == -1
        radius = (5 + 20 * np.sqrt(r.incident_count / mx)) if city_level else 4
        name = html.escape(str(r.location)) if r.location else f"{r.latitude:.4f}, {r.longitude:.4f}"
        label = "Noise" if is_noise else f"Cluster {int(r.cluster)}"
        folium.CircleMarker(
            location=[r.latitude, r.longitude], radius=float(radius if not is_noise else max(4, radius * 0.6)),
            color="white", weight=2 if not is_noise else 1, fill=True,
            fill_color=NOISE_COLOR if is_noise else colors.get(r.cluster, OTHER_GREY),
            fill_opacity=0.5 if is_noise else 0.85,
            tooltip=f"{name}: {r.incident_count:,} incidents ({label})",
        ).add_to(m)
    for c in result.clusters.itertuples():
        color = colors.get(c.cluster_label, OTHER_GREY)
        radius_m = max(float(c.radius_km) * 1000 + (15000 if city_level else 150), 15000 if city_level else 150)
        folium.Circle(location=[c.centroid_lat, c.centroid_lon], radius=radius_m, color=color, weight=2,
                      fill=True, fill_opacity=0.08, dash_array="6,4",
                      tooltip=f"Hotspot #{c.rank}: {c.incident_count:,} incidents").add_to(m)
        folium.Marker(
            location=[c.centroid_lat, c.centroid_lon],
            icon=folium.DivIcon(html=f"<div style='background:{color};color:white;border-radius:12px;"
                                     f"width:24px;height:24px;line-height:24px;text-align:center;font:600 12px {FONT};"
                                     f"border:2px solid white'>{c.rank}</div>", icon_size=(24, 24), icon_anchor=(12, 12)),
            tooltip=f"Hotspot #{c.rank} - {html.escape(str(c.member_locations))}: {c.incident_count:,} incidents",
        ).add_to(m)
    items = [(f"#{c.rank} {str(c.member_locations)[:32]}{'...' if len(str(c.member_locations)) > 32 else ''}",
              colors[c.cluster_label]) for c in result.clusters.head(8).itertuples()]
    items.append(("Noise (not in any hotspot)", NOISE_COLOR))
    _legend(m, "DBSCAN result", items)
    return m
