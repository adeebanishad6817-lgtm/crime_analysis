"""Descriptive statistics, temporal patterns, trend tests and auto-observations.

Everything here describes *observed history*. Nothing forecasts future crime.
"""
from __future__ import annotations

import math
import warnings

import numpy as np
import pandas as pd
from scipy import stats

WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


# ---------------------------------------------------------------------------
# KPIs and simple counts
# ---------------------------------------------------------------------------
def kpis(df: pd.DataFrame) -> dict:
    if df.empty:
        return {"total": 0}
    top_type = df["crime_type"].value_counts()
    out = {
        "total": int(len(df)),
        "first_date": df["occurred_at"].min(),
        "last_date": df["occurred_at"].max(),
        "top_crime_type": top_type.index[0],
        "top_crime_type_count": int(top_type.iloc[0]),
        "n_crime_types": int(df["crime_type"].nunique()),
        "high_severity_pct": float((df["severity"] == "High").mean() * 100) if "severity" in df else None,
    }
    if "location" in df and df["location"].notna().any():
        loc = df["location"].value_counts()
        out.update(top_location=loc.index[0], top_location_count=int(loc.iloc[0]), n_locations=int(df["location"].nunique()))
    if "case_closed" in df and df["case_closed"].notna().any():
        out["closure_rate_pct"] = float(df["case_closed"].astype(float).mean() * 100)
    return out


def counts_by(df: pd.DataFrame, col: str, top: int | None = None) -> pd.DataFrame:
    if df.empty or col not in df or df[col].isna().all():
        return pd.DataFrame(columns=[col, "incidents", "share_pct"])
    vc = df[col].value_counts()
    out = vc.rename_axis(col).reset_index(name="incidents")
    out["share_pct"] = out["incidents"] / out["incidents"].sum() * 100
    return out.head(top) if top else out


def monthly_counts(df: pd.DataFrame, group: str | None = None) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame(columns=["month", "incidents"])
    data = df.assign(month=df["occurred_at"].dt.to_period("M").dt.start_time)
    keys = ["month"] + ([group] if group else [])
    return data.groupby(keys).size().reset_index(name="incidents")


def resample_complete(df: pd.DataFrame, rule: str) -> pd.Series:
    """Counts per period ('D', 'W-SUN', 'MS') with incomplete first/last periods dropped."""
    if df.empty:
        return pd.Series(dtype=float)
    ts = df.set_index("occurred_at").resample(rule).size()
    first, last = df["occurred_at"].min().normalize(), df["occurred_at"].max().normalize()
    if rule.startswith("W"):
        starts = ts.index - pd.Timedelta(days=6)
        ends = ts.index
    elif rule == "MS":
        starts = ts.index
        ends = ts.index + pd.offsets.MonthEnd(0)
    else:
        return ts
    keep = (starts >= first) & (ends <= last)
    return ts[keep]


def coverage_by_year(df: pd.DataFrame) -> pd.DataFrame:
    """Incidents per year with the number of months observed, so partial years are visible."""
    if df.empty:
        return pd.DataFrame(columns=["year", "incidents", "months_covered", "per_month"])
    g = df.groupby("year").agg(incidents=("crime_type", "size"),
                               months_covered=("month", "nunique")).reset_index()
    g["per_month"] = g["incidents"] / g["months_covered"]
    return g


# ---------------------------------------------------------------------------
# Temporal patterns
# ---------------------------------------------------------------------------
def hour_counts(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or df["hour"].isna().all():
        return pd.DataFrame(columns=["hour", "incidents"])
    return df["hour"].dropna().astype(int).value_counts().reindex(range(24), fill_value=0)\
        .rename_axis("hour").reset_index(name="incidents")


def weekday_counts(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame(columns=["weekday", "incidents"])
    vc = df["day_of_week"].value_counts().reindex(range(7), fill_value=0)
    return pd.DataFrame({"weekday": [d[:3] for d in WEEKDAYS], "incidents": vc.to_numpy()})


def month_of_year_counts(df: pd.DataFrame) -> pd.DataFrame:
    """Average incidents per calendar month (averaged over the years observed)."""
    if df.empty:
        return pd.DataFrame(columns=["month_name", "avg_incidents", "years_observed"])
    g = df.groupby(["year", "month"]).size().reset_index(name="n")
    m = g.groupby("month").agg(avg_incidents=("n", "mean"), years_observed=("n", "size")).reindex(range(1, 13))
    m["month_name"] = MONTH_NAMES
    return m.reset_index()[["month", "month_name", "avg_incidents", "years_observed"]]


def weekday_hour_matrix(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or df["hour"].isna().all():
        return pd.DataFrame()
    m = pd.crosstab(df["day_of_week"], df["hour"].astype("Int64")).reindex(index=range(7), columns=range(24), fill_value=0)
    m.index = WEEKDAYS
    return m


def weekend_vs_weekday(df: pd.DataFrame) -> pd.DataFrame:
    """Average incidents per calendar day for weekdays vs weekends (fair comparison: 5 vs 2 days)."""
    if df.empty:
        return pd.DataFrame(columns=["day_type", "days", "incidents", "avg_per_day"])
    daily = df.groupby(df["occurred_at"].dt.normalize()).size()
    all_days = pd.date_range(daily.index.min(), daily.index.max(), freq="D")
    daily = daily.reindex(all_days, fill_value=0)
    is_we = daily.index.dayofweek >= 5
    rows = []
    for label, mask in (("Weekday", ~is_we), ("Weekend", is_we)):
        rows.append({"day_type": label, "days": int(mask.sum()), "incidents": int(daily[mask].sum()),
                     "avg_per_day": float(daily[mask].mean()) if mask.any() else 0.0})
    out = pd.DataFrame(rows)
    if is_we.any() and (~is_we).any():
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            t = stats.ttest_ind(daily[~is_we], daily[is_we], equal_var=False)
        if np.isfinite(t.pvalue):
            out.attrs["welch_t_p"] = float(t.pvalue)
    return out


def peak_periods(df: pd.DataFrame) -> dict:
    if df.empty:
        return {}
    out = {"peak_weekday": WEEKDAYS[int(df["day_of_week"].mode().iat[0])],
           "peak_month": MONTH_NAMES[int(df["month"].mode().iat[0]) - 1]}
    if df["hour"].notna().any():
        h = hour_counts(df)
        top = h.sort_values("incidents", ascending=False).iloc[0]
        out["peak_hour"] = int(top["hour"])
        out["peak_hour_share_pct"] = float(top["incidents"] / h["incidents"].sum() * 100)
        out["peak_time_period"] = df["time_period"].mode().iat[0]
    daily = df.groupby(df["occurred_at"].dt.date).size()
    out["busiest_day"] = str(daily.idxmax())
    out["busiest_day_count"] = int(daily.max())
    return out


# ---------------------------------------------------------------------------
# Category analysis
# ---------------------------------------------------------------------------
def category_location_matrix(df: pd.DataFrame, top_types: int = 15, top_locations: int = 15) -> pd.DataFrame:
    if df.empty or "location" not in df or df["location"].isna().all():
        return pd.DataFrame()
    types = df["crime_type"].value_counts().head(top_types).index
    locs = df["location"].value_counts().head(top_locations).index
    sub = df[df["crime_type"].isin(types) & df["location"].isin(locs)]
    return pd.crosstab(sub["crime_type"], sub["location"]).reindex(index=types, columns=locs, fill_value=0)


def severity_by_category(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()
    return pd.crosstab(df["crime_type"], df["severity"]).reindex(columns=["High", "Medium", "Low"], fill_value=0)


def category_share_by_year(df: pd.DataFrame, top_n: int = 8) -> pd.DataFrame:
    if df.empty:
        return pd.DataFrame()
    """Share (%) of each year's incidents for the top categories (the rest are omitted, not lumped)."""
    types = df["crime_type"].value_counts().head(top_n).index
    ct = pd.crosstab(df["year"], df["crime_type"], normalize="index") * 100
    return ct[types]


# ---------------------------------------------------------------------------
# Trend tests (observed, not forecast)
# ---------------------------------------------------------------------------
def mann_kendall(values: np.ndarray) -> dict:
    """Mann-Kendall trend test with tie correction and Sen's slope."""
    x = np.asarray(values, dtype=float)
    n = len(x)
    if n < 4:
        return {"n": n, "s": None, "z": None, "p_value": None, "sens_slope": None, "trend": "insufficient data"}
    s = 0.0
    for k in range(n - 1):
        s += np.sign(x[k + 1:] - x[k]).sum()
    _, counts = np.unique(x, return_counts=True)
    var_s = (n * (n - 1) * (2 * n + 5) - np.sum(counts * (counts - 1) * (2 * counts + 5))) / 18
    if var_s <= 0:
        z = 0.0
    elif s > 0:
        z = (s - 1) / math.sqrt(var_s)
    elif s < 0:
        z = (s + 1) / math.sqrt(var_s)
    else:
        z = 0.0
    p = 2 * (1 - stats.norm.cdf(abs(z)))
    slopes = [(x[j] - x[i]) / (j - i) for i in range(n - 1) for j in range(i + 1, n)]
    sens = float(np.median(slopes))
    trend = "no significant trend"
    if p < 0.05:
        trend = "increasing" if z > 0 else "decreasing"
    return {"n": n, "s": float(s), "z": float(z), "p_value": float(p), "sens_slope": sens, "trend": trend}


def trend_summary(series: pd.Series) -> dict:
    """Linear regression + Mann-Kendall on an ordered count series."""
    y = series.astype(float).to_numpy()
    if len(y) < 4:
        return {"trend": "insufficient data", "n": len(y)}
    lr = stats.linregress(np.arange(len(y)), y)
    mk = mann_kendall(y)
    mean = y.mean() or 1.0
    return {"n": len(y), "slope_per_period": float(lr.slope), "slope_pct_of_mean": float(lr.slope / mean * 100),
            "r_squared": float(lr.rvalue ** 2), "lr_p_value": float(lr.pvalue), **{f"mk_{k}": v for k, v in mk.items()},
            "trend": mk["trend"]}


def complete_months(df: pd.DataFrame) -> pd.DataFrame:
    """Monthly counts with partial first/last months removed."""
    m = monthly_counts(df)
    if m.empty:
        return m
    first, last = df["occurred_at"].min(), df["occurred_at"].max()
    if first.day > 1 or first.normalize() != first.to_period("M").start_time:
        m = m[m["month"] != first.to_period("M").start_time]
    if (last + pd.Timedelta(days=1)).month == last.month:
        m = m[m["month"] != last.to_period("M").start_time]
    return m


def category_trends(df: pd.DataFrame, top_n: int = 10) -> pd.DataFrame:
    rows = []
    months = complete_months(df)["month"]
    if months.empty:
        return pd.DataFrame()
    for t in df["crime_type"].value_counts().head(top_n).index:
        s = monthly_counts(df[df["crime_type"] == t]).set_index("month")["incidents"].reindex(months, fill_value=0)
        r = trend_summary(s)
        rows.append({"crime_type": t, "months": r.get("n"), "mean_per_month": float(s.mean()),
                     "slope_per_month": r.get("slope_per_period"), "mk_p_value": r.get("mk_p_value"),
                     "trend": r.get("trend")})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Period comparison and correlation
# ---------------------------------------------------------------------------
def compare_periods(df: pd.DataFrame, a: tuple, b: tuple, by: str = "crime_type") -> tuple[pd.DataFrame, dict]:
    """Compare counts between two date ranges; chi-square test on the distribution."""
    ts = df["occurred_at"]
    da = df[(ts >= pd.Timestamp(a[0])) & (ts < pd.Timestamp(a[1]) + pd.Timedelta(days=1))]
    db = df[(ts >= pd.Timestamp(b[0])) & (ts < pd.Timestamp(b[1]) + pd.Timedelta(days=1))]
    ca, cb = da[by].value_counts(), db[by].value_counts()
    out = pd.concat([ca.rename("period_a"), cb.rename("period_b")], axis=1).fillna(0).astype(int)
    out["change"] = out["period_b"] - out["period_a"]
    out["change_pct"] = np.where(out["period_a"] > 0, out["change"] / out["period_a"].replace(0, np.nan) * 100, np.nan)
    out = out.sort_values("period_b", ascending=False).rename_axis(by).reset_index()
    days_a = (pd.Timestamp(a[1]) - pd.Timestamp(a[0])).days + 1
    days_b = (pd.Timestamp(b[1]) - pd.Timestamp(b[0])).days + 1
    test = {"total_a": int(len(da)), "total_b": int(len(db)), "days_a": days_a, "days_b": days_b,
            "per_day_a": len(da) / days_a if days_a > 0 else None, "per_day_b": len(db) / days_b if days_b > 0 else None}
    table = out[(out["period_a"] + out["period_b"]) > 0][["period_a", "period_b"]]
    if len(table) >= 2 and len(da) and len(db):
        chi2, p, dof, _ = stats.chi2_contingency(table.to_numpy().T)
        test.update(chi2=float(chi2), p_value=float(p), dof=int(dof))
    return out, test


NUMERIC_FOR_CORRELATION = ["hour", "day_of_week", "month", "victim_age", "police_deployed", "resolution_days"]


def correlation_matrix(df: pd.DataFrame, method: str = "spearman") -> pd.DataFrame:
    cols = [c for c in NUMERIC_FOR_CORRELATION if c in df and pd.to_numeric(df[c], errors="coerce").notna().sum() > 30]
    data = df[cols].apply(pd.to_numeric, errors="coerce")
    if "case_closed" in df and df["case_closed"].notna().any():
        data["case_closed"] = df["case_closed"].astype(float)
    data["is_high_severity"] = (df["severity"] == "High").astype(float)
    data = data.loc[:, data.std(ddof=0) > 0]
    return data.corr(method=method)


def strongest_correlations(corr: pd.DataFrame, n: int = 5) -> pd.DataFrame:
    if corr.empty:
        return pd.DataFrame(columns=["var_1", "var_2", "rho"])
    pairs = corr.where(np.triu(np.ones(corr.shape, dtype=bool), k=1)).stack().rename("rho").reset_index()
    pairs.columns = ["var_1", "var_2", "rho"]
    return pairs.reindex(pairs["rho"].abs().sort_values(ascending=False).index).head(n)


# ---------------------------------------------------------------------------
# Automatic observations (all computed from the data passed in)
# ---------------------------------------------------------------------------
def auto_observations(df: pd.DataFrame, dbscan=None, anomalies=None) -> list[str]:
    if df.empty:
        return ["No incidents match the current filters."]
    obs: list[str] = []
    k = kpis(df)
    obs.append(f"{k['total']:,} incidents between {k['first_date']:%d %b %Y} and {k['last_date']:%d %b %Y}, "
               f"across {k['n_crime_types']} crime categories.")
    vc = df["crime_type"].value_counts()
    obs.append(f"Most frequent category: {vc.index[0]} ({vc.iloc[0]:,}, {vc.iloc[0] / len(df):.1%}); "
               f"least frequent: {vc.index[-1]} ({vc.iloc[-1]:,}).")
    cv = vc.std(ddof=0) / vc.mean() if len(vc) > 1 else 0
    if len(vc) >= 5 and cv < 0.05:
        obs.append(f"Category counts are almost uniform (coefficient of variation {cv:.1%}). Real-world crime "
                   f"data is usually highly skewed, so check how this dataset was produced before drawing conclusions.")
    if "top_location" in k:
        obs.append(f"{k['top_location']} has the most incidents ({k['top_location_count']:,}, "
                   f"{k['top_location_count'] / k['total']:.1%} of the filtered total).")
    p = peak_periods(df)
    if "peak_hour" in p:
        obs.append(f"Peak hour is {p['peak_hour']:02d}:00 with {p['peak_hour_share_pct']:.1f}% of incidents "
                   f"(an even spread would be 4.2% per hour).")
    ww = weekend_vs_weekday(df)
    if len(ww) == 2 and "welch_t_p" in ww.attrs:
        wd, we = ww.set_index("day_type")["avg_per_day"]
        sig = "a statistically significant" if ww.attrs["welch_t_p"] < 0.05 else "no statistically significant"
        obs.append(f"Average per day: {wd:.1f} on weekdays vs {we:.1f} on weekends - {sig} difference "
                   f"(Welch t-test p = {ww.attrs['welch_t_p']:.3f}).")
    months = complete_months(df)
    if len(months) >= 6:
        t = trend_summary(months["incidents"])
        obs.append(f"Monthly volume over {t['n']} complete months: {t['trend']} "
                   f"(Mann-Kendall p = {t['mk_p_value']:.3f}; slope {t['slope_per_period']:+.1f} incidents/month). "
                   f"This describes the past only and is not a forecast.")
    if "closure_rate_pct" in k:
        obs.append(f"{k['closure_rate_pct']:.1f}% of cases are recorded as closed.")
    if dbscan is not None and getattr(dbscan, "n_clusters", 0):
        top = dbscan.clusters.iloc[0]
        obs.append(f"DBSCAN (eps {dbscan.params['eps_km']:g} km, min_samples {dbscan.params['min_samples']}) found "
                   f"{dbscan.n_clusters} hotspot(s); the largest groups {top['member_locations']} with "
                   f"{int(top['incident_count']):,} incidents. {dbscan.noise_incidents:,} incidents are noise.")
    if anomalies is not None and anomalies.n_anomalies:
        obs.append(f"Isolation Forest flagged {anomalies.n_anomalies} unusual period(s) in aggregate activity.")
    return obs
