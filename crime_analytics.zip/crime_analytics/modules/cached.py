"""Cached wrappers around the heavier analyses, shared by several pages."""
from __future__ import annotations

import pandas as pd
import streamlit as st

import config
from modules.anomaly_detection import detect_activity_anomalies
from modules.hotspot_detection import run_dbscan


def dbscan_params() -> tuple[float, int, bool]:
    """Current DBSCAN settings (shared between the Hotspot, Overview and Reports pages)."""
    return (float(st.session_state.get("dbscan_eps_km", config.DBSCAN_DEFAULT_EPS_KM)),
            int(st.session_state.get("dbscan_min_samples", config.DBSCAN_DEFAULT_MIN_SAMPLES)),
            bool(st.session_state.get("dbscan_weighted", True)))


@st.cache_data(show_spinner="Running DBSCAN clustering...", max_entries=32)
def cached_dbscan(df: pd.DataFrame, eps_km: float, min_samples: int, weighted: bool):
    return run_dbscan(df, eps_km, min_samples, weighted)


@st.cache_data(show_spinner="Running Isolation Forest...", max_entries=32)
def cached_anomalies(df: pd.DataFrame, freq: str, group_col: str | None, contamination: float):
    return detect_activity_anomalies(df, freq, group_col, contamination)
