"""Parser, cleaner and analysis for aggregated monthly crime-review files.

Built for the Karnataka State Police "crime review for the month" format:
one row per crime category with four count columns (current month, previous
month, same month of previous year, year-to-date). Columns are matched by
header text, not position, so small layout changes do not break parsing.

These files contain category totals only - no incidents, dates or places -
so they are analysed separately from incident data and never mixed with it.
"""
from __future__ import annotations

import re
from datetime import date

import numpy as np
import pandas as pd

from modules.data_upload import UploadError, normalise

COLUMN_PATTERNS = {
    "sl_no": ("sl_no", "sl", "serial"),
    "head_of_crime": ("heads_of_crime", "head_of_crime"),
    "major_head_raw": ("major_heads", "major_head"),
    "minor_head": ("minor_heads", "minor_head"),
    "count_ytd": ("current_year_upto", "year_upto", "ytd"),
    "count_same_month_prev_year": ("corresponding_month_of_previous_year", "same_month_previous_year"),
    "count_previous_month": ("during_the_previous_month", "previous_month"),
    "count_current_month": ("during_the_current_month", "current_month"),
}
COUNT_COLUMNS = ["count_current_month", "count_previous_month", "count_same_month_prev_year", "count_ytd"]
MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], start=1)}


def report_month_from_filename(file_name: str) -> date | None:
    """'crime_review_for_month_Feb2026.csv' -> date(2026, 2, 1)."""
    m = re.search(r"(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*[\s_-]*(\d{4})", file_name, re.I)
    if not m:
        return None
    return date(int(m.group(2)), MONTHS[m.group(1).lower()[:3]], 1)


def _match_columns(columns: list[str]) -> dict[str, str]:
    norm = {c: normalise(c) for c in columns}
    found: dict[str, str] = {}
    # Order matters: match the long, specific headers first.
    for target in ("count_ytd", "count_same_month_prev_year", "count_previous_month",
                   "count_current_month", "head_of_crime", "major_head_raw", "minor_head", "sl_no"):
        for col, n in norm.items():
            if col in found.values():
                continue
            if any(p in n for p in COLUMN_PATTERNS[target]):
                found[target] = col
                break
    return found


def split_major_head(raw: str) -> tuple[str, str | None]:
    """'Murder (Sec.302/303 IPC/103,104 BNS)' -> ('Murder', 'Sec.302/303 IPC/103,104 BNS')."""
    text = re.sub(r"\s+", " ", str(raw)).strip()
    m = re.search(r"\((?=[^()]*\bSec)", text, flags=re.IGNORECASE)
    if not m:
        name, legal = text, None
    else:
        name = text[:m.start()].strip()
        legal = text[m.start():].strip().strip("()").strip() or None
    if name.isupper():
        name = name.title()
    return name or text, legal


def parse_karnataka_review(df: pd.DataFrame, file_name: str = "",
                           report_month: date | None = None) -> tuple[pd.DataFrame, list[dict]]:
    """Clean a crime-review DataFrame. Returns (clean rows, operation log)."""
    log: list[dict] = []
    cols = _match_columns(list(df.columns))
    missing = [k for k in ("head_of_crime", "major_head_raw", *COUNT_COLUMNS) if k not in cols]
    if missing:
        raise UploadError(
            "This does not look like a crime-review summary. Missing columns for: "
            + ", ".join(missing)
            + ". Expected headers such as 'Heads of Crime', 'Major Heads', 'During the current month'."
        )
    extra_cols = [c for c in df.columns if c not in cols.values()]
    data = df.rename(columns={v: k for k, v in cols.items()}).copy()
    total = len(data)
    log.append({"step": "Read file", "rows_before": total, "rows_after": total,
                "detail": f"Matched columns: {cols}"})

    # Stray values in unnamed extra columns -> flag, do not use.
    for c in extra_cols:
        stray = data[data[c].notna()]
        if len(stray):
            sl = stray["sl_no"].tolist() if "sl_no" in stray else stray.index.tolist()
            log.append({"step": "Stray values in unnamed column", "rows_before": total, "rows_after": total,
                        "detail": f"Column '{c}' has {len(stray)} value(s) on Sl.No. {sl} "
                                  f"({stray[c].tolist()}). Ignored; the four count columns are kept."})
    data = data.drop(columns=extra_cols)

    # Unlabelled rows (no head of crime / major head) cannot be attributed.
    unlabelled = data["head_of_crime"].isna() | data["major_head_raw"].isna()
    if unlabelled.any():
        dropped = data[unlabelled]
        counts = {c: int(pd.to_numeric(dropped[c], errors="coerce").fillna(0).sum()) for c in COUNT_COLUMNS}
        log.append({"step": "Excluded unlabelled rows", "rows_before": len(data),
                    "rows_after": int((~unlabelled).sum()),
                    "detail": f"{int(unlabelled.sum())} row(s) have no crime head or category, so their "
                              f"counts cannot be attributed. Their totals were: {counts}."})
    data = data[~unlabelled].copy()

    for c in COUNT_COLUMNS:
        data[c] = pd.to_numeric(data[c], errors="coerce")
    bad_counts = data[COUNT_COLUMNS].isna().any(axis=1)
    if bad_counts.any():
        log.append({"step": "Non-numeric counts set to 0", "rows_before": len(data), "rows_after": len(data),
                    "detail": f"{int(bad_counts.sum())} row(s) had blank or non-numeric counts."})
    data[COUNT_COLUMNS] = data[COUNT_COLUMNS].fillna(0).astype(int)

    split = data["major_head_raw"].map(split_major_head)
    data["major_head"] = split.map(lambda t: t[0])
    data["legal_sections"] = split.map(lambda t: t[1])
    data["major_head_raw"] = data["major_head_raw"].astype(str).str.replace(r"\s+", " ", regex=True).str.strip()
    data["head_of_crime"] = data["head_of_crime"].astype(str).str.strip()

    minor = data.get("minor_head", pd.Series(index=data.index, dtype=object))
    minor = minor.astype("object").where(minor.notna(), None)
    blank_minor = minor.isna() | minor.astype(str).str.strip().str.upper().isin(["NA", "N/A", "", "NAN", "NONE"])
    data["minor_head"] = np.where(blank_minor, data["major_head"],
                                  minor.astype(str).str.replace(r"\s+", " ", regex=True).str.strip())
    if blank_minor.any():
        log.append({"step": "Blank / NA minor heads filled", "rows_before": len(data), "rows_after": len(data),
                    "detail": f"{int(blank_minor.sum())} row(s) used the major head name as the category."})

    data["ytd_consistent"] = data["count_ytd"] == data["count_previous_month"] + data["count_current_month"]
    inconsistent = data[~data["ytd_consistent"]]
    log.append({"step": "YTD consistency check", "rows_before": len(data), "rows_after": len(data),
                "detail": f"YTD = previous month + current month for {int(data['ytd_consistent'].sum())} of "
                          f"{len(data)} rows. Mismatches kept and flagged: "
                          + "; ".join(f"{r.major_head} / {r.minor_head}" for r in inconsistent.itertuples())})

    data["sl_no"] = pd.to_numeric(data.get("sl_no"), errors="coerce").astype("Int64")
    data["report_month"] = report_month or report_month_from_filename(file_name) or date.today().replace(day=1)
    data["region"] = "Karnataka"
    keep = ["region", "report_month", "sl_no", "head_of_crime", "major_head", "major_head_raw",
            "legal_sections", "minor_head", *COUNT_COLUMNS, "ytd_consistent"]
    log.append({"step": "Saved rows", "rows_before": total, "rows_after": len(data),
                "detail": f"{total - len(data)} of {total} rows excluded in total."})
    return data[keep].reset_index(drop=True), log


# ---------------------------------------------------------------------------
# Analysis
# ---------------------------------------------------------------------------
def _pct(new: pd.Series, old: pd.Series) -> pd.Series:
    return np.where(old > 0, (new - old) / old.replace(0, np.nan) * 100, np.nan)


def add_change_metrics(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["mom_change"] = out["count_current_month"] - out["count_previous_month"]
    out["yoy_change"] = out["count_current_month"] - out["count_same_month_prev_year"]
    out["mom_pct"] = _pct(out["count_current_month"], out["count_previous_month"])
    out["yoy_pct"] = _pct(out["count_current_month"], out["count_same_month_prev_year"])
    return out


def summary_by_head(df: pd.DataFrame) -> pd.DataFrame:
    g = df.groupby("head_of_crime")[COUNT_COLUMNS].sum().reset_index()
    return add_change_metrics(g)


def major_head_totals(df: pd.DataFrame, head: str | None = None) -> pd.DataFrame:
    data = df if head is None else df[df["head_of_crime"] == head]
    g = data.groupby(["head_of_crime", "major_head"])[COUNT_COLUMNS].sum().reset_index()
    return add_change_metrics(g).sort_values("count_current_month", ascending=False)


def top_movers(df: pd.DataFrame, by: str = "yoy_change", n: int = 10, min_base: int = 5) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Largest rises and falls at major-head level (ignores tiny bases)."""
    m = major_head_totals(df)
    base_col = "count_same_month_prev_year" if by.startswith("yoy") else "count_previous_month"
    m = m[(m[base_col] >= min_base) | (m["count_current_month"] >= min_base)]
    rises = m.sort_values(by, ascending=False).head(n)
    falls = m.sort_values(by, ascending=True).head(n)
    return rises, falls
