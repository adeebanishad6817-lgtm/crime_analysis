"""Preprocessing for incident-level crime data.

``preprocess_incidents`` turns a raw uploaded DataFrame plus a column mapping
into clean rows for the ``crime_records`` table. Every step is recorded in an
operation log with row counts before and after, so nothing is discarded
silently. Rows are only *excluded* when they cannot be used at all (no crime
type, no parseable date); bad coordinates or ages are blanked, not dropped.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

import config
from modules.data_upload import load_city_coordinates

DATETIME_FORMATS = [
    "%d-%m-%Y %H:%M", "%m-%d-%Y %H:%M", "%d-%m-%Y %H:%M:%S", "%m-%d-%Y %H:%M:%S",
    "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M:%S",
    "%d/%m/%Y %H:%M", "%m/%d/%Y %H:%M", "%m/%d/%Y %I:%M:%S %p", "%d/%m/%Y %H:%M:%S",
    "%Y-%m-%d", "%d-%m-%Y", "%m-%d-%Y", "%d/%m/%Y", "%m/%d/%Y", "%d.%m.%Y",
]
TIME_FORMATS = ["%H:%M", "%H:%M:%S", "%I:%M %p", "%I:%M:%S %p"]

# Documented rule used when a dataset has no severity column.
SEVERITY_KEYWORDS: dict[str, tuple[str, ...]] = {
    "High": ("homicide", "murder", "sexual assault", "rape", "kidnap", "abduct", "firearm",
             "assault", "robbery", "arson", "domestic violence", "battery", "dacoity", "weapon"),
    "Medium": ("burglary", "theft", "stolen", "extortion", "fraud", "identity", "cyber",
               "counterfeit", "drug", "narcotic", "illegal possession", "motor vehicle"),
    "Low": ("vandalism", "shoplifting", "intoxication", "traffic", "nuisance", "trespass",
            "gambling", "criminal damage", "liquor"),
}
TIME_PERIODS = [(0, 6, "Night"), (6, 12, "Morning"), (12, 18, "Afternoon"), (18, 24, "Evening")]
AGE_BINS = [0, 18, 31, 46, 61, 200]
AGE_LABELS = ["0-17", "18-30", "31-45", "46-60", "61+"]

FIELD_TO_COLUMN = {
    "Crime_ID": "source_crime_id", "Crime_Type": "crime_type", "Location": "location",
    "Police_Station": "police_station", "Crime_Code": "crime_code", "Crime_Domain": "crime_domain",
    "Weapon_Used": "weapon_used", "Victim_Gender": "victim_gender",
}


@dataclass
class PreprocessResult:
    data: pd.DataFrame
    log: list[dict] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    rows_in: int = 0

    @property
    def rows_out(self) -> int:
        return int(len(self.data))

    @property
    def rows_excluded(self) -> int:
        return self.rows_in - self.rows_out

    @property
    def excluded_share(self) -> float:
        return self.rows_excluded / self.rows_in if self.rows_in else 0.0


class _Log:
    def __init__(self) -> None:
        self.entries: list[dict] = []

    def add(self, step: str, before: int, after: int, detail: str, changed: int | None = None) -> None:
        self.entries.append({"step": step, "rows_before": int(before), "rows_after": int(after),
                             "rows_changed": int(changed) if changed is not None else int(before - after),
                             "detail": detail})


# ---------------------------------------------------------------------------
# Date helpers
# ---------------------------------------------------------------------------
def detect_datetime(series: pd.Series, formats: list[str] = DATETIME_FORMATS) -> tuple[pd.Series, str, float]:
    """Parse with the format that fits the most values.

    Trying every candidate and keeping the best avoids the classic
    day-first / month-first confusion (e.g. '01-13-2020' can only be
    month-first). Returns (parsed, format_used, share_parsed).
    """
    s = series.copy()
    non_null = s.notna().sum()
    if non_null == 0:
        return pd.to_datetime(s, errors="coerce"), "empty", 0.0
    if pd.api.types.is_datetime64_any_dtype(s):
        return s, "native datetime", float(s.notna().sum() / non_null)
    s = s.astype(str).str.strip().replace({"": np.nan, "nan": np.nan, "NaT": np.nan, "None": np.nan})
    best, best_fmt, best_share = None, "", -1.0
    for fmt in formats:
        parsed = pd.to_datetime(s, format=fmt, errors="coerce")
        share = parsed.notna().sum() / non_null
        if share > best_share:
            best, best_fmt, best_share = parsed, fmt, share
        if share == 1.0:
            break
    if best_share < 0.9:  # last resort: let pandas infer per element
        mixed = pd.to_datetime(s, format="mixed", dayfirst=True, errors="coerce")
        share = mixed.notna().sum() / non_null
        if share > best_share:
            best, best_fmt, best_share = mixed, "mixed (inferred)", share
    return best, best_fmt, float(best_share)


def _parse_time_only(series: pd.Series) -> tuple[pd.Series, str, float]:
    s = series.astype(str).str.strip()
    non_null = series.notna().sum() or 1
    best, best_fmt, best_share = None, "", -1.0
    for fmt in TIME_FORMATS:
        parsed = pd.to_datetime(s, format=fmt, errors="coerce")
        share = parsed.notna().sum() / non_null
        if share > best_share:
            best, best_fmt, best_share = parsed, fmt, share
    return best, best_fmt, float(best_share)


def derive_severity(crime_type: str) -> str:
    text = str(crime_type).lower()
    for level in ("High", "Medium", "Low"):
        if any(k in text for k in SEVERITY_KEYWORDS[level]):
            return level
    return "Low"


def _normalise_severity(value: object) -> str | None:
    if value is None or (isinstance(value, float) and np.isnan(value)):
        return None
    v = str(value).strip().lower()
    if v in {"high", "h", "3", "severe", "critical", "major"}:
        return "High"
    if v in {"medium", "med", "m", "2", "moderate"}:
        return "Medium"
    if v in {"low", "l", "1", "minor"}:
        return "Low"
    return None


def time_period(hour: float) -> str | None:
    if pd.isna(hour):
        return None
    for start, end, label in TIME_PERIODS:
        if start <= hour < end:
            return label
    return None


# ---------------------------------------------------------------------------
# Main pipeline
# ---------------------------------------------------------------------------
def preprocess_incidents(raw: pd.DataFrame, mapping: dict[str, str | None]) -> PreprocessResult:
    log = _Log()
    warnings: list[str] = []
    rows_in = len(raw)
    col = {k: v for k, v in mapping.items() if v}

    # 1. Keep only mapped columns, drop exact duplicate rows ---------------
    df = raw.copy()
    n = len(df)
    df = df.drop_duplicates()
    log.add("Remove exact duplicate rows", n, len(df), f"{n - len(df)} identical row(s) removed.")

    out = pd.DataFrame(index=df.index)
    for field_name, target in FIELD_TO_COLUMN.items():
        if field_name in col:
            out[target] = df[col[field_name]].astype("object").where(df[col[field_name]].notna(), None)

    # 2. Duplicate IDs ------------------------------------------------------
    if "source_crime_id" in out:
        out["source_crime_id"] = out["source_crime_id"].map(lambda v: None if v is None else str(v).strip())
        dup = out["source_crime_id"].notna() & out["source_crime_id"].duplicated(keep="first")
        n = len(out)
        out, df = out[~dup], df[~dup]
        log.add("Remove duplicate Crime_ID", n, len(out),
                f"{int(dup.sum())} row(s) repeated an existing Crime_ID; first occurrence kept.")

    # 3. Crime type ---------------------------------------------------------
    ct = out["crime_type"].map(lambda v: None if v is None else re.sub(r"\s+", " ", str(v)).strip())
    ct = ct.where(ct.astype(str).str.len() > 0, None)
    missing_ct = ct.isna()
    n = len(out)
    out["crime_type"] = ct.str.title() if hasattr(ct, "str") else ct
    out, df = out[~missing_ct], df[~missing_ct]
    log.add("Exclude rows with no crime type", n, len(out), f"{int(missing_ct.sum())} row(s) had a blank crime type.")
    log.add("Standardise crime categories", len(out), len(out),
            f"Trimmed spaces and applied Title Case: {out['crime_type'].nunique()} distinct categories.", changed=0)

    # 4. Occurrence date-time -------------------------------------------------
    date_parsed, date_fmt, date_share = detect_datetime(df[col["Date"]])
    occurred = date_parsed
    hour_reliable = True
    time_note = ""
    if "Time" in col and col["Time"] != col["Date"]:
        full, full_fmt, full_share = detect_datetime(df[col["Time"]])
        if full_share >= 0.9 and full_fmt not in ("%Y-%m-%d", "%d-%m-%Y", "%m-%d-%Y", "%d/%m/%Y", "%m/%d/%Y", "%d.%m.%Y"):
            # Date column supplies the calendar date, Time column the clock time.
            occurred = date_parsed.dt.normalize() + (full - full.dt.normalize())
            differ = int((full.dt.normalize() != date_parsed.dt.normalize()).sum())
            time_note = (f"Date column '{col['Date']}' parsed as {date_fmt}; time column '{col['Time']}' holds "
                         f"full date-times ({full_fmt}), so only its clock time was used. In {differ} row(s) the "
                         f"time column's own date differed from the date column (date column kept).")
        else:
            t, t_fmt, t_share = _parse_time_only(df[col["Time"]])
            if t_share >= 0.5:
                occurred = date_parsed.dt.normalize() + (t - t.dt.normalize())
                time_note = f"Combined date ({date_fmt}) with time ({t_fmt})."
            else:
                time_note = f"Time column could not be parsed ({t_share:.0%}); date only used."
    else:
        time_note = f"Date format detected: {date_fmt} ({date_share:.1%} parsed)."
    if occurred.notna().any() and (occurred.dropna().dt.hour == 0).all() and (occurred.dropna().dt.minute == 0).all():
        hour_reliable = False
        warnings.append("All timestamps are at midnight, so hour-of-day analysis is not meaningful for this dataset.")
    bad_date = occurred.isna()
    n = len(out)
    out["occurred_at"] = occurred
    out, df = out[~bad_date], df[~bad_date]
    log.add("Parse occurrence date-time", n, len(out),
            f"{int(bad_date.sum())} row(s) with missing or invalid dates excluded. {time_note}")

    # 5. Coordinates / location ----------------------------------------------
    if "location" in out:
        out["location"] = out["location"].map(
            lambda v: None if v is None else re.sub(r"\s+", " ", str(v)).strip().title())
    if "Latitude" in col and "Longitude" in col:
        lat = pd.to_numeric(df[col["Latitude"]], errors="coerce")
        lon = pd.to_numeric(df[col["Longitude"]], errors="coerce")
        invalid = lat.isna() | lon.isna() | ~lat.between(-90, 90) | ~lon.between(-180, 180) | ((lat == 0) & (lon == 0))
        out["latitude"] = lat.where(~invalid)
        out["longitude"] = lon.where(~invalid)
        out["coord_source"] = np.where(invalid, None, "record")
        log.add("Validate coordinates", len(out), len(out),
                f"{int(invalid.sum())} row(s) had missing, (0,0) or out-of-range coordinates; set to blank and "
                f"kept for non-map analysis.", changed=int(invalid.sum()))
    elif "location" in out:
        ref = load_city_coordinates().drop_duplicates("city_key").set_index("city_key")
        key = out["location"].astype(str).str.lower()
        out["latitude"] = key.map(ref["latitude"])
        out["longitude"] = key.map(ref["longitude"])
        matched = out["latitude"].notna()
        out["coord_source"] = np.where(matched, "city_centroid", None)
        unmatched = sorted(out.loc[~matched, "location"].dropna().unique().tolist())
        log.add("Assign approximate city coordinates", len(out), len(out),
                f"No coordinate columns. {int(matched.sum())} row(s) matched a city-centre coordinate from "
                f"data/reference/india_city_coordinates.csv; {int((~matched).sum())} unmatched"
                + (f" (cities: {unmatched[:20]})" if unmatched else "") + ".", changed=int(matched.sum()))
        if unmatched:
            warnings.append(f"{len(unmatched)} location name(s) are not in the city reference table and will not "
                            f"appear on maps: {', '.join(unmatched[:10])}. Add them to the reference CSV.")
    else:
        out["latitude"] = np.nan
        out["longitude"] = np.nan
        out["coord_source"] = None

    # 6. Severity -------------------------------------------------------------
    if "Severity" in col:
        sev = df[col["Severity"]].map(_normalise_severity)
        unknown = sev.isna()
        out["severity"] = sev.where(~unknown, out["crime_type"].map(derive_severity))
        log.add("Standardise severity", len(out), len(out),
                f"{int(unknown.sum())} unrecognised severity value(s) replaced by the crime-type rule.",
                changed=int(unknown.sum()))
    else:
        out["severity"] = out["crime_type"].map(derive_severity)
        rule = {t: derive_severity(t) for t in sorted(out["crime_type"].unique())}
        log.add("Derive severity from crime type", len(out), len(out),
                f"No severity column; derived with the documented keyword rule: {rule}", changed=len(out))

    # 7. Optional fields --------------------------------------------------------
    if "Date_Reported" in col:
        rep, rep_fmt, _ = detect_datetime(df[col["Date_Reported"]])
        out["date_reported"] = rep
        log.add("Parse reported date", len(out), len(out),
                f"Format {rep_fmt}; {int(rep.isna().sum())} blank/invalid.", changed=0)
    if "Victim_Age" in col:
        age = pd.to_numeric(df[col["Victim_Age"]], errors="coerce")
        bad_age = age.notna() & ~age.between(0, 110)
        age = age.where(~bad_age)
        out["victim_age"] = age.round().astype("Int64")
        valid_share = age.notna().mean()
        if valid_share >= 0.5:
            out["age_group"] = pd.cut(age, bins=AGE_BINS, labels=AGE_LABELS, right=False).astype("object")
            out["age_group"] = out["age_group"].where(age.notna(), None)
        log.add("Validate victim age", len(out), len(out),
                f"{int(bad_age.sum())} out-of-range age(s) blanked; {valid_share:.1%} valid. "
                + ("Age groups created." if valid_share >= 0.5 else "Too few valid ages: age groups skipped."),
                changed=int(bad_age.sum()))
    if "victim_gender" in out:
        gmap = {"m": "Male", "male": "Male", "f": "Female", "female": "Female",
                "x": "Other", "o": "Other", "other": "Other"}
        out["victim_gender"] = out["victim_gender"].map(
            lambda v: None if v is None else gmap.get(str(v).strip().lower(), "Unknown"))
    if "Police_Deployed" in col:
        pdp = pd.to_numeric(df[col["Police_Deployed"]], errors="coerce")
        out["police_deployed"] = pdp.where(pdp >= 0).round().astype("Int64")
    if "Case_Closed" in col:
        out["case_closed"] = df[col["Case_Closed"]].map(
            lambda v: None if pd.isna(v) else str(v).strip().lower() in {"yes", "y", "true", "1", "closed"})
    if "Date_Case_Closed" in col:
        closed, closed_fmt, _ = detect_datetime(df[col["Date_Case_Closed"]])
        out["date_case_closed"] = closed
        base = out["date_reported"] if "date_reported" in out else out["occurred_at"]
        days = (closed - base).dt.total_seconds() / 86400
        negative = days < 0
        out["resolution_days"] = days.where(~negative)
        log.add("Compute case resolution time", len(out), len(out),
                f"Closure date format {closed_fmt}; {int(closed.notna().sum())} closed cases; "
                f"{int(negative.sum())} negative durations blanked.", changed=int(negative.sum()))

    # 8. Outlier inspection (report only, nothing removed) ----------------------
    notes = []
    if "date_reported" in out:
        delay_h = (out["date_reported"] - out["occurred_at"]).dt.total_seconds() / 3600
        notes.append(f"report delay median {delay_h.median():.1f} h, {int((delay_h < 0).sum())} reported before occurrence")
    for c in ("victim_age", "police_deployed", "resolution_days"):
        if c in out:
            s = pd.to_numeric(out[c], errors="coerce").dropna()
            if len(s) > 10:
                q1, q3 = s.quantile([0.25, 0.75])
                iqr = q3 - q1
                k = int(((s < q1 - 1.5 * iqr) | (s > q3 + 1.5 * iqr)).sum())
                notes.append(f"{c}: {k} IQR outlier(s)")
    log.add("Outlier inspection (no rows removed)", len(out), len(out), "; ".join(notes) or "No numeric fields.", changed=0)

    # 9. Feature engineering -----------------------------------------------------
    ts = out["occurred_at"]
    out["year"] = ts.dt.year
    out["month"] = ts.dt.month
    out["day"] = ts.dt.day
    out["hour"] = ts.dt.hour if hour_reliable else np.nan
    out["day_of_week"] = ts.dt.dayofweek
    out["is_weekend"] = out["day_of_week"] >= 5
    out["time_period"] = out["hour"].map(time_period)
    log.add("Feature engineering", len(out), len(out),
            "Added year, month, day, hour, day_of_week, is_weekend, time_period"
            + (", age_group" if "age_group" in out else "") + ".", changed=0)

    result = PreprocessResult(data=out.reset_index(drop=True), log=log.entries, warnings=warnings, rows_in=rows_in)
    if result.excluded_share > config.EXCLUSION_WARNING_SHARE:
        result.warnings.insert(0, f"{result.rows_excluded} of {rows_in} rows ({result.excluded_share:.1%}) would be "
                                  f"excluded. Check the column mapping and date formats before saving.")
    result.log.append({"step": "Summary", "rows_before": rows_in, "rows_after": result.rows_out,
                       "rows_changed": result.rows_excluded,
                       "detail": f"{result.rows_out} rows ready to save, {result.rows_excluded} excluded."})
    return result
