"""Isolation Forest on *aggregated* crime activity.

The model looks for unusual periods (weeks or months) in counts, not unusual
individual records. A flagged period means "aggregate activity in this period
was unlike most other periods" - it says nothing about any person or case.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

import config

FREQ_LABELS = {"W": "week", "M": "month"}


@dataclass
class AnomalyResult:
    table: pd.DataFrame
    params: dict
    notes: list[str] = field(default_factory=list)

    @property
    def n_anomalies(self) -> int:
        return int(self.table["is_anomaly"].sum()) if not self.table.empty else 0


def _period_index(ts: pd.Series, freq: str) -> pd.Series:
    return ts.dt.to_period("W-SUN" if freq == "W" else "M").dt.start_time


def build_period_features(df: pd.DataFrame, freq: str = "W", group_col: str | None = None) -> tuple[pd.DataFrame, list[str]]:
    """Counts per period (and per group) with derived features.

    Incomplete first/last periods are removed so that a partial week at the
    edge of the data is not mistaken for a sudden drop.
    """
    notes: list[str] = []
    if df.empty:
        return pd.DataFrame(), ["No data for the selected filters."]
    data = df[["occurred_at", "severity"] + ([group_col] if group_col else [])].copy()
    data["period"] = _period_index(data["occurred_at"], freq)
    first, last = data["occurred_at"].min(), data["occurred_at"].max()
    periods = pd.Series(sorted(data["period"].unique()))
    step = pd.Timedelta(days=7) if freq == "W" else None
    drop = []
    if len(periods):
        p0 = periods.iloc[0]
        if first.normalize() > p0:
            drop.append(p0)
        p_last = periods.iloc[-1]
        period_end = p_last + step if step is not None else p_last + pd.offsets.MonthBegin(1)
        if last.normalize() + pd.Timedelta(days=1) < period_end:
            drop.append(p_last)
    if drop:
        data = data[~data["period"].isin(drop)]
        notes.append(f"Removed {len(drop)} incomplete edge {FREQ_LABELS[freq]}(s) at the start/end of the data.")
    keys = ["period"] + ([group_col] if group_col else [])
    g = data.groupby(keys).agg(count=("severity", "size"),
                               high_share=("severity", lambda s: (s == "High").mean())).reset_index()
    # Fill periods with zero incidents so gaps are visible.
    all_periods = pd.Index(sorted(data["period"].unique()), name="period")
    if group_col:
        full = pd.MultiIndex.from_product([all_periods, sorted(data[group_col].dropna().unique())], names=keys)
        g = g.set_index(keys).reindex(full).reset_index()
    else:
        g = g.set_index("period").reindex(all_periods).reset_index()
    g["count"] = g["count"].fillna(0)
    g["high_share"] = g["high_share"].fillna(0)
    grouped = g.groupby(group_col) if group_col else [(None, g)]
    parts = []
    for _, part in grouped:
        part = part.sort_values("period").copy()
        part["change"] = part["count"].diff().fillna(0)
        rolling = part["count"].shift(1).rolling(4, min_periods=2).mean()
        part["expected"] = rolling.fillna(part["count"].expanding().mean())
        part["deviation"] = part["count"] - part["expected"]
        parts.append(part)
    return pd.concat(parts, ignore_index=True), notes


def detect_activity_anomalies(df: pd.DataFrame, freq: str = "W", group_col: str | None = None,
                              contamination: float = config.ISOLATION_DEFAULT_CONTAMINATION) -> AnomalyResult:
    params = {"freq": freq, "group_col": group_col, "contamination": contamination,
              "features": ["count", "change", "deviation", "high_share"], "random_state": config.RANDOM_STATE}
    feats, notes = build_period_features(df, freq, group_col)
    if feats.empty or len(feats) < 10:
        notes.append("Fewer than 10 periods available: anomaly detection needs more history.")
        return AnomalyResult(pd.DataFrame(columns=["period", "count", "is_anomaly", "score"]), params, notes)
    cols = ["count", "change", "deviation", "high_share"]
    X = feats[cols].astype(float)
    if group_col:  # standardise within each group so big cities do not dominate
        X = feats.groupby(group_col)[cols].transform(lambda s: (s - s.mean()) / (s.std(ddof=0) or 1.0))
    else:
        X = (X - X.mean()) / X.std(ddof=0).replace(0, 1.0)
    if float(feats["count"].std(ddof=0)) == 0.0:
        notes.append(f"Every {FREQ_LABELS[freq]} has exactly the same incident count "
                     f"({int(feats['count'].iloc[0])}), so overall volume shows no variation to analyse. "
                     f"Try grouping by category or location.")
        feats["score"] = 0.0
        feats["is_anomaly"] = False
        return AnomalyResult(feats, params, notes)
    model = IsolationForest(n_estimators=200, contamination=contamination, random_state=config.RANDOM_STATE)
    model.fit(X.to_numpy())
    feats["score"] = -model.score_samples(X.to_numpy())   # higher = more unusual
    feats["is_anomaly"] = model.predict(X.to_numpy()) == -1
    feats["direction"] = np.where(feats["deviation"] >= 0, "higher than recent average",
                                  "lower than recent average")
    return AnomalyResult(feats, params, notes)


def aggregate_category_anomalies(stats: pd.DataFrame, contamination: float = 0.05) -> pd.DataFrame:
    """Flag categories with unusual month-on-month / year-on-year movement.

    Works on the Karnataka aggregate table after ``add_change_metrics``.
    """
    data = stats.copy()
    data = data[(data["count_current_month"] + data["count_previous_month"] + data["count_same_month_prev_year"]) > 0]
    if len(data) < 10:
        return data.assign(is_anomaly=False, score=0.0)
    X = np.column_stack([
        np.log1p(data["count_current_month"]),
        np.clip(np.nan_to_num(data["mom_pct"].astype(float), nan=0.0), -200, 500) / 100,
        np.clip(np.nan_to_num(data["yoy_pct"].astype(float), nan=0.0), -200, 500) / 100,
        np.sign(data["yoy_change"]) * np.log1p(np.abs(data["yoy_change"])),
    ])
    model = IsolationForest(n_estimators=200, contamination=contamination, random_state=config.RANDOM_STATE)
    model.fit(X)
    data["score"] = -model.score_samples(X)
    data["is_anomaly"] = model.predict(X) == -1
    return data.sort_values("score", ascending=False)
