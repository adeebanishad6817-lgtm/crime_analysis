"""Geographic hotspot detection with DBSCAN and the haversine metric.

How it works
------------
1. Incidents are grouped into unique (latitude, longitude) locations, each
   carrying its incident count as a weight. With exact incident coordinates
   this is (almost) one point per incident; with city-centre coordinates it is
   one point per city.
2. Coordinates are converted to radians and clustered with scikit-learn's
   DBSCAN using ``metric="haversine"`` (great-circle distance on a sphere).
   Haversine works in radians, so ``eps`` in kilometres is divided by the
   Earth's radius (6371 km).
3. ``sample_weight`` makes ``min_samples`` count *incidents*, not locations:
   a location is a core point when the incidents within ``eps`` km of it
   (including its own) reach ``min_samples``.
4. Points not reachable from any core point get label -1 (noise).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from sklearn.cluster import DBSCAN
from sklearn.neighbors import BallTree

import config


@dataclass
class DBSCANResult:
    points: pd.DataFrame            # one row per location, with 'cluster'
    clusters: pd.DataFrame          # one row per cluster, ranked
    incidents_with_labels: pd.DataFrame
    params: dict
    notes: list[str] = field(default_factory=list)

    @property
    def n_clusters(self) -> int:
        return int(len(self.clusters))

    @property
    def noise_incidents(self) -> int:
        return int(self.points.loc[self.points["cluster"] == -1, "incident_count"].sum())

    @property
    def noise_locations(self) -> int:
        return int((self.points["cluster"] == -1).sum())

    @property
    def clustered_incidents(self) -> int:
        return int(self.points.loc[self.points["cluster"] >= 0, "incident_count"].sum())


def haversine_km(lat1, lon1, lat2, lon2):
    """Great-circle distance in km (vectorised)."""
    lat1, lon1, lat2, lon2 = map(np.radians, (lat1, lon1, lat2, lon2))
    a = np.sin((lat2 - lat1) / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1) / 2) ** 2
    return 2 * config.EARTH_RADIUS_KM * np.arcsin(np.sqrt(np.clip(a, 0, 1)))


def spherical_centroid(lat: np.ndarray, lon: np.ndarray, weights: np.ndarray) -> tuple[float, float]:
    """Weighted centroid computed on the sphere (via 3-D unit vectors)."""
    la, lo = np.radians(lat), np.radians(lon)
    x = np.average(np.cos(la) * np.cos(lo), weights=weights)
    y = np.average(np.cos(la) * np.sin(lo), weights=weights)
    z = np.average(np.sin(la), weights=weights)
    return float(np.degrees(np.arctan2(z, np.hypot(x, y)))), float(np.degrees(np.arctan2(y, x)))


def prepare_locations(df: pd.DataFrame, max_points: int = config.DBSCAN_MAX_POINTS) -> tuple[pd.DataFrame, list[str]]:
    """Aggregate incidents to weighted unique locations."""
    notes: list[str] = []
    geo = df.dropna(subset=["latitude", "longitude"]).copy()
    skipped = len(df) - len(geo)
    if skipped:
        notes.append(f"{skipped} incident(s) without coordinates were left out of clustering.")
    if geo.empty:
        return pd.DataFrame(columns=["latitude", "longitude", "incident_count", "location"]), notes
    geo["latitude"] = geo["latitude"].astype(float).round(5)
    geo["longitude"] = geo["longitude"].astype(float).round(5)
    agg = {"incident_count": ("crime_type", "size")}
    if "location" in geo:
        agg["location"] = ("location", lambda s: s.mode().iat[0] if s.notna().any() else None)
    points = geo.groupby(["latitude", "longitude"]).agg(**agg).reset_index()
    if len(points) > max_points:
        before = len(points)
        points = points.sample(n=max_points, weights="incident_count", random_state=config.RANDOM_STATE)
        notes.append(f"{before} unique locations exceeded the limit of {max_points}; a weighted random sample "
                     f"(seed {config.RANDOM_STATE}) was clustered.")
    if "location" not in points:
        points["location"] = None
    return points.reset_index(drop=True), notes


def k_distance(points: pd.DataFrame, k: int) -> np.ndarray:
    """Sorted distance (km) from each location to its k-th nearest neighbour.

    The 'elbow' of this curve is a common heuristic for choosing eps.
    """
    if len(points) <= 1:
        return np.array([])
    k = max(1, min(k, len(points) - 1))
    tree = BallTree(np.radians(points[["latitude", "longitude"]].to_numpy()), metric="haversine")
    dist, _ = tree.query(np.radians(points[["latitude", "longitude"]].to_numpy()), k=k + 1)
    return np.sort(dist[:, -1] * config.EARTH_RADIUS_KM)


def run_dbscan(df: pd.DataFrame, eps_km: float = config.DBSCAN_DEFAULT_EPS_KM,
               min_samples: int = config.DBSCAN_DEFAULT_MIN_SAMPLES, weighted: bool = True) -> DBSCANResult:
    if eps_km <= 0 or min_samples < 1:
        raise ValueError("eps_km must be > 0 and min_samples must be >= 1.")
    points, notes = prepare_locations(df)
    params = {"eps_km": float(eps_km), "min_samples": int(min_samples), "weighted": bool(weighted),
              "metric": "haversine", "algorithm": "ball_tree", "earth_radius_km": config.EARTH_RADIUS_KM,
              "eps_radians": float(eps_km / config.EARTH_RADIUS_KM)}
    if points.empty:
        empty = pd.DataFrame(columns=["cluster_label", "rank", "incident_count"])
        notes.append("No incidents with coordinates match the current filters.")
        return DBSCANResult(points.assign(cluster=pd.Series(dtype=int)), empty, df.iloc[0:0], params, notes)

    coords = np.radians(points[["latitude", "longitude"]].to_numpy())
    model = DBSCAN(eps=eps_km / config.EARTH_RADIUS_KM, min_samples=min_samples,
                   metric="haversine", algorithm="ball_tree")
    model.fit(coords, sample_weight=points["incident_count"].to_numpy() if weighted else None)
    points["cluster"] = model.labels_
    points["is_core"] = False
    points.loc[model.core_sample_indices_, "is_core"] = True

    geo = df.dropna(subset=["latitude", "longitude"]).copy()
    geo["latitude"] = geo["latitude"].astype(float).round(5)
    geo["longitude"] = geo["longitude"].astype(float).round(5)
    labelled = geo.merge(points[["latitude", "longitude", "cluster"]], on=["latitude", "longitude"], how="left")
    labelled["cluster"] = labelled["cluster"].fillna(-1).astype(int)
    clusters = summarise_clusters(points, labelled)
    if clusters.empty:
        notes.append("No clusters found: every location is noise. Increase eps or lower min_samples.")
    elif (points["cluster"] >= 0).all():
        notes.append("Every location joined a cluster (no noise). Lower eps or raise min_samples to be stricter.")
    return DBSCANResult(points, clusters, labelled, params, notes)


def summarise_clusters(points: pd.DataFrame, labelled: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for label, grp in points[points["cluster"] >= 0].groupby("cluster"):
        w = grp["incident_count"].to_numpy(dtype=float)
        clat, clon = spherical_centroid(grp["latitude"].to_numpy(), grp["longitude"].to_numpy(), w)
        radius = float(np.max(haversine_km(clat, clon, grp["latitude"].to_numpy(), grp["longitude"].to_numpy())))
        inc = labelled[labelled["cluster"] == label]
        names = grp.sort_values("incident_count", ascending=False)["location"].dropna().astype(str).tolist()
        rows.append({
            "cluster_label": int(label),
            "incident_count": int(w.sum()),
            "location_count": int(len(grp)),
            "centroid_lat": round(clat, 6),
            "centroid_lon": round(clon, 6),
            "radius_km": round(radius, 3),
            "member_locations": ", ".join(dict.fromkeys(names)) or None,
            "top_crime_type": inc["crime_type"].mode().iat[0] if len(inc) else None,
            "high_severity_share": float((inc["severity"] == "High").mean()) if "severity" in inc and len(inc) else None,
            "first_incident": inc["occurred_at"].min() if "occurred_at" in inc and len(inc) else None,
            "last_incident": inc["occurred_at"].max() if "occurred_at" in inc and len(inc) else None,
        })
    clusters = pd.DataFrame(rows)
    if clusters.empty:
        return pd.DataFrame(columns=["rank", "cluster_label", "incident_count", "location_count", "centroid_lat",
                                     "centroid_lon", "radius_km", "member_locations", "top_crime_type",
                                     "high_severity_share", "first_incident", "last_incident"])
    clusters = clusters.sort_values(["incident_count", "high_severity_share"], ascending=[False, False])
    clusters.insert(0, "rank", range(1, len(clusters) + 1))
    return clusters.reset_index(drop=True)


def location_ranking(df: pd.DataFrame, top_n: int = 20) -> pd.DataFrame:
    """Simple incident-count ranking of locations (independent of DBSCAN)."""
    if df.empty or "location" not in df:
        return pd.DataFrame(columns=["location", "incidents", "share_pct", "high_severity_pct"])
    g = df.groupby("location").agg(incidents=("crime_type", "size"),
                                   high_severity_pct=("severity", lambda s: (s == "High").mean() * 100))
    g["share_pct"] = g["incidents"] / g["incidents"].sum() * 100
    return g.sort_values("incidents", ascending=False).head(top_n).reset_index()[
        ["location", "incidents", "share_pct", "high_severity_pct"]]
