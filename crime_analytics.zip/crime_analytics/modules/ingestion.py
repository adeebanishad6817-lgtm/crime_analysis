"""Save validated datasets to PostgreSQL (used by the UI and by scripts).

Each save is one transaction: the upload row, all records and the final
status are committed together, or nothing is written.
"""
from __future__ import annotations

from dataclasses import dataclass

import pandas as pd

from database import models
from database.connection import transaction
from modules.karnataka_stats import parse_karnataka_review
from modules.preprocessing import PreprocessResult, preprocess_incidents


@dataclass
class SaveOutcome:
    upload_id: int
    rows_received: int
    rows_saved: int
    rows_excluded: int
    log: list
    warnings: list


def save_incident_dataset(raw: pd.DataFrame, mapping: dict, *, file_name: str, user_id: int | None,
                          source_name: str | None = None, source_note: str | None = None,
                          is_synthetic: bool = False, result: PreprocessResult | None = None,
                          url: str | None = None) -> SaveOutcome:
    result = result or preprocess_incidents(raw, mapping)
    with transaction(url) as conn:
        upload_id = models.create_upload(
            conn, file_name=file_name, dataset_type="incidents", uploaded_by=user_id, source_name=source_name,
            source_note=source_note, is_synthetic=is_synthetic, column_mapping=mapping, rows_received=len(raw))
        saved = models.insert_crime_records(conn, upload_id, result.data)
        models.finalize_upload(conn, upload_id, status="completed", rows_saved=saved,
                               rows_excluded=len(raw) - saved,
                               preprocessing_log={"steps": result.log, "warnings": result.warnings})
    return SaveOutcome(upload_id, len(raw), saved, len(raw) - saved, result.log, result.warnings)


def save_aggregate_dataset(raw: pd.DataFrame, *, file_name: str, user_id: int | None,
                           source_name: str | None = None, source_note: str | None = None,
                           url: str | None = None) -> SaveOutcome:
    clean, log = parse_karnataka_review(raw, file_name)
    with transaction(url) as conn:
        upload_id = models.create_upload(
            conn, file_name=file_name, dataset_type="aggregate", uploaded_by=user_id, source_name=source_name,
            source_note=source_note, is_synthetic=False, rows_received=len(raw))
        saved = models.insert_aggregate_stats(conn, upload_id, clean)
        models.finalize_upload(conn, upload_id, status="completed", rows_saved=saved,
                               rows_excluded=len(raw) - saved, preprocessing_log={"steps": log, "warnings": []})
    return SaveOutcome(upload_id, len(raw), saved, len(raw) - saved, log, [])
