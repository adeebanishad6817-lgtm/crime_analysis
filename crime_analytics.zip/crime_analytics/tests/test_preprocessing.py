"""Preprocessing: cleaning, date handling, coordinates, features and the operation log."""
import pandas as pd
import pytest

from modules.data_upload import read_uploaded_file, suggest_mapping
from modules.preprocessing import derive_severity, detect_datetime, preprocess_incidents, time_period


def run(samples, name):
    df = read_uploaded_file(samples / name)
    return df, preprocess_incidents(df, suggest_mapping(list(df.columns)))


def step(result, name):
    return next(e for e in result.log if e["step"] == name)


def test_valid_file_keeps_every_row(samples):
    raw, r = run(samples, "valid_incidents.csv")
    assert r.rows_out == len(raw) == 195
    assert r.rows_excluded == 0
    assert r.data["latitude"].notna().all()


def test_duplicates_removed_and_logged(samples):
    _, r = run(samples, "duplicates.csv")
    assert step(r, "Remove exact duplicate rows")["rows_changed"] == 10
    assert step(r, "Remove duplicate Crime_ID")["rows_changed"] == 5
    assert r.rows_out == 30
    assert r.data["source_crime_id"].is_unique


def test_missing_values_handled(samples):
    _, r = run(samples, "missing_values.csv")
    assert step(r, "Exclude rows with no crime type")["rows_changed"] == 5
    assert step(r, "Parse occurrence date-time")["rows_changed"] == 5
    assert r.rows_out == 30
    # Blank severity replaced by the documented rule, not dropped
    assert r.data["severity"].isin(["High", "Medium", "Low"]).all()


def test_invalid_coordinates_blanked_not_dropped(samples):
    raw, r = run(samples, "invalid_coordinates.csv")
    assert r.rows_out == len(raw)                      # nothing silently discarded
    assert r.data["latitude"].isna().sum() == 5
    assert step(r, "Validate coordinates")["rows_changed"] == 5
    assert r.data["latitude"].dropna().between(-90, 90).all()


def test_month_first_dates_detected():
    parsed, fmt, share = detect_datetime(pd.Series(["01-13-2020 00:00", "02-28-2020 05:00"]))
    assert fmt == "%m-%d-%Y %H:%M" and share == 1.0
    assert parsed.iloc[0] == pd.Timestamp("2020-01-13")


def test_day_first_dates_detected():
    _, fmt, _ = detect_datetime(pd.Series(["31-01-2020 10:00", "13-02-2020 11:30"]))
    assert fmt == "%d-%m-%Y %H:%M"


def test_city_level_dataset_uses_reference_coordinates(samples):
    _, r = run(samples, "city_level_incidents.csv")
    assert (r.data["coord_source"] == "city_centroid").sum() == 7
    atlantis = r.data[r.data["location"] == "Atlantis"]
    assert atlantis["latitude"].isna().all()           # unknown city kept, just not mapped
    assert any("Atlantis" in w for w in r.warnings)
    # Date from the date column, clock time from the time column
    assert r.data["occurred_at"].iloc[0] == pd.Timestamp("2020-01-13 08:43")


def test_feature_engineering(samples):
    _, r = run(samples, "valid_incidents.csv")
    d = r.data
    for col in ("year", "month", "day", "hour", "day_of_week", "is_weekend", "time_period"):
        assert col in d and d[col].notna().all()
    assert (d["is_weekend"] == (d["day_of_week"] >= 5)).all()
    assert d["hour"].between(0, 23).all()


def test_time_period_boundaries():
    assert [time_period(h) for h in (0, 5, 6, 11, 12, 17, 18, 23)] == \
        ["Night", "Night", "Morning", "Morning", "Afternoon", "Afternoon", "Evening", "Evening"]


@pytest.mark.parametrize("crime,level", [("HOMICIDE", "High"), ("Identity Theft", "Medium"),
                                         ("Shoplifting", "Low"), ("Something new", "Low")])
def test_derived_severity(crime, level):
    assert derive_severity(crime) == level


def test_large_exclusion_triggers_warning():
    raw = pd.DataFrame({"Crime_Type": ["Theft"] * 10, "Date": ["not a date"] * 8 + ["01-01-2024", "02-01-2024"]})
    r = preprocess_incidents(raw, {"Crime_Type": "Crime_Type", "Date": "Date"})
    assert r.rows_out == 2
    assert r.warnings and "would be excluded" in r.warnings[0]


def test_age_groups_created_when_age_reliable():
    raw = pd.DataFrame({"Crime_Type": ["Theft"] * 4, "Date": ["01-01-2024"] * 4, "Victim_Age": [10, 25, 50, 150]})
    r = preprocess_incidents(raw, {"Crime_Type": "Crime_Type", "Date": "Date", "Victim_Age": "Victim_Age"})
    assert r.data["age_group"].tolist()[:3] == ["0-17", "18-30", "46-60"]
    assert pd.isna(r.data["victim_age"].iloc[3])       # 150 is out of range -> blanked


def test_log_records_every_step_with_counts(samples):
    _, r = run(samples, "valid_incidents.csv")
    assert all({"step", "rows_before", "rows_after", "detail"} <= set(e) for e in r.log)
    assert r.log[-1]["step"] == "Summary"
