"""Upload validation and column mapping."""
import pandas as pd
import pytest

from modules.data_upload import (UploadError, detect_dataset_type, detect_personal_data_columns, profile_dataframe,
                                 read_uploaded_file, suggest_mapping, validate_mapping)


def test_valid_csv_upload(samples):
    df = read_uploaded_file(samples / "valid_incidents.csv")
    assert len(df) == 195
    assert detect_dataset_type(df) == "incidents"


def test_valid_excel_upload(samples):
    df = read_uploaded_file(samples / "valid_incidents.xlsx")
    assert len(df) == 50 and "Crime_Type" in df.columns


def test_invalid_file_type_rejected(samples):
    with pytest.raises(UploadError, match="Unsupported file type"):
        read_uploaded_file(samples / "invalid_file.txt")


def test_empty_file_rejected(samples):
    with pytest.raises(UploadError, match="no data rows"):
        read_uploaded_file(samples / "empty.csv")
    with pytest.raises(UploadError, match="empty"):
        read_uploaded_file(b"", "x.csv")


def test_missing_required_columns_give_clear_errors(samples):
    df = read_uploaded_file(samples / "missing_columns.csv")
    errors, _ = validate_mapping(suggest_mapping(list(df.columns)), df)
    assert any("Crime_Type" in e for e in errors)
    assert any("Date" in e for e in errors)
    assert all("upload it again" in e or "Pick the column" in e for e in errors)


def test_mapping_suggestion_for_project_dataset_headers():
    cols = ["Report Number", "Date Reported", "Date of Occurrence", "Time of Occurrence", "City",
            "Crime Code", "Crime Description", "Victim Age", "Victim Gender", "Weapon Used"]
    m = suggest_mapping(cols)
    assert m["Crime_ID"] == "Report Number"
    assert m["Crime_Type"] == "Crime Description"
    assert m["Date"] == "Date of Occurrence"
    assert m["Time"] == "Time of Occurrence"
    assert m["Location"] == "City"
    assert m["Latitude"] is None


def test_city_only_mapping_warns_not_errors(samples):
    df = read_uploaded_file(samples / "city_level_incidents.csv")
    errors, warnings = validate_mapping(suggest_mapping(list(df.columns)), df)
    assert errors == []
    assert any("city-centre" in w for w in warnings)


def test_half_mapped_coordinates_is_error(valid_df):
    m = suggest_mapping(list(valid_df.columns))
    m["Longitude"] = None
    errors, _ = validate_mapping(m, valid_df)
    assert any("both Latitude and Longitude" in e for e in errors)


def test_personal_data_columns_detected():
    assert detect_personal_data_columns(["Victim Name", "Phone", "City", "Aadhaar No"]) == ["Victim Name", "Phone", "Aadhaar No"]


def test_profile_counts_missing_and_duplicates(samples):
    df = read_uploaded_file(samples / "duplicates.csv")
    p = profile_dataframe(df)
    assert p["duplicate_rows"] == 10
    mv = profile_dataframe(read_uploaded_file(samples / "missing_values.csv"))
    assert mv["missing_by_column"]["Crime_Type"] == 5


def test_aggregate_type_detected():
    df = pd.DataFrame({"Sl.No.": [1], "Heads of Crime": ["A"], "Major Heads": ["M"], "During the current month": [1]})
    assert detect_dataset_type(df) == "aggregate"
