"""Database connectivity and persistence, authentication, and CSV/PDF exports."""
import pandas as pd
import pytest

from database import models
from database.connection import check_connection, get_connection, transaction
from modules import authentication as auth
from modules import crime_analysis as ca
from modules import report_generation as rg
from modules.data_upload import read_uploaded_file, suggest_mapping
from modules.hotspot_detection import run_dbscan
from modules.ingestion import save_incident_dataset


# --- database ---------------------------------------------------------------------------
def test_database_connectivity(db_url):
    ok, msg = check_connection(db_url)
    assert ok, msg


def test_bad_database_url_reports_failure():
    ok, msg = check_connection("postgresql+psycopg2://nobody:wrong@127.0.0.1:1/none")
    assert not ok and "failed" in msg


def test_save_and_reload_incidents(db_url, samples):
    raw = read_uploaded_file(samples / "valid_incidents.csv")
    out = save_incident_dataset(raw, suggest_mapping(list(raw.columns)), file_name="valid_incidents.csv",
                                user_id=None, is_synthetic=True, url=db_url)
    assert out.rows_saved == 195
    with get_connection(db_url) as conn:
        df = models.load_crime_records(conn, out.upload_id)
        up = models.get_upload(conn, out.upload_id)
    assert len(df) == 195 and df["latitude"].dtype == float
    assert up["status"] == "completed" and up["is_synthetic"]
    assert up["preprocessing_log"]["steps"][-1]["step"] == "Summary"


def test_hotspots_saved_and_delete_cascades(db_url, samples):
    raw = read_uploaded_file(samples / "valid_incidents.csv")
    out = save_incident_dataset(raw, suggest_mapping(list(raw.columns)), file_name="v.csv", user_id=None, url=db_url)
    with get_connection(db_url) as conn:
        df = models.load_crime_records(conn, out.upload_id)
    r = run_dbscan(df, 0.5, 10)
    with transaction(db_url) as conn:
        aid = models.save_analysis(conn, analysis_type="dbscan", upload_id=out.upload_id, user_id=None,
                                   parameters=r.params, filters=None, result_summary={"clusters": r.n_clusters})
        assert models.save_hotspot_clusters(conn, aid, r.clusters) == 3
    with get_connection(db_url) as conn:
        assert len(models.load_hotspot_clusters(conn, aid)) == 3
    with transaction(db_url) as conn:
        models.delete_upload(conn, out.upload_id)
    with get_connection(db_url) as conn:
        assert models.load_crime_records(conn, out.upload_id).empty
        assert models.load_hotspot_clusters(conn, aid).empty


def test_invalid_coordinates_rejected_by_database(db_url):
    with transaction(db_url) as conn:
        uid = models.create_upload(conn, file_name="x", dataset_type="incidents", uploaded_by=None)
    bad = pd.DataFrame({"crime_type": ["Theft"], "occurred_at": [pd.Timestamp("2024-01-01")], "latitude": [123.0],
                        "longitude": [77.0]})
    with pytest.raises(Exception):
        with transaction(db_url) as conn:
            models.insert_crime_records(conn, uid, bad)


# --- authentication --------------------------------------------------------------------------
def test_password_hashing():
    h = auth.hash_password("Secret123")
    assert h != "Secret123" and h.startswith("$2")
    assert auth.verify_password("Secret123", h)
    assert not auth.verify_password("wrong", h)
    assert not auth.verify_password("x", "not-a-hash")


def test_password_and_username_rules():
    assert auth.validate_password_strength("short1")
    assert auth.validate_password_strength("onlyletters")
    assert auth.validate_password_strength("Good1234") is None
    assert auth.validate_username("a b")
    assert auth.validate_username("admin") is None


def test_register_and_authenticate(db_url):
    uid = auth.register_user("analyst1", "Analyst123", "analyst", url=db_url)
    user = auth.authenticate("analyst1", "Analyst123", url=db_url)
    assert user and user["user_id"] == uid and "password_hash" not in user
    assert auth.authenticate("analyst1", "wrong", url=db_url) is None
    assert auth.authenticate("nobody", "Analyst123", url=db_url) is None
    assert auth.authenticate("x'; DROP TABLE users;--", "a", url=db_url) is None   # rejected, table intact
    with pytest.raises(ValueError, match="already exists"):
        auth.register_user("analyst1", "Analyst123", url=db_url)


def test_inactive_user_cannot_log_in(db_url):
    uid = auth.register_user("temp", "Temp12345", url=db_url)
    with transaction(db_url) as conn:
        models.set_user_active(conn, uid, False)
    assert auth.authenticate("temp", "Temp12345", url=db_url) is None


# --- exports ---------------------------------------------------------------------------------------
@pytest.fixture
def incidents(samples):
    from modules.preprocessing import preprocess_incidents
    raw = read_uploaded_file(samples / "valid_incidents.csv")
    return preprocess_incidents(raw, suggest_mapping(list(raw.columns))).data


def test_csv_export(incidents):
    data = rg.dataframe_to_csv_bytes(incidents.assign(upload_id=1))
    back = pd.read_csv(pd.io.common.BytesIO(data))
    assert len(back) == len(incidents) and "upload_id" not in back.columns


def test_hotspot_summary_csv(incidents):
    r = run_dbscan(incidents, 0.5, 10)
    out = pd.read_csv(pd.io.common.BytesIO(rg.hotspot_summary_csv(r.clusters, r.params)))
    assert len(out) == 3 and (out["eps_km"] == 0.5).all()


def test_png_charts(incidents):
    for builder in rg.CHART_BUILDERS.values():
        assert builder(incidents)[:8] == b"\x89PNG\r\n\x1a\n"
    assert rg.png_monthly_trend(incidents.iloc[0:0])[:4] == b"\x89PNG"


def test_pdf_report(incidents):
    r = run_dbscan(incidents, 0.5, 10)
    upload = {"upload_id": 1, "file_name": "valid_incidents.csv", "rows_received": 195, "rows_saved": 195,
              "rows_excluded": 0, "is_synthetic": True}
    pdf = rg.build_incident_report(upload, incidents, "No filters", ca.auto_observations(incidents, r), dbscan=r)
    assert pdf[:5] == b"%PDF-" and len(pdf) > 20_000
    empty = rg.build_incident_report(upload, incidents.iloc[0:0], "No filters", ["No incidents"])
    assert empty[:5] == b"%PDF-"
