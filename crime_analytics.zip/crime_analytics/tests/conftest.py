"""Shared fixtures.

Database tests run against SQLite by default (no setup needed). Set
TEST_DATABASE_URL to a PostgreSQL URL to run them against PostgreSQL too:

    TEST_DATABASE_URL=postgresql+psycopg2://crime_admin:crime_pass@localhost:5432/crime_analytics_test pytest
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from database import models  # noqa: E402
from database.connection import get_engine  # noqa: E402

SAMPLES = ROOT / "tests" / "sample_data"
DB_URLS = ["sqlite"] + (["postgresql"] if os.getenv("TEST_DATABASE_URL") else [])


@pytest.fixture
def samples() -> Path:
    return SAMPLES


@pytest.fixture
def valid_df() -> pd.DataFrame:
    return pd.read_csv(SAMPLES / "valid_incidents.csv")


@pytest.fixture(params=DB_URLS)
def db_url(request, tmp_path) -> str:
    """A fresh, empty database with all tables created."""
    if request.param == "sqlite":
        url = f"sqlite:///{tmp_path / 'test.db'}"
    else:
        url = os.environ["TEST_DATABASE_URL"]
    engine = get_engine(url)
    models.metadata.drop_all(engine)
    models.metadata.create_all(engine)
    yield url
    models.metadata.drop_all(engine)
