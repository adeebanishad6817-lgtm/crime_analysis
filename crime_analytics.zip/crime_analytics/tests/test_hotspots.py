"""DBSCAN hotspot detection with the haversine metric."""
import numpy as np
import pandas as pd
import pytest

import config
from modules.data_upload import read_uploaded_file, suggest_mapping
from modules.hotspot_detection import haversine_km, k_distance, location_ranking, prepare_locations, run_dbscan
from modules.preprocessing import preprocess_incidents


@pytest.fixture
def incidents(samples):
    raw = read_uploaded_file(samples / "valid_incidents.csv")
    return preprocess_incidents(raw, suggest_mapping(list(raw.columns))).data


def test_haversine_known_distance():
    # Delhi to Mumbai is about 1,150 km great-circle distance
    d = haversine_km(28.6139, 77.2090, 19.0760, 72.8777)
    assert 1140 < d < 1160
    assert haversine_km(10, 10, 10, 10) == pytest.approx(0)


def test_three_synthetic_clusters_found(incidents):
    r = run_dbscan(incidents, eps_km=0.5, min_samples=10, weighted=True)
    assert r.n_clusters == 3
    assert r.clusters["incident_count"].tolist() == [60, 60, 60]
    assert r.noise_incidents == 15
    assert list(r.clusters["rank"]) == [1, 2, 3]
    assert (r.clusters["radius_km"] < 1).all()


def test_eps_is_converted_with_earth_radius(incidents):
    r = run_dbscan(incidents, eps_km=0.5, min_samples=10)
    assert r.params["eps_radians"] == pytest.approx(0.5 / config.EARTH_RADIUS_KM)
    assert r.params["metric"] == "haversine"


def test_large_eps_merges_everything(incidents):
    r = run_dbscan(incidents, eps_km=100, min_samples=5)
    assert r.n_clusters == 1 and r.noise_incidents == 0
    assert any("no noise" in n for n in r.notes)


def test_strict_parameters_give_only_noise(incidents):
    r = run_dbscan(incidents, eps_km=0.01, min_samples=1000)
    assert r.n_clusters == 0
    assert r.noise_incidents == len(incidents)


def test_weighting_counts_incidents_not_locations():
    # One location with 50 incidents, far from everything else
    df = pd.DataFrame({"latitude": [12.0] * 50 + [20.0], "longitude": [77.0] * 50 + [80.0],
                       "crime_type": ["Theft"] * 51, "severity": ["Low"] * 51,
                       "occurred_at": pd.Timestamp("2024-01-01"), "location": ["A"] * 50 + ["B"]})
    assert run_dbscan(df, 1, 20, weighted=True).n_clusters == 1
    assert run_dbscan(df, 1, 20, weighted=False).n_clusters == 0


def test_every_incident_gets_a_label(incidents):
    r = run_dbscan(incidents, 0.5, 10)
    assert len(r.incidents_with_labels) == len(incidents)
    assert set(r.incidents_with_labels["cluster"]) == {-1, 0, 1, 2}


def test_empty_and_coordinate_free_data():
    empty = pd.DataFrame(columns=["latitude", "longitude", "crime_type", "severity", "occurred_at", "location"])
    r = run_dbscan(empty, 1, 5)
    assert r.n_clusters == 0 and r.notes
    no_coords = pd.DataFrame({"latitude": [np.nan], "longitude": [np.nan], "crime_type": ["X"],
                              "severity": ["Low"], "occurred_at": [pd.Timestamp("2024-01-01")], "location": ["A"]})
    assert run_dbscan(no_coords, 1, 1).n_clusters == 0


def test_invalid_parameters_rejected(incidents):
    with pytest.raises(ValueError):
        run_dbscan(incidents, 0, 5)
    with pytest.raises(ValueError):
        run_dbscan(incidents, 1, 0)


def test_k_distance_sorted(incidents):
    pts, _ = prepare_locations(incidents)
    d = k_distance(pts, 3)
    assert len(d) == len(pts) and np.all(np.diff(d) >= 0)


def test_location_ranking(incidents):
    lr = location_ranking(incidents, 10)
    assert lr["incidents"].sum() == len(incidents)
    assert lr["share_pct"].sum() == pytest.approx(100)
