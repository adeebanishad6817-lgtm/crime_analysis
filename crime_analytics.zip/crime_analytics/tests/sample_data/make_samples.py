"""Regenerate the SYNTHETIC test files in this folder.

These files are made-up data for automated tests only. They are never loaded
into the dashboards and must not be read as real crime statistics.

    python tests/sample_data/make_samples.py
"""
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
rng = np.random.default_rng(7)
TYPES = ["Theft", "Assault", "Burglary", "Robbery", "Vandalism"]


def incidents(n_per_cluster=60, noise=15):
    centres = [(12.9716, 77.5946), (12.9352, 77.6245), (13.0358, 77.5970)]  # three dense spots
    rows = []
    rid = 1
    for clat, clon in centres:
        for _ in range(n_per_cluster):
            rows.append((clat + rng.normal(0, 0.0015), clon + rng.normal(0, 0.0015)))
    for _ in range(noise):
        rows.append((12.80 + rng.uniform(0, 0.4), 77.40 + rng.uniform(0, 0.4)))
    out = []
    start = pd.Timestamp("2024-01-01")
    for lat, lon in rows:
        ts = start + pd.Timedelta(minutes=int(rng.integers(0, 60 * 24 * 365)))
        out.append({"Crime_ID": f"SYN-{rid:05d}", "Crime_Type": rng.choice(TYPES), "Date": ts.strftime("%d-%m-%Y"),
                    "Time": ts.strftime("%H:%M"), "Latitude": round(lat, 6), "Longitude": round(lon, 6),
                    "Location": "Synthetic Area " + str(rid % 4), "Severity": rng.choice(["High", "Medium", "Low"]),
                    "Police_Station": f"PS-{rid % 3}"})
        rid += 1
    return pd.DataFrame(out)


def main():
    valid = incidents()
    (HERE / "valid_incidents.csv").write_text(valid.to_csv(index=False))
    # Missing required column (no Crime_Type, no Date)
    (HERE / "missing_columns.csv").write_text(valid.drop(columns=["Crime_Type", "Date"]).head(20).to_csv(index=False))
    # Missing values: blank types, blank dates, blank severity
    mv = valid.head(40).copy()
    mv.loc[0:4, "Crime_Type"] = None
    mv.loc[5:9, "Date"] = None
    mv.loc[10:14, "Severity"] = None
    (HERE / "missing_values.csv").write_text(mv.to_csv(index=False))
    # Duplicates: 10 exact copies + 5 repeated IDs with different content
    dup = pd.concat([valid.head(30), valid.head(10)], ignore_index=True)
    rep = valid.iloc[30:35].copy()
    rep["Crime_ID"] = valid["Crime_ID"].iloc[:5].to_numpy()
    dup = pd.concat([dup, rep], ignore_index=True)
    (HERE / "duplicates.csv").write_text(dup.to_csv(index=False))
    # Invalid coordinates
    bad = valid.head(20).copy()
    bad["Latitude"] = bad["Latitude"].astype(object)
    bad.loc[0, "Latitude"] = 95.0
    bad.loc[1, "Longitude"] = -200.0
    bad.loc[2, ["Latitude", "Longitude"]] = 0.0
    bad.loc[3, "Latitude"] = None
    bad.loc[4, "Latitude"] = "abc"
    (HERE / "invalid_coordinates.csv").write_text(bad.to_csv(index=False))
    # Header only
    (HERE / "empty.csv").write_text(",".join(valid.columns) + "\n")
    # Not a CSV
    (HERE / "invalid_file.txt").write_text("this is not a dataset\n")
    # City-level file with month-first dates, like the project's India dataset
    city = pd.DataFrame({"Report Number": range(1, 9), "Crime Description": ["THEFT", "HOMICIDE"] * 4,
                         "Date of Occurrence": ["01-13-2020 00:00", "01-14-2020 01:00", "02-20-2020 02:00",
                                                "03-25-2020 03:00", "04-01-2020 04:00", "05-30-2020 05:00",
                                                "06-15-2020 06:00", "07-31-2020 07:00"],
                         "Time of Occurrence": ["14-01-2020 08:43"] * 8,
                         "City": ["Delhi", "Mumbai", "Ghaziabad", "Atlantis", "Delhi", "Pune", "Thane", "Mumbai"]})
    (HERE / "city_level_incidents.csv").write_text(city.to_csv(index=False))
    with pd.ExcelWriter(HERE / "valid_incidents.xlsx") as xw:
        valid.head(50).to_excel(xw, index=False)
    print("Synthetic test files written to", HERE)


if __name__ == "__main__":
    main()
