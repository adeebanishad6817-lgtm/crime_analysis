# Synthetic test data

Every file in this folder is **made-up data for automated tests**. Record IDs start with `SYN-` and
locations are named "Synthetic Area". None of it is real crime data, and it is never shown on the dashboards.

| File | Purpose |
| --- | --- |
| valid_incidents.csv / .xlsx | 195 incidents: three tight clusters near Bengaluru plus 15 scattered noise points |
| missing_columns.csv | No Crime_Type and no Date column (must be rejected with a clear message) |
| missing_values.csv | Blank crime types, blank dates and blank severities |
| duplicates.csv | 10 exact duplicate rows and 5 repeated Crime_IDs |
| invalid_coordinates.csv | Latitude 95, longitude -200, (0, 0), blank and text coordinates |
| empty.csv | Header row only |
| invalid_file.txt | Not a CSV/Excel file |
| city_level_incidents.csv | City names only, month-first dates, one unknown city ("Atlantis") |

Regenerate with `python tests/sample_data/make_samples.py`.
