"""End-to-end smoke test: log in and open every page with Streamlit's AppTest.

Needs the real database from .env, initialised with scripts/init_db.py and
scripts/load_sample_data.py. Skipped automatically when the database is unreachable.
"""
from pathlib import Path

import pytest

import config
from database.connection import check_connection

APP = str(Path(__file__).resolve().parents[1] / "app.py")
PAGES = ["views/overview.py", "views/hotspot_analysis.py", "views/temporal_analysis.py",
         "views/category_analysis.py", "views/advanced_analytics.py", "views/karnataka_statistics.py",
         "views/reports.py", "views/data_management.py"]

pytestmark = pytest.mark.skipif(not check_connection()[0], reason="application database not reachable")


@pytest.fixture(scope="module")
def app():
    from streamlit.testing.v1 import AppTest
    at = AppTest.from_file(APP, default_timeout=180)
    at.run()
    at.text_input[0].input(config.ADMIN_USERNAME)
    at.text_input[1].input(config.ADMIN_PASSWORD)
    at.button[0].click()
    at.run()
    try:
        logged_in = bool(at.session_state["user"])
    except KeyError:
        logged_in = False
    if not logged_in:
        pytest.skip("admin login failed - run scripts/init_db.py")
    return at


def test_login_page_shown_first():
    from streamlit.testing.v1 import AppTest
    at = AppTest.from_file(APP, default_timeout=60)
    at.run()
    assert not at.exception
    assert [t.label for t in at.text_input] == ["Username", "Password"]


def test_wrong_password_rejected():
    from streamlit.testing.v1 import AppTest
    at = AppTest.from_file(APP, default_timeout=60)
    at.run()
    at.text_input[0].input(config.ADMIN_USERNAME)
    at.text_input[1].input("definitely-wrong")
    at.button[0].click()
    at.run()
    assert any("Invalid username or password" in e.value for e in at.error)


@pytest.mark.parametrize("page", PAGES)
def test_page_renders_without_errors(app, page):
    app.switch_page(page)
    app.run()
    assert not app.exception, [e.value for e in app.exception]
