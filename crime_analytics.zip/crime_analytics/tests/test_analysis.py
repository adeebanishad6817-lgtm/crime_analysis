"""Statistics, filters, anomaly detection and the Karnataka parser."""
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from modules import crime_analysis as ca
from modules.anomaly_detection import aggregate_category_anomalies, detect_activity_anomalies
from modules.data_upload import UploadError, read_uploaded_file, suggest_mapping
from modules.filters import apply_filters, describe_filters, empty_filters
from modules.karnataka_stats import (add_change_metrics, parse_karnataka_review, report_month_from_filename,
                                     split_major_head, summary_by_head, top_movers)
from modules.preprocessing import preprocess_incidents

KARNATAKA = Path(__file__).resolve().parents[1] / "data" / "raw" / "crime_review_for_month_Feb2026.csv"


@pytest.fixture
def incidents(samples):
    raw = read_uploaded_file(samples / "valid_incidents.csv")
    return preprocess_incidents(raw, suggest_mapping(list(raw.columns))).data


def daily_series(counts, start="2023-01-02", crime="Theft"):
    rows = []
    for i, n in enumerate(counts):
        day = pd.Timestamp(start) + pd.Timedelta(days=i)
        rows += [{"occurred_at": day + pd.Timedelta(hours=h % 24), "crime_type": crime, "severity": "Low",
                  "location": "A"} for h in range(n)]
    df = pd.DataFrame(rows)
    ts = df["occurred_at"]
    from modules.preprocessing import time_period
    return df.assign(year=ts.dt.year, month=ts.dt.month, day=ts.dt.day, hour=ts.dt.hour,
                     day_of_week=ts.dt.dayofweek, is_weekend=ts.dt.dayofweek >= 5,
                     time_period=ts.dt.hour.map(time_period))


# --- descriptive statistics ----------------------------------------------------
def test_kpis(incidents):
    k = ca.kpis(incidents)
    assert k["total"] == 195
    assert k["top_crime_type_count"] == incidents["crime_type"].value_counts().iloc[0]
    assert ca.kpis(incidents.iloc[0:0]) == {"total": 0}


def test_hour_and_weekday_counts_sum_to_total(incidents):
    assert ca.hour_counts(incidents)["incidents"].sum() == len(incidents)
    wd = ca.weekday_counts(incidents)
    assert len(wd) == 7 and wd["incidents"].sum() == len(incidents)
    assert ca.weekday_hour_matrix(incidents).to_numpy().sum() == len(incidents)


def test_weekend_vs_weekday_uses_per_day_average():
    df = daily_series([10, 10, 10, 10, 10, 20, 20] * 4)  # starts on a Monday
    ww = ca.weekend_vs_weekday(df).set_index("day_type")
    assert ww.loc["Weekday", "avg_per_day"] == pytest.approx(10)
    assert ww.loc["Weekend", "avg_per_day"] == pytest.approx(20)


def test_mann_kendall_detects_trend_and_no_trend():
    assert ca.mann_kendall(np.arange(20))["trend"] == "increasing"
    assert ca.mann_kendall(np.arange(20)[::-1])["trend"] == "decreasing"
    rng = np.random.default_rng(0)
    assert ca.mann_kendall(rng.normal(size=30))["trend"] == "no significant trend"
    assert ca.mann_kendall([1, 2])["trend"] == "insufficient data"


def test_compare_periods(incidents):
    table, test = ca.compare_periods(incidents, ("2024-01-01", "2024-06-30"), ("2024-07-01", "2024-12-31"))
    assert test["total_a"] + test["total_b"] == len(incidents)
    assert {"period_a", "period_b", "change", "change_pct"} <= set(table.columns)


def test_auto_observations_flag_uniform_categories():
    df = daily_series([5] * 400)
    df["crime_type"] = np.tile(["A", "B", "C", "D", "E"], len(df) // 5 + 1)[:len(df)]
    obs = " ".join(ca.auto_observations(df))
    assert "almost uniform" in obs and "not a forecast" in obs


# --- filters -----------------------------------------------------------------------
def test_dashboard_filters(incidents):
    assert len(apply_filters(incidents, empty_filters())) == len(incidents)
    f = empty_filters() | {"crime_types": ["Theft"], "weekdays": [0, 1]}
    out = apply_filters(incidents, f)
    assert set(out["crime_type"]) <= {"Theft"} and set(out["day_of_week"]) <= {0, 1}
    f = empty_filters() | {"date_range": (pd.Timestamp("2024-03-01").date(), pd.Timestamp("2024-03-31").date())}
    out = apply_filters(incidents, f)
    assert out["occurred_at"].dt.month.eq(3).all()
    assert "Theft" in describe_filters({"crime_types": ["Theft"]})


# --- anomaly detection ----------------------------------------------------------------
def test_isolation_forest_flags_injected_spike():
    rng = np.random.default_rng(1)
    counts = list(rng.integers(18, 23, size=7 * 30))
    for d in range(7 * 20, 7 * 21):          # one week with five times the usual volume
        counts[d] = 100
    res = detect_activity_anomalies(daily_series(counts), "W", None, 0.05)
    flagged = res.table[res.table["is_anomaly"]]
    assert pd.Timestamp("2023-01-02") + pd.Timedelta(weeks=20) in set(flagged["period"])


def test_constant_volume_reports_no_variation():
    res = detect_activity_anomalies(daily_series([24] * 140), "W", None, 0.05)
    assert res.n_anomalies == 0
    assert any("same incident count" in n for n in res.notes)


def test_too_little_history():
    res = detect_activity_anomalies(daily_series([5] * 20), "W")
    assert res.table.empty and res.notes


# --- Karnataka aggregate parser ------------------------------------------------------------
@pytest.mark.skipif(not KARNATAKA.exists(), reason="Karnataka file not present")
def test_karnataka_file_parsing():
    raw = read_uploaded_file(KARNATAKA)
    clean, log = parse_karnataka_review(raw, KARNATAKA.name)
    assert len(raw) == 762 and len(clean) == 738
    steps = {e["step"]: e for e in log}
    assert steps["Excluded unlabelled rows"]["rows_before"] - steps["Excluded unlabelled rows"]["rows_after"] == 24
    assert "670" in steps["Stray values in unnamed column"]["detail"]
    assert (~clean["ytd_consistent"]).sum() == 4
    assert clean["report_month"].iloc[0] == pd.Timestamp("2026-02-01").date()
    s = summary_by_head(clean).set_index("head_of_crime")
    assert s.loc["A - IPC Crime", "count_current_month"] == 11449
    rises, falls = top_movers(clean)
    assert rises["yoy_change"].iloc[0] >= rises["yoy_change"].iloc[-1]
    an = aggregate_category_anomalies(add_change_metrics(clean))
    assert an["is_anomaly"].sum() > 0


def test_split_major_head():
    assert split_major_head("Murder (Sec.302/303 IPC/103,104 BNS)") == ("Murder", "Sec.302/303 IPC/103,104 BNS")
    name, legal = split_major_head("OFFENCES AGAINST PUBLIC SERVANTS (Public servant is a victim) (Sec 182-188 IPC)")
    assert name.startswith("OFFENCES AGAINST PUBLIC SERVANTS (Public servant") and legal.startswith("Sec 182")
    assert split_major_head("Arms Act 1959") == ("Arms Act 1959", None)
    assert split_major_head("THEFT (Sec.379 IPC)")[0] == "Theft"


def test_report_month_from_filename():
    assert str(report_month_from_filename("crime_review_for_month_Feb2026.csv")) == "2026-02-01"
    assert report_month_from_filename("data.csv") is None


def test_non_review_file_rejected(valid_df):
    with pytest.raises(UploadError, match="does not look like a crime-review"):
        parse_karnataka_review(valid_df)
