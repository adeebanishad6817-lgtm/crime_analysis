"""Create all tables and the first administrator account.

Usage:
    python scripts/init_db.py              # create tables + admin from .env
    python scripts/init_db.py --print-sql  # regenerate database/schema.sql
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from sqlalchemy.dialects import postgresql  # noqa: E402
from sqlalchemy.schema import CreateIndex, CreateTable  # noqa: E402

import config  # noqa: E402
from database import models  # noqa: E402
from database.connection import check_connection, get_connection, get_engine  # noqa: E402
from modules.authentication import hash_password, validate_password_strength  # noqa: E402


def schema_sql() -> str:
    dialect = postgresql.dialect()
    parts = ["-- Generated from database/models.py by scripts/init_db.py --print-sql", ""]
    for table in models.metadata.sorted_tables:
        parts.append(str(CreateTable(table).compile(dialect=dialect)).strip() + ";\n")
        for idx in sorted(table.indexes, key=lambda i: i.name):
            parts.append(str(CreateIndex(idx).compile(dialect=dialect)).strip() + ";")
        parts.append("")
    return "\n".join(parts)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--print-sql", action="store_true", help="write database/schema.sql and exit")
    args = parser.parse_args()
    if args.print_sql:
        out = config.BASE_DIR / "database" / "schema.sql"
        out.write_text(schema_sql(), encoding="utf-8")
        print(f"Wrote {out}")
        return 0

    ok, msg = check_connection()
    print(msg)
    if not ok:
        print("Fix DATABASE_URL in .env (see README, 'Database setup') and run again.")
        return 1
    models.create_all(get_engine())
    print("Tables ready:", ", ".join(t.name for t in models.metadata.sorted_tables))

    problem = validate_password_strength(config.ADMIN_PASSWORD)
    if problem:
        print(f"ADMIN_PASSWORD in .env is too weak: {problem}")
        return 1
    with get_connection() as conn:
        existing = models.get_user_by_username(conn, config.ADMIN_USERNAME)
    if existing:
        print(f"Admin user '{config.ADMIN_USERNAME}' already exists - left unchanged.")
    else:
        from database.connection import transaction
        with transaction() as conn:
            models.create_user(conn, config.ADMIN_USERNAME, hash_password(config.ADMIN_PASSWORD), "admin")
        print(f"Created admin user '{config.ADMIN_USERNAME}'. Change the password in .env for real use.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
