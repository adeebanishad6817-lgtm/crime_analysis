"""Load the two project datasets from data/raw into PostgreSQL.

Usage:
    python scripts/load_sample_data.py           # loads both files if not already loaded
    python scripts/load_sample_data.py --force   # load again even if a file with the same name exists

1. data/raw/crime_dataset_india.csv          -> incidents (city-level, no coordinates)
2. data/raw/crime_review_for_month_Feb2026.csv -> aggregate statistics (Karnataka)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import config  # noqa: E402
from database import models  # noqa: E402
from database.connection import get_connection  # noqa: E402
from modules.data_upload import read_uploaded_file, suggest_mapping, validate_mapping  # noqa: E402
from modules.ingestion import save_aggregate_dataset, save_incident_dataset  # noqa: E402

INDIA_FILE = config.RAW_DIR / "crime_dataset_india.csv"
KARNATAKA_FILE = config.RAW_DIR / "crime_review_for_month_Feb2026.csv"
INDIA_NOTE = ("Incident-level Indian crime dataset (29 cities, 2020-2024) supplied with the project. Its "
              "distributions are near-uniform (about 1,900 incidents per category and exactly one incident per hour "
              "in the occurrence column), which indicates simulated data. Use it to demonstrate the methods, not to "
              "draw conclusions about real crime in these cities.")


def _already_loaded(file_name: str) -> bool:
    with get_connection() as conn:
        ups = models.list_uploads(conn, completed_only=True)
    return not ups.empty and file_name in set(ups["file_name"])


def _admin_id() -> int | None:
    with get_connection() as conn:
        u = models.get_user_by_username(conn, config.ADMIN_USERNAME)
    return u["user_id"] if u else None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    user_id = _admin_id()

    if INDIA_FILE.exists() and (args.force or not _already_loaded(INDIA_FILE.name)):
        raw = read_uploaded_file(INDIA_FILE)
        mapping = suggest_mapping(list(raw.columns))
        errors, warnings = validate_mapping(mapping, raw)
        if errors:
            print("Mapping errors:", errors)
            return 1
        out = save_incident_dataset(raw, mapping, file_name=INDIA_FILE.name, user_id=user_id,
                                    source_name="Indian crime dataset (project file)", source_note=INDIA_NOTE,
                                    is_synthetic=True)
        print(f"Incidents: upload #{out.upload_id}, {out.rows_saved:,} saved, {out.rows_excluded:,} excluded.")
        for w in warnings + out.warnings:
            print("  note:", w)
    else:
        print(f"Skipped {INDIA_FILE.name} (missing or already loaded).")

    if KARNATAKA_FILE.exists() and (args.force or not _already_loaded(KARNATAKA_FILE.name)):
        raw = read_uploaded_file(KARNATAKA_FILE)
        out = save_aggregate_dataset(raw, file_name=KARNATAKA_FILE.name, user_id=user_id,
                                     source_name="Karnataka State Police - Crime Review for the Month (Feb 2026)")
        print(f"Karnataka aggregates: upload #{out.upload_id}, {out.rows_saved:,} saved, "
              f"{out.rows_excluded:,} excluded.")
    else:
        print(f"Skipped {KARNATAKA_FILE.name} (missing or already loaded).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
