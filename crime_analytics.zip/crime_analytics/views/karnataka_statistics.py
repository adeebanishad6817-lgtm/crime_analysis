"""Page 7 - Karnataka official crime review (aggregate category statistics)."""
from __future__ import annotations

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from database import models
from database.connection import get_connection
from modules import karnataka_stats as ks
from modules import visualization as viz
from modules.anomaly_detection import aggregate_category_anomalies
from modules.app_state import kpi_card, load_aggregates, page_header, select_upload

page_header("Karnataka Crime Review", "Official monthly category totals: month-on-month and year-on-year change.")
upload = select_upload("aggregate", "Aggregate dataset")
if upload is None:
    st.info("No aggregate dataset loaded. Upload a crime-review CSV on the Data Management page "
            "or run `python scripts/load_sample_data.py`.")
    st.stop()
stats = load_aggregates(upload["upload_id"])
if stats.empty:
    st.warning("This upload has no rows.")
    st.stop()
month = pd.Timestamp(stats["report_month"].iloc[0])
src = f"Source: {upload.get('source_name') or upload['file_name']} (upload #{upload['upload_id']})"
prev_m, prev_y = month - pd.DateOffset(months=1), month - pd.DateOffset(years=1)
st.caption(f"Report month **{month:%B %Y}** compared with {prev_m:%B %Y} (previous month) and "
           f"{prev_y:%B %Y} (same month last year). Year-to-date covers January-{month:%B %Y}.")

summary = ks.summary_by_head(stats)
cols = st.columns(len(summary))
for col, r in zip(cols, summary.itertuples()):
    kpi_card(col, r.head_of_crime, f"{r.count_current_month:,}",
             f"Previous month {r.count_previous_month:,} ({r.mom_pct:+.1f}%); same month last year "
             f"{r.count_same_month_prev_year:,} ({r.yoy_pct:+.1f}%); YTD {r.count_ytd:,}")
    col.caption(f"MoM {r.mom_pct:+.1f}% · YoY {r.yoy_pct:+.1f}%")
st.info("Heads are shown separately and never added together: *Crimes Against Women* can overlap with IPC "
        "categories such as rape or dowry deaths.", icon=":material/info:")

long = summary.melt(id_vars="head_of_crime", value_vars=["count_same_month_prev_year", "count_previous_month",
                                                         "count_current_month"], var_name="period", value_name="cases")
names = {"count_same_month_prev_year": f"{prev_y:%b %Y}", "count_previous_month": f"{prev_m:%b %Y}",
         "count_current_month": f"{month:%b %Y}"}
fig = go.Figure()
for i, (key, label) in enumerate(names.items()):
    d = long[long["period"] == key]
    fig.add_trace(go.Bar(x=d["head_of_crime"], y=d["cases"], name=label, marker_color=viz.CATEGORICAL[i],
                         hovertemplate=f"%{{x}}<br>{label}: %{{y:,}}<extra></extra>"))
fig.update_layout(barmode="group")
st.plotly_chart(viz._base_layout(fig, "Cases by head of crime: three periods compared", "Head of crime", "Cases",
                                 source=src), width="stretch")

st.subheader("Major heads")
head = st.selectbox("Head of crime", ["All"] + summary["head_of_crime"].tolist(), key="k_head")
majors = ks.major_head_totals(stats, None if head == "All" else head)
top = majors.head(20)
st.plotly_chart(viz.bar_chart(top, "count_current_month", "major_head", f"Top 20 major heads, {month:%B %Y}",
                              "Cases", "Major head", horizontal=True, source=src), width="stretch")

st.subheader("Largest year-on-year movements")
c1, c2 = st.columns([1, 3])
basis = c1.radio("Compare with", ["Same month last year", "Previous month"], key="k_basis")
min_base = c1.number_input("Ignore categories with fewer than this many cases", 0, 1000, 5, key="k_min")
by = "yoy_change" if basis.startswith("Same") else "mom_change"
rises, falls = ks.top_movers(stats if head == "All" else stats[stats["head_of_crime"] == head], by, 10, min_base)
movers = pd.concat([rises[rises[by] > 0], falls[falls[by] < 0]]).drop_duplicates("major_head").sort_values(by)
fig = go.Figure(go.Bar(x=movers[by], y=movers["major_head"], orientation="h",
                       marker_color=[viz.CATEGORICAL[1] if v > 0 else viz.CATEGORICAL[0] for v in movers[by]],
                       hovertemplate="%{y}<br>Change: %{x:+,}<extra></extra>"))
with c2:
    st.plotly_chart(viz._base_layout(fig, f"Biggest increases and decreases ({basis.lower()})", "Change in cases",
                                     "Major head", height=max(380, 26 * len(movers) + 100), source=src),
                    width="stretch")
    st.caption("Orange = increase, blue = decrease. Changes are in case counts for the report month.")

st.subheader("Categories with unusual movement (Isolation Forest)")
an = aggregate_category_anomalies(ks.add_change_metrics(stats))
flagged = an[an["is_anomaly"]]
st.caption(f"{len(flagged)} of {len(an)} non-empty categories flagged, using current count, MoM % and YoY % as features. "
           "A flag means the category's movement this month is unlike most others - a prompt to look closer.")
st.dataframe(flagged[["head_of_crime", "major_head", "minor_head", "count_current_month", "count_previous_month",
                      "count_same_month_prev_year", "mom_pct", "yoy_pct", "score"]],
             hide_index=True, width="stretch",
             column_config={"mom_pct": st.column_config.NumberColumn("MoM %", format="%+.0f%%"),
                            "yoy_pct": st.column_config.NumberColumn("YoY %", format="%+.0f%%"),
                            "score": st.column_config.NumberColumn("Score", format="%.3f")})

st.subheader("All categories")
q = st.text_input("Search category", key="k_search")
table = ks.add_change_metrics(stats)
if q:
    m = table["major_head"].str.contains(q, case=False, na=False) | table["minor_head"].str.contains(q, case=False, na=False)
    table = table[m]
st.dataframe(table[["sl_no", "head_of_crime", "major_head", "minor_head", "legal_sections", "count_current_month",
                    "count_previous_month", "count_same_month_prev_year", "count_ytd", "mom_change", "yoy_change",
                    "ytd_consistent"]], hide_index=True, width="stretch")

with st.expander("Data cleaning log for this file", icon=":material/fact_check:"):
    with get_connection() as conn:
        up = models.get_upload(conn, upload["upload_id"])
    steps = (up.get("preprocessing_log") or {}).get("steps", []) if up else []
    st.dataframe(pd.DataFrame(steps), hide_index=True, width="stretch")
