"""Page 1 - Overview dashboard."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from modules import crime_analysis as ca
from modules import visualization as viz
from modules.app_state import filter_status, incident_context, kpi_card, page_header, provenance_banner, source_text
from modules.cached import cached_dbscan, dbscan_params

page_header("Overview", "Headline figures, trends and distributions for the selected dataset and filters.")
upload, full, df, filters = incident_context()
if upload is None:
    st.stop()
provenance_banner(upload)
filter_status(full, df)
src = source_text(upload)

k = ca.kpis(df)
eps, min_samples, weighted = dbscan_params()
db = cached_dbscan(df, eps, min_samples, weighted) if not df.empty else None

c1, c2, c3, c4 = st.columns(4)
kpi_card(c1, "Total incidents", f"{k.get('total', 0):,}",
         f"{k['first_date']:%d %b %Y} to {k['last_date']:%d %b %Y}" if k.get("total") else None)
kpi_card(c2, "Hotspot clusters (DBSCAN)", f"{db.n_clusters if db else 0}",
         f"eps {eps:g} km, min_samples {min_samples}. Change on the Geographic Hotspots page.")
kpi_card(c3, "Most common category", k.get("top_crime_type", "-"),
         f"{k['top_crime_type_count']:,} incidents" if k.get("total") else None)
kpi_card(c4, "Highest incident-count location", k.get("top_location", "-"),
         f"{k['top_location_count']:,} incidents" if k.get("top_location") else None)

if k.get("total"):
    c5, c6, c7, c8 = st.columns(4)
    kpi_card(c5, "Crime categories", f"{k['n_crime_types']}")
    kpi_card(c6, "Locations", f"{k.get('n_locations', 0)}")
    kpi_card(c7, "High-severity share", f"{k['high_severity_pct']:.1f}%", "Severity derived from crime type "
             "when the dataset has no severity column.")
    kpi_card(c8, "Cases closed", f"{k['closure_rate_pct']:.1f}%" if "closure_rate_pct" in k else "n/a")

st.plotly_chart(viz.line_chart(ca.monthly_counts(df), "month", "incidents", "Monthly crime trend",
                               "Month", "Incidents", source=src), width="stretch", theme="streamlit")

left, right = st.columns([3, 2])
with left:
    st.plotly_chart(viz.bar_chart(ca.counts_by(df, "crime_type", 15), "incidents", "crime_type",
                                  "Crime category distribution (top 15)", "Incidents", "Crime category",
                                  horizontal=True, source=src), width="stretch", theme="streamlit")
with right:
    st.plotly_chart(viz.severity_donut(ca.counts_by(df, "severity"), "Severity distribution", source=src),
                    width="stretch", theme="streamlit")

left, right = st.columns(2)
with left:
    st.plotly_chart(viz.bar_chart(ca.counts_by(df, "location", 15), "incidents", "location",
                                  "Location-wise comparison (top 15)", "Incidents", "Location",
                                  horizontal=True, source=src), width="stretch", theme="streamlit")
with right:
    # Recent historical trend: last 24 months with a 3-month rolling average.
    m = ca.monthly_counts(df)
    if not m.empty:
        recent = m.tail(24).copy()
        recent["3-month average"] = recent["incidents"].rolling(3, min_periods=1).mean()
        long = recent.melt(id_vars="month", value_vars=["incidents", "3-month average"],
                           var_name="series", value_name="value")
        long["series"] = long["series"].replace({"incidents": "Monthly incidents"})
        fig = viz.line_chart(long, "month", "value", "Recent trend: last 24 months", "Month", "Incidents",
                             group="series", source=src)
    else:
        fig = viz.empty_figure("Recent trend: last 24 months")
    st.plotly_chart(fig, width="stretch", theme="streamlit")

with st.expander("Automatic observations", expanded=True, icon=":material/lightbulb:"):
    for line in ca.auto_observations(df, db):
        st.markdown(f"- {line}")
