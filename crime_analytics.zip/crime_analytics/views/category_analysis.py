"""Page 4 - Crime category analysis."""
from __future__ import annotations

import streamlit as st

from modules import crime_analysis as ca
from modules import visualization as viz
from modules.app_state import filter_status, incident_context, page_header, provenance_banner, source_text

page_header("Crime Category Analysis", "Distribution, severity, location mix and trends for each crime category.")
upload, full, df, filters = incident_context()
if upload is None:
    st.stop()
provenance_banner(upload)
filter_status(full, df)
src = source_text(upload)

left, right = st.columns(2)
with left:
    st.plotly_chart(viz.bar_chart(ca.counts_by(df, "crime_type"), "incidents", "crime_type",
                                  "Crime type distribution", "Incidents", "Crime type", horizontal=True,
                                  source=src), width="stretch")
with right:
    st.plotly_chart(viz.stacked_severity_bar(ca.severity_by_category(df), "Severity by crime type (derived)",
                                             source=src), width="stretch")

st.plotly_chart(viz.heatmap(ca.category_location_matrix(df), "Crime category vs location (top 15 each)",
                            "Location", "Crime category", source=src, height=560), width="stretch")

st.subheader("Category-wise historical trends")
types = ca.counts_by(df, "crime_type")["crime_type"].tolist()
chosen = st.multiselect("Categories to compare (up to 8 keep distinct colours)", types, default=types[:4],
                        max_selections=8, key="cat_trend_types")
if chosen:
    sub = df[df["crime_type"].isin(chosen)]
    m = ca.monthly_counts(sub, group="crime_type")
    st.plotly_chart(viz.line_chart(m, "month", "incidents", "Monthly incidents by category", "Month", "Incidents",
                                   group="crime_type", source=src), width="stretch")
trend = ca.category_trends(df, top_n=len(types))
if not trend.empty:
    st.markdown("**Observed trend per category** (Mann-Kendall test on complete months; history only, not a forecast)")
    st.dataframe(trend, hide_index=True, width="stretch", column_config={
        "crime_type": "Category", "months": "Months", "mean_per_month": st.column_config.NumberColumn("Mean / month", format="%.1f"),
        "slope_per_month": st.column_config.NumberColumn("Slope / month", format="%+.2f"),
        "mk_p_value": st.column_config.NumberColumn("p-value", format="%.3f"), "trend": "Trend"})

share = ca.category_share_by_year(df)
if not share.empty:
    long = share.reset_index().melt(id_vars="year", var_name="crime_type", value_name="share")
    long["year"] = long["year"].astype(str)
    fig = viz.line_chart(long, "year", "share", "Share of each year's incidents, top 8 categories (%)", "Year",
                         "Share of incidents (%)", group="crime_type", source=src)
    fig.update_xaxes(type="category")
    st.plotly_chart(fig, width="stretch")

extra = [c for c in ("crime_domain", "weapon_used", "age_group", "victim_gender") if c in df and df[c].notna().any()]
if extra:
    st.subheader("Other recorded attributes")
    st.caption("Aggregate counts only. No individual victim details are shown.")
    labels = {"crime_domain": "Crime domain", "weapon_used": "Weapon used", "age_group": "Victim age group",
              "victim_gender": "Victim gender"}
    cols = st.columns(2)
    for i, c in enumerate(extra):
        data = ca.counts_by(df, c)
        if c == "age_group":
            data = data.sort_values(c)
        with cols[i % 2]:
            st.plotly_chart(viz.bar_chart(data, c, "incidents", f"Incidents by {labels[c].lower()}", labels[c],
                                          "Incidents", source=src), width="stretch")
