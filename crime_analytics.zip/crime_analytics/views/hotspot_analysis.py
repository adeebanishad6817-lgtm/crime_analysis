"""Page 2 - Geographic hotspot analysis (Folium maps + DBSCAN)."""
from __future__ import annotations

import streamlit as st
from streamlit_folium import st_folium

import config
from database import models
from database.connection import transaction
from modules import visualization as viz
from modules.app_state import filter_status, incident_context, kpi_card, page_header, provenance_banner, source_text
from modules.cached import cached_dbscan
from modules.filters import describe_filters
from modules.hotspot_detection import k_distance, location_ranking, prepare_locations

page_header("Geographic Hotspot Analysis",
            "Incident locations, a weighted heatmap and DBSCAN density clusters (haversine distance).")
upload, full, df, filters = incident_context()
if upload is None:
    st.stop()
provenance_banner(upload)
filter_status(full, df)
src = source_text(upload)

city_level = bool(len(df)) and (df["coord_source"] == "city_centroid").mean() > 0.5
if df["latitude"].notna().sum() == 0 if len(df) else True:
    st.error("This dataset has no usable coordinates or recognised location names, so maps and DBSCAN are "
             "unavailable. Map Latitude/Longitude or a Location column on the Data Management page.")
    st.stop()
if city_level:
    st.info("This dataset has no incident coordinates. Each city is placed at its approximate centre, so the map "
            "and clusters work at **city level**: DBSCAN groups nearby cities into regional hotspots, weighted by "
            "their incident counts.", icon=":material/info:")

with st.container(border=True):
    st.markdown("**DBSCAN parameters**")
    p1, p2, p3 = st.columns([2, 2, 1])
    eps_km = p1.slider("eps - neighbourhood radius (km)", 1.0, 500.0 if city_level else 50.0,
                       value=float(st.session_state.get("dbscan_eps_km",
                                                        config.DBSCAN_DEFAULT_EPS_KM if city_level else 0.5)),
                       step=1.0 if city_level else 0.1, key="dbscan_eps_km",
                       help="Two locations are neighbours when their great-circle distance is at most eps.")
    min_samples = p2.number_input("min_samples - incidents needed for a core point", 1, 1_000_000,
                                  value=int(st.session_state.get("dbscan_min_samples",
                                                                 config.DBSCAN_DEFAULT_MIN_SAMPLES if city_level else 20)),
                                  step=100 if city_level else 5, key="dbscan_min_samples")
    weighted = p3.toggle("Weight by incidents", value=st.session_state.get("dbscan_weighted", True),
                         key="dbscan_weighted", help="Each location counts once per incident it holds.")

result = cached_dbscan(df, eps_km, int(min_samples), weighted)
pct = result.clustered_incidents / max(1, result.clustered_incidents + result.noise_incidents) * 100
c1, c2, c3, c4 = st.columns(4)
kpi_card(c1, "Hotspot clusters", f"{result.n_clusters}")
kpi_card(c2, "Incidents in hotspots", f"{result.clustered_incidents:,}", f"{pct:.1f}% of mapped incidents")
kpi_card(c3, "Noise incidents", f"{result.noise_incidents:,}", "Not dense enough to join any cluster")
kpi_card(c4, "Noise locations", f"{result.noise_locations}", f"of {len(result.points)} locations")
for note in result.notes:
    st.caption(note)

view = st.segmented_control("Map view", ["DBSCAN clusters", "Incident markers", "Heatmap"],
                            default="DBSCAN clusters", key="map_view")
points, _ = prepare_locations(df)
if view == "Incident markers":
    fmap = viz.incident_map(points, "markers", city_level)
elif view == "Heatmap":
    fmap = viz.incident_map(points, "heatmap", city_level)
else:
    fmap = viz.cluster_map(result, city_level)
st_folium(fmap, height=560, use_container_width=True, returned_objects=[], key=f"map-{view}")
st.caption(src + (" - city-centre coordinates are approximate." if city_level else ""))

left, right = st.columns([3, 2])
with left:
    st.subheader("Hotspot ranking")
    if result.clusters.empty:
        st.info("No clusters with the current parameters. Increase eps or lower min_samples.")
    else:
        show = result.clusters[["rank", "member_locations", "incident_count", "location_count", "radius_km",
                                "top_crime_type", "high_severity_share", "centroid_lat", "centroid_lon"]]
        st.dataframe(show, hide_index=True, width="stretch", column_config={
            "rank": "Rank", "member_locations": "Locations in cluster", "incident_count": st.column_config.NumberColumn("Incidents", format="%d"),
            "location_count": "Locations", "radius_km": st.column_config.NumberColumn("Radius (km)", format="%.1f"),
            "top_crime_type": "Most common crime",
            "high_severity_share": st.column_config.ProgressColumn("High severity", format="percent", min_value=0, max_value=1),
            "centroid_lat": st.column_config.NumberColumn("Centre lat", format="%.4f"),
            "centroid_lon": st.column_config.NumberColumn("Centre lon", format="%.4f")})
        bar = result.clusters.assign(label=lambda d: "#" + d["rank"].astype(str) + " " + d["member_locations"].str.slice(0, 40))
        st.plotly_chart(viz.bar_chart(bar, "incident_count", "label", "Cluster-wise incident counts",
                                      "Incidents", "Hotspot", horizontal=True, source=src),
                        width="stretch", theme="streamlit")
with right:
    st.subheader("Location ranking")
    st.dataframe(location_ranking(df, 30), hide_index=True, width="stretch", column_config={
        "location": "Location", "incidents": st.column_config.NumberColumn("Incidents", format="%d"),
        "share_pct": st.column_config.NumberColumn("Share", format="%.1f%%"),
        "high_severity_pct": st.column_config.NumberColumn("High severity", format="%.1f%%")})

user = st.session_state.get("user", {})
if st.button("Save this DBSCAN run to the database", icon=":material/save:"):
    try:
        with transaction() as conn:
            aid = models.save_analysis(
                conn, analysis_type="dbscan", upload_id=upload["upload_id"], user_id=user.get("user_id"),
                parameters=result.params, filters={"description": describe_filters(filters)},
                result_summary={"clusters": result.n_clusters, "noise_incidents": result.noise_incidents,
                                "clustered_incidents": result.clustered_incidents})
            n = models.save_hotspot_clusters(conn, aid, result.clusters)
        st.success(f"Saved as analysis #{aid} with {n} cluster rows.", icon=":material/check_circle:")
    except Exception as exc:
        st.error(f"Could not save: {exc}")

with st.expander("How DBSCAN hotspot detection works", icon=":material/school:"):
    st.markdown(f"""
**DBSCAN** (Density-Based Spatial Clustering of Applications with Noise) groups points that are packed
closely together and marks isolated points as **noise**. It needs two parameters:

* **eps** - the neighbourhood radius. Here distance is the **haversine** (great-circle) distance, because
  latitude/longitude lie on a sphere. scikit-learn's haversine metric works in radians, so
  `eps_radians = eps_km / {config.EARTH_RADIUS_KM:.0f}` (Earth's radius in km).
* **min_samples** - how many incidents must fall within eps of a location for it to be a **core point**.
  With *weight by incidents* on, each location counts as many times as it has incidents.

A cluster is a set of core points within eps of each other plus the border points they reach. Unlike k-means,
DBSCAN does not need the number of clusters in advance and finds clusters of any shape.

**Choosing eps:** the k-distance plot below sorts every location by the distance to its k-th nearest
neighbour. A sharp bend ("elbow") suggests a natural eps.
""")
    k = st.slider("k for the k-distance plot", 1, max(1, min(10, len(points) - 1)), min(3, max(1, len(points) - 1)))
    st.plotly_chart(viz.k_distance_chart(k_distance(points, k), eps_km, k), width="stretch")
