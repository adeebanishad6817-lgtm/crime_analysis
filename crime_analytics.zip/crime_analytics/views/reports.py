"""Page 6 - Report generation and exports."""
from __future__ import annotations

from datetime import datetime

import streamlit as st

from database import models
from database.connection import get_connection, transaction
from modules import crime_analysis as ca
from modules import karnataka_stats as ks
from modules import report_generation as rg
from modules.app_state import (filter_status, incident_context, load_aggregates, page_header,
                               provenance_banner, select_upload)
from modules.cached import cached_anomalies, cached_dbscan, dbscan_params
from modules.filters import describe_filters

page_header("Reports & Exports", "Download filtered records, chart images, hotspot summaries and PDF reports.")
upload, full, df, filters = incident_context(require_data=False)
user = st.session_state.get("user", {})
stamp = datetime.now().strftime("%Y%m%d_%H%M")

if upload is not None:
    provenance_banner(upload)
    filter_status(full, df)
    st.markdown(f"**Dataset:** {upload['file_name']} (upload #{upload['upload_id']}) &nbsp;|&nbsp; "
                f"**Filters:** {describe_filters(filters)}")
    eps, min_samples, weighted = dbscan_params()

    c1, c2 = st.columns(2)
    with c1, st.container(border=True):
        st.markdown("#### Filtered records (CSV)")
        st.caption(f"{len(df):,} rows, {df.shape[1]} columns.")
        st.download_button("Download CSV", rg.dataframe_to_csv_bytes(df), f"crime_records_{stamp}.csv",
                           "text/csv", icon=":material/download:", disabled=df.empty)
    with c2, st.container(border=True):
        st.markdown("#### Hotspot summary (CSV)")
        db = cached_dbscan(df, eps, min_samples, weighted) if not df.empty else None
        st.caption(f"DBSCAN with eps {eps:g} km, min_samples {min_samples}: "
                   f"{db.n_clusters if db else 0} cluster(s).")
        st.download_button("Download hotspot summary", rg.hotspot_summary_csv(db.clusters, db.params) if db else b"",
                           f"hotspots_{stamp}.csv", "text/csv", icon=":material/download:",
                           disabled=db is None or db.clusters.empty)

    with st.container(border=True):
        st.markdown("#### Chart images (PNG)")
        st.caption("Static images for documents. Every interactive chart also has a camera button for PNG download.")
        chart = st.selectbox("Chart", list(rg.CHART_BUILDERS) + ["Hotspots"], key="png_chart")
        png = rg.png_hotspots(db.clusters if db else None) if chart == "Hotspots" else rg.CHART_BUILDERS[chart](df)
        st.image(png, width="stretch")
        st.download_button("Download PNG", png, f"{chart.lower().replace(' ', '_')}_{stamp}.png", "image/png",
                           icon=":material/image:")

    with st.container(border=True):
        st.markdown("#### PDF analytical report")
        st.caption("Dataset information, filters, KPIs, observations, charts, hotspot table, unusual periods, "
                   "preprocessing log and method notes.")
        inc_anom = st.checkbox("Include Isolation Forest results (monthly, by location)", value=True)
        if st.button("Generate PDF report", type="primary", icon=":material/picture_as_pdf:", disabled=df.empty):
            with st.spinner("Building the PDF..."):
                anomalies = cached_anomalies(df, "M", "location" if "location" in df else None, 0.05) if inc_anom else None
                with get_connection() as conn:
                    up = models.get_upload(conn, upload["upload_id"]) or upload
                log = (up.get("preprocessing_log") or {}).get("steps") if isinstance(up.get("preprocessing_log"), dict) else None
                pdf = rg.build_incident_report(up, df, describe_filters(filters), ca.auto_observations(df, db, anomalies),
                                               dbscan=db, anomalies=anomalies, preprocessing_log=log,
                                               generated_by=user.get("username"))
                with transaction() as conn:
                    models.save_analysis(conn, analysis_type="report", upload_id=upload["upload_id"],
                                         user_id=user.get("user_id"), parameters={"type": "incident_pdf"},
                                         filters={"description": describe_filters(filters)},
                                         result_summary={"records": len(df), "bytes": len(pdf)})
            st.session_state["pdf_report"] = pdf
            st.success("Report ready.", icon=":material/check_circle:")
        if st.session_state.get("pdf_report"):
            st.download_button("Download PDF report", st.session_state["pdf_report"], f"crime_report_{stamp}.pdf",
                               "application/pdf", icon=":material/download:")

st.divider()
st.subheader("Karnataka crime review exports")
agg = select_upload("aggregate", "Aggregate dataset")
if agg is None:
    st.info("No aggregate dataset loaded.")
else:
    stats = load_aggregates(agg["upload_id"])
    c1, c2 = st.columns(2)
    with c1:
        st.download_button("Download cleaned Karnataka data (CSV)", rg.dataframe_to_csv_bytes(ks.add_change_metrics(stats)),
                           f"karnataka_review_{stamp}.csv", "text/csv", icon=":material/download:")
    with c2:
        if st.button("Generate Karnataka PDF summary", icon=":material/picture_as_pdf:"):
            with get_connection() as conn:
                up = models.get_upload(conn, agg["upload_id"]) or agg
            log = (up.get("preprocessing_log") or {}).get("steps")
            rises, falls = ks.top_movers(stats, "yoy_change", 10)
            st.session_state["k_pdf"] = rg.build_karnataka_report(up, stats, ks.summary_by_head(stats), rises, falls, log)
        if st.session_state.get("k_pdf"):
            st.download_button("Download Karnataka PDF", st.session_state["k_pdf"], f"karnataka_summary_{stamp}.pdf",
                               "application/pdf", icon=":material/download:")
