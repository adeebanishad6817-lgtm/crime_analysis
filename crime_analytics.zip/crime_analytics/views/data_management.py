"""Admin page - upload datasets, map columns, validate, save; manage datasets and users."""
from __future__ import annotations

import hashlib

import pandas as pd
import streamlit as st
from sqlalchemy import func, select

from database import models
from database.connection import check_connection, get_connection, transaction
from modules import authentication as auth
from modules.app_state import clear_caches, page_header
from modules.data_upload import (FIELD_NAMES, REQUIRED_FIELDS, STANDARD_FIELDS, UploadError,
                                 detect_dataset_type, detect_personal_data_columns, profile_dataframe,
                                 read_uploaded_file, suggest_mapping, validate_mapping)
from modules.ingestion import save_aggregate_dataset, save_incident_dataset
from modules.karnataka_stats import parse_karnataka_review
from modules.preprocessing import preprocess_incidents

if not auth.is_admin():
    st.error("Administrator access is required for this page.")
    st.stop()

page_header("Data Management", "Upload and validate datasets, review preprocessing, manage stored data and users.")
user = st.session_state["user"]
NOT_MAPPED = "- not mapped -"

tab_upload, tab_data, tab_users, tab_system = st.tabs(["Upload dataset", "Stored datasets", "Users", "System"])

# ---------------------------------------------------------------------------
with tab_upload:
    file = st.file_uploader("CSV or Excel file", type=["csv", "xlsx", "xls"], key="uploader")
    if file is None:
        st.caption("Incident files need at least a crime type and a date column. Coordinates are optional: "
                   "a city/location column is enough for city-level maps.")
    else:
        raw_bytes = file.getvalue()
        fid = hashlib.md5(raw_bytes).hexdigest()
        if st.session_state.get("upload_fid") != fid:
            try:
                st.session_state["upload_df"] = read_uploaded_file(raw_bytes, file.name)
                st.session_state["upload_fid"] = fid
                st.session_state.pop("prep_result", None)
            except UploadError as exc:
                st.error(str(exc), icon=":material/error:")
                st.stop()
        raw: pd.DataFrame = st.session_state["upload_df"]
        prof = profile_dataframe(raw)
        st.success(f"Read **{file.name}**: {prof['rows']:,} rows x {prof['columns']} columns.",
                   icon=":material/check_circle:")

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Rows", f"{prof['rows']:,}", border=True)
        c2.metric("Columns", prof["columns"], border=True)
        c3.metric("Duplicate rows", f"{prof['duplicate_rows']:,}", border=True)
        c4.metric("Missing cells", f"{prof['missing_cells']:,}", border=True)
        with st.expander("Preview (first 100 rows)", expanded=True):
            st.dataframe(raw.head(100), width="stretch")
        if prof["missing_by_column"]:
            with st.expander("Missing values by column"):
                miss = pd.DataFrame({"column": list(prof["missing_by_column"]),
                                     "missing": list(prof["missing_by_column"].values())})
                miss["share_pct"] = miss["missing"] / prof["rows"] * 100
                st.dataframe(miss, hide_index=True, width="stretch")
        pii = detect_personal_data_columns(list(raw.columns))
        if pii:
            st.warning(f"Columns that may hold personal data: **{', '.join(pii)}**. They are not stored unless you "
                       f"map them, and they should not be mapped.", icon=":material/privacy_tip:")

        detected = detect_dataset_type(raw)
        dtype = st.radio("Dataset type", ["incidents", "aggregate"], index=0 if detected == "incidents" else 1,
                         horizontal=True, format_func=lambda t: {"incidents": "Incident records (one row per crime)",
                                                                  "aggregate": "Aggregated statistics (crime-review summary)"}[t],
                         help=f"Detected automatically as '{detected}'.")
        source_name = st.text_input("Source / provenance", placeholder="e.g. Karnataka State Police website, Kaggle dataset")
        source_note = st.text_area("Notes about this dataset (shown with results)", height=70)

        if dtype == "aggregate":
            try:
                clean, log = parse_karnataka_review(raw, file.name)
            except UploadError as exc:
                st.error(str(exc))
                st.stop()
            st.markdown("**Cleaning log**")
            st.dataframe(pd.DataFrame(log), hide_index=True, width="stretch")
            st.dataframe(clean.head(50), hide_index=True, width="stretch")
            if st.button("Save to database", type="primary", icon=":material/save:"):
                with st.spinner("Saving..."):
                    out = save_aggregate_dataset(raw, file_name=file.name, user_id=user["user_id"],
                                                 source_name=source_name or None, source_note=source_note or None)
                clear_caches()
                st.success(f"Saved as upload #{out.upload_id}: {out.rows_saved:,} rows, {out.rows_excluded} excluded.")
        else:
            st.subheader("1. Map columns")
            st.caption("Match your columns to the standard fields. Required fields are marked *. "
                       "Suggestions are pre-filled from the column names.")
            suggestion = suggest_mapping(list(raw.columns))
            options = [NOT_MAPPED] + list(raw.columns)
            mapping: dict[str, str | None] = {}
            cols = st.columns(3)
            for i, f in enumerate(STANDARD_FIELDS):
                default = suggestion.get(f.name)
                choice = cols[i % 3].selectbox(f"{f.name}{' *' if f.required else ''}", options,
                                               index=options.index(default) if default in options else 0,
                                               help=f.description, key=f"map_{fid}_{f.name}")
                mapping[f.name] = None if choice == NOT_MAPPED else choice
            errors, warnings = validate_mapping(mapping, raw)
            for e in errors:
                st.error(e, icon=":material/error:")
            for w in warnings:
                st.warning(w, icon=":material/warning:")

            st.subheader("2. Validate and preprocess")
            if st.button("Run validation", disabled=bool(errors), icon=":material/rule:"):
                with st.spinner("Preprocessing..."):
                    st.session_state["prep_result"] = (preprocess_incidents(raw, mapping), dict(mapping))
            prep = st.session_state.get("prep_result")
            if prep and prep[1] == mapping:
                result = prep[0]
                k1, k2, k3 = st.columns(3)
                k1.metric("Rows received", f"{result.rows_in:,}", border=True)
                k2.metric("Rows to save", f"{result.rows_out:,}", border=True)
                k3.metric("Rows excluded", f"{result.rows_excluded:,}", f"{result.excluded_share:.1%}", border=True,
                          delta_color="inverse")
                for w in result.warnings:
                    st.warning(w)
                st.markdown("**Preprocessing log** (every operation, with row counts)")
                st.dataframe(pd.DataFrame(result.log), hide_index=True, width="stretch",
                             column_config={"detail": st.column_config.TextColumn("Detail", width="large")})
                st.markdown("**Cleaned sample**")
                st.dataframe(result.data.head(50), width="stretch")

                st.subheader("3. Save")
                synthetic = st.checkbox("This dataset is synthetic / simulated (results will be labelled as such)")
                confirm = True
                if result.excluded_share > 0.10:
                    confirm = st.checkbox(f"I have reviewed why {result.rows_excluded:,} rows are excluded and want to continue.")
                if st.button("Save to database", type="primary", disabled=not confirm, icon=":material/save:"):
                    with st.spinner(f"Saving {result.rows_out:,} records to PostgreSQL..."):
                        try:
                            out = save_incident_dataset(raw, mapping, file_name=file.name, user_id=user["user_id"],
                                                        source_name=source_name or None,
                                                        source_note=source_note or None,
                                                        is_synthetic=synthetic, result=result)
                        except Exception as exc:
                            st.error(f"Save failed and nothing was written: {exc}")
                            st.stop()
                    clear_caches()
                    st.session_state["active_incidents"] = out.upload_id
                    st.success(f"Saved as upload #{out.upload_id}: {out.rows_saved:,} records. "
                               f"It is now selected on the dashboards.", icon=":material/check_circle:")
            elif not errors:
                st.caption("Run validation to see the preprocessing report before saving.")

# ---------------------------------------------------------------------------
with tab_data:
    with get_connection() as conn:
        ups = models.list_uploads(conn)
    if ups.empty:
        st.info("No datasets stored yet.")
    else:
        st.dataframe(ups.drop(columns=["column_mapping", "preprocessing_log"]), hide_index=True, width="stretch")
        sel = st.selectbox("Dataset", ups["upload_id"].tolist(),
                           format_func=lambda i: f"#{i} {ups.set_index('upload_id').loc[i, 'file_name']}")
        row = ups.set_index("upload_id").loc[sel]
        log = row["preprocessing_log"] or {}
        st.markdown("**Column mapping**")
        st.json(row["column_mapping"] or {}, expanded=False)
        st.markdown("**Preprocessing log**")
        st.dataframe(pd.DataFrame(log.get("steps", [])), hide_index=True, width="stretch")
        with st.popover("Delete this dataset", icon=":material/delete:"):
            st.write(f"Delete upload #{sel} and all its records and saved analyses? This cannot be undone.")
            if st.button("Yes, delete", type="primary", key=f"del_{sel}"):
                with transaction() as conn:
                    models.delete_upload(conn, int(sel))
                clear_caches()
                st.success(f"Deleted upload #{sel}.")
                st.rerun()

# ---------------------------------------------------------------------------
with tab_users:
    with get_connection() as conn:
        st.dataframe(models.list_users(conn), hide_index=True, width="stretch")
    with st.form("new_user", clear_on_submit=True):
        st.markdown("**Create user**")
        c1, c2, c3 = st.columns(3)
        uname = c1.text_input("Username")
        pwd = c2.text_input("Password", type="password", help="At least 8 characters with a letter and a digit.")
        role = c3.selectbox("Role", ["analyst", "admin"])
        if st.form_submit_button("Create", type="primary"):
            try:
                uid = auth.register_user(uname.strip(), pwd, role)
                st.success(f"Created user #{uid} '{uname}'.")
            except ValueError as exc:
                st.error(str(exc))
    with get_connection() as conn:
        users_df = models.list_users(conn)
    others = users_df[users_df["user_id"] != user["user_id"]]
    if not others.empty:
        c1, c2 = st.columns([3, 1])
        target = c1.selectbox("Activate / deactivate user", others["user_id"].tolist(),
                              format_func=lambda i: others.set_index("user_id").loc[i, "username"])
        active = bool(others.set_index("user_id").loc[target, "is_active"])
        if c2.button("Deactivate" if active else "Activate", width="stretch"):
            with transaction() as conn:
                models.set_user_active(conn, int(target), not active)
            st.rerun()

# ---------------------------------------------------------------------------
with tab_system:
    ok, msg = check_connection()
    (st.success if ok else st.error)(msg)
    with get_connection() as conn:
        counts = {t.name: conn.execute(select(func.count()).select_from(t)).scalar_one()
                  for t in models.metadata.sorted_tables}
    st.dataframe(pd.DataFrame({"table": list(counts), "rows": list(counts.values())}), hide_index=True)
    st.caption(f"Standard fields: {', '.join(FIELD_NAMES)}. Required: {', '.join(REQUIRED_FIELDS)}.")
    if st.button("Clear cached data", icon=":material/refresh:"):
        clear_caches()
        st.success("Caches cleared.")
