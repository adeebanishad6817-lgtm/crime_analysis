"""Page 5 - Advanced analytics: DBSCAN summary, Isolation Forest, trends, correlation, period comparison."""
from __future__ import annotations

import pandas as pd
import streamlit as st

from database import models
from database.connection import get_connection, transaction
from modules import crime_analysis as ca
from modules import visualization as viz
from modules.app_state import filter_status, incident_context, kpi_card, page_header, provenance_banner, source_text
from modules.cached import cached_anomalies, cached_dbscan, dbscan_params
from modules.filters import describe_filters

page_header("Advanced Analytics", "Clustering, anomaly detection, statistical trends, correlation and period comparison.")
upload, full, df, filters = incident_context()
if upload is None:
    st.stop()
provenance_banner(upload)
filter_status(full, df)
src = source_text(upload)
user = st.session_state.get("user", {})

eps, min_samples, weighted = dbscan_params()
db = cached_dbscan(df, eps, min_samples, weighted) if not df.empty else None

tabs = st.tabs(["Observations", "DBSCAN", "Isolation Forest", "Trends", "Correlation", "Period comparison", "History"])

with tabs[0]:
    st.markdown("Generated automatically from the filtered data. Each statement is computed, not written by hand.")
    anomaly_for_obs = cached_anomalies(df, "M", "location" if "location" in df else None, 0.05) if len(df) else None
    for line in ca.auto_observations(df, db, anomaly_for_obs):
        st.markdown(f"- {line}")

with tabs[1]:
    if db is None:
        st.info("No data.")
    else:
        c1, c2, c3 = st.columns(3)
        kpi_card(c1, "Clusters", str(db.n_clusters))
        kpi_card(c2, "Clustered incidents", f"{db.clustered_incidents:,}")
        kpi_card(c3, "Noise incidents", f"{db.noise_incidents:,}")
        st.caption(f"Parameters: eps = {eps:g} km, min_samples = {min_samples}, weighted = {weighted}. "
                   f"Change them on the Geographic Hotspots page.")
        st.dataframe(db.clusters, hide_index=True, width="stretch")
        st.markdown("**Sensitivity to eps** (min_samples fixed): how the number of clusters changes.")
        grid = sorted({max(1.0, eps * f) for f in (0.25, 0.5, 0.75, 1, 1.5, 2, 3)})
        rows = []
        for e in grid:
            r = cached_dbscan(df, float(e), min_samples, weighted)
            rows.append({"eps_km": e, "clusters": r.n_clusters, "noise_incidents": r.noise_incidents})
        sens = pd.DataFrame(rows)
        st.plotly_chart(viz.line_chart(sens, "eps_km", "clusters", "Number of clusters vs eps", "eps (km)",
                                       "Clusters", source=src), width="stretch")

with tabs[2]:
    st.markdown("Isolation Forest isolates observations with random splits; points isolated in few splits are "
                "unusual. Here each observation is one **period of aggregated counts**, never a single crime record.")
    a1, a2, a3 = st.columns(3)
    freq_label = a1.radio("Period", ["Week", "Month"], horizontal=True, key="if_freq")
    group_label = a2.selectbox("Analyse", ["Overall volume", "By crime category", "By location"], key="if_group")
    contamination = a3.slider("Expected share of unusual periods", 0.01, 0.20, 0.05, 0.01, key="if_cont",
                              help="Isolation Forest's 'contamination': the fraction of periods it will flag.")
    freq = "W" if freq_label == "Week" else "M"
    group_col = {"Overall volume": None, "By crime category": "crime_type", "By location": "location"}[group_label]
    res = cached_anomalies(df, freq, group_col, contamination)
    for n in res.notes:
        st.info(n)
    if not res.table.empty:
        if group_col:
            flagged_groups = res.table[res.table["is_anomaly"]][group_col].value_counts()
            options = flagged_groups.index.tolist() + sorted(set(res.table[group_col]) - set(flagged_groups.index))
            g = st.selectbox("Show series for", options, key="if_series")
        else:
            g = None
        st.plotly_chart(viz.anomaly_chart(res.table, f"Unusual {freq_label.lower()}s in aggregated incident counts",
                                          g, group_col, source=src), width="stretch")
        flagged = res.table[res.table["is_anomaly"]].sort_values("score", ascending=False)
        st.markdown(f"**{len(flagged)} flagged period(s)** (higher score = more unusual)")
        cols = ["period"] + ([group_col] if group_col else []) + ["count", "expected", "deviation", "high_share",
                                                                    "score", "direction"]
        st.dataframe(flagged[[c for c in cols if c in flagged]], hide_index=True, width="stretch",
                     column_config={"period": st.column_config.DateColumn("Period start"),
                                    "expected": st.column_config.NumberColumn("Recent average", format="%.1f"),
                                    "deviation": st.column_config.NumberColumn("Deviation", format="%+.1f"),
                                    "high_share": st.column_config.NumberColumn("High-severity share", format="%.2f"),
                                    "score": st.column_config.NumberColumn("Score", format="%.3f")})
        st.caption("A flagged period only means its aggregate pattern differed from most other periods. It is not "
                   "evidence of suspicious activity by any person.")
        if st.button("Save this anomaly run", icon=":material/save:"):
            with transaction() as conn:
                aid = models.save_analysis(conn, analysis_type="isolation_forest", upload_id=upload["upload_id"],
                                           user_id=user.get("user_id"), parameters=res.params,
                                           filters={"description": describe_filters(filters)},
                                           result_summary={"flagged": res.n_anomalies, "periods": len(res.table)})
            st.success(f"Saved as analysis #{aid}.")

with tabs[3]:
    months = ca.complete_months(df)
    t = ca.trend_summary(months["incidents"]) if len(months) else {"trend": "insufficient data"}
    if t.get("n", 0) >= 4:
        c1, c2, c3, c4 = st.columns(4)
        kpi_card(c1, "Observed trend", t["trend"].capitalize())
        kpi_card(c2, "Slope", f"{t['slope_per_period']:+.2f} / month", f"{t['slope_pct_of_mean']:+.2f}% of the monthly mean")
        kpi_card(c3, "Mann-Kendall p-value", f"{t['mk_p_value']:.3f}")
        kpi_card(c4, "Linear fit R²", f"{t['r_squared']:.3f}")
        st.plotly_chart(viz.line_chart(months, "month", "incidents", "Complete months used for the trend test",
                                       "Month", "Incidents", source=src), width="stretch")
    st.info("These are **observed historical trends**. The app does not forecast future crime: no forecasting "
            "model has been validated on this data.", icon=":material/info:")
    st.markdown("**Trend per crime category**")
    st.dataframe(ca.category_trends(df, 30), hide_index=True, width="stretch")
    if "location" in df:
        rows = []
        for loc in ca.counts_by(df, "location", 15)["location"]:
            s = ca.monthly_counts(df[df["location"] == loc]).set_index("month")["incidents"].reindex(months["month"], fill_value=0)
            r = ca.trend_summary(s)
            rows.append({"location": loc, "mean_per_month": s.mean(), "slope_per_month": r.get("slope_per_period"),
                         "mk_p_value": r.get("mk_p_value"), "trend": r.get("trend")})
        st.markdown("**Trend per location (top 15)**")
        st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch")

with tabs[4]:
    corr = ca.correlation_matrix(df)
    st.plotly_chart(viz.correlation_heatmap(corr, "Spearman correlation between numeric attributes", source=src),
                    width="stretch")
    st.markdown("**Strongest pairs**")
    st.dataframe(ca.strongest_correlations(corr), hide_index=True)
    st.caption("Spearman's rho ranges from -1 to 1; |rho| < 0.1 is negligible. Correlation does not imply causation.")

with tabs[5]:
    if df.empty:
        st.info("No data.")
    else:
        lo, hi = df["occurred_at"].min().date(), df["occurred_at"].max().date()
        mid = lo + (hi - lo) / 2
        c1, c2, c3 = st.columns(3)
        a = c1.date_input("Period A", (lo, mid), min_value=lo, max_value=hi, key="cmp_a")
        b = c2.date_input("Period B", (mid, hi), min_value=lo, max_value=hi, key="cmp_b")
        by = c3.selectbox("Compare by", [c for c in ("crime_type", "location", "severity", "time_period") if c in df],
                          format_func=lambda c: c.replace("_", " ").title(), key="cmp_by")
        if len(a) == 2 and len(b) == 2:
            table, test = ca.compare_periods(df, a, b, by)
            k1, k2, k3 = st.columns(3)
            kpi_card(k1, "Period A per day", f"{test['per_day_a']:.1f}" if test["per_day_a"] else "-", f"{test['total_a']:,} incidents")
            kpi_card(k2, "Period B per day", f"{test['per_day_b']:.1f}" if test["per_day_b"] else "-", f"{test['total_b']:,} incidents")
            kpi_card(k3, "Chi-square p-value", f"{test['p_value']:.3f}" if "p_value" in test else "-",
                     "Tests whether the mix across categories differs between periods")
            long = table.melt(id_vars=by, value_vars=["period_a", "period_b"], var_name="period", value_name="incidents")
            long["period"] = long["period"].map({"period_a": "Period A", "period_b": "Period B"})
            import plotly.express as px
            fig = px.bar(long, x=by, y="incidents", color="period", barmode="group",
                         color_discrete_map={"Period A": viz.CATEGORICAL[0], "Period B": viz.CATEGORICAL[1]})
            fig = viz._base_layout(fig, "Incidents in period A vs period B", by.replace("_", " ").title(), "Incidents",
                                   source=src, height=420)
            st.plotly_chart(fig, width="stretch")
            st.dataframe(table, hide_index=True, width="stretch",
                         column_config={"change_pct": st.column_config.NumberColumn("Change %", format="%+.1f%%")})
            st.caption("Periods of different lengths: compare the per-day figures, not the raw totals.")

with tabs[6]:
    with get_connection() as conn:
        hist = models.list_analysis_history(conn)
    if hist.empty:
        st.info("No saved analyses yet. Use the save buttons on the Hotspots and Isolation Forest views.")
    else:
        st.dataframe(hist, hide_index=True, width="stretch")
