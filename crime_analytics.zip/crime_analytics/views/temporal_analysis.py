"""Page 3 - Temporal analysis."""
from __future__ import annotations

import streamlit as st

from modules import crime_analysis as ca
from modules import visualization as viz
from modules.app_state import filter_status, incident_context, kpi_card, page_header, provenance_banner, source_text

page_header("Temporal Analysis", "When incidents happen: hour, weekday, month, year and longer-term patterns.")
upload, full, df, filters = incident_context()
if upload is None:
    st.stop()
provenance_banner(upload)
filter_status(full, df)
src = source_text(upload)

peaks = ca.peak_periods(df)
c1, c2, c3, c4 = st.columns(4)
kpi_card(c1, "Peak hour", f"{peaks['peak_hour']:02d}:00" if "peak_hour" in peaks else "n/a",
         f"{peaks['peak_hour_share_pct']:.1f}% of incidents" if "peak_hour" in peaks else "No time of day in data")
kpi_card(c2, "Peak weekday", peaks.get("peak_weekday", "-"))
kpi_card(c3, "Peak month", peaks.get("peak_month", "-"))
kpi_card(c4, "Busiest single day", peaks.get("busiest_day", "-"),
         f"{peaks['busiest_day_count']} incidents" if peaks else None)

left, right = st.columns(2)
with left:
    st.plotly_chart(viz.bar_chart(ca.hour_counts(df), "hour", "incidents", "Incidents by hour of day",
                                  "Hour of day (0-23)", "Incidents", source=src), width="stretch")
with right:
    st.plotly_chart(viz.bar_chart(ca.weekday_counts(df), "weekday", "incidents", "Incidents by day of week",
                                  "Day of week", "Incidents", source=src), width="stretch")

st.plotly_chart(viz.heatmap(ca.weekday_hour_matrix(df), "Crime by weekday and hour", "Hour of day",
                            "Day of week", source=src, height=380), width="stretch")

left, right = st.columns(2)
with left:
    moy = ca.month_of_year_counts(df)
    st.plotly_chart(viz.bar_chart(moy.dropna(subset=["avg_incidents"]), "month_name", "avg_incidents",
                                  "Average incidents per calendar month", "Month", "Average incidents per month",
                                  source=src), width="stretch")
with right:
    cov = ca.coverage_by_year(df)
    st.plotly_chart(viz.bar_chart(cov.assign(year=cov["year"].astype(str)), "year", "per_month",
                                  "Yearly trend: average incidents per month", "Year", "Incidents per month",
                                  source=src), width="stretch")
    if not cov.empty and (cov["months_covered"] < 12).any():
        partial = ", ".join(f"{int(r.year)} ({int(r.months_covered)} months)" for r in cov.itertuples() if r.months_covered < 12)
        st.caption(f"Partial years: {partial}. Shown as a monthly average so partial years compare fairly.")

left, right = st.columns(2)
with left:
    ww = ca.weekend_vs_weekday(df)
    st.plotly_chart(viz.bar_chart(ww, "day_type", "avg_per_day", "Weekend vs weekday: average incidents per day",
                                  "Day type", "Average incidents per day", source=src, text_fmt="%{y:.1f}"),
                    width="stretch")
    if "welch_t_p" in ww.attrs:
        st.caption(f"Welch t-test on daily counts: p = {ww.attrs['welch_t_p']:.3f} "
                   f"({'significant' if ww.attrs['welch_t_p'] < 0.05 else 'not significant'} at 5%).")
with right:
    st.plotly_chart(viz.donut_chart(ca.counts_by(df, "time_period"), "time_period", "incidents",
                                    "Incidents by time of day", source=src), width="stretch")
    st.caption("Night 00-05, Morning 06-11, Afternoon 12-17, Evening 18-23.")

st.subheader("Time series")
freq = st.segmented_control("Resolution", ["Daily", "Weekly", "Monthly"], default="Weekly", key="ts_freq")
rule = {"Daily": "D", "Weekly": "W-SUN", "Monthly": "MS"}[freq or "Weekly"]
if not df.empty:
    ts = ca.resample_complete(df, rule).rename("Incidents").to_frame()
    ts.index.name = "occurred_at"
    window = {"D": 30, "W-SUN": 8, "MS": 3}[rule]
    ts[f"{window}-period rolling average"] = ts["Incidents"].rolling(window, min_periods=1).mean()
    long = ts.reset_index().melt(id_vars="occurred_at", var_name="series", value_name="value")
    fig = viz.line_chart(long, "occurred_at", "value", f"{freq} incidents with rolling average",
                         "Date", "Incidents", group="series", source=src)
else:
    fig = viz.empty_figure("Time series")
st.plotly_chart(fig, width="stretch")

st.subheader("Year-over-year comparison")
m = ca.monthly_counts(df)
if not m.empty:
    m["year"] = m["month"].dt.year.astype(str)
    m["month_name"] = m["month"].dt.strftime("%b")
    m["month_num"] = m["month"].dt.month
    m = m.sort_values("month_num")
    fig = viz.line_chart(m, "month_name", "incidents", "Monthly incidents by year", "Month", "Incidents",
                         group="year", source=src)
    st.plotly_chart(fig, width="stretch")
