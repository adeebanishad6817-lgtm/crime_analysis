"""Entry point: `streamlit run app.py`.

Every page lives in views/ and is registered with st.navigation, so no page
can be opened without passing the login check below.
"""
from __future__ import annotations

import streamlit as st

import config
from database.connection import check_connection
from modules import authentication as auth

st.set_page_config(page_title=config.APP_TITLE, page_icon=":material/map:", layout="wide")
css = config.ASSETS_DIR / "styles.css"
if css.exists():
    st.markdown(f"<style>{css.read_text()}</style>", unsafe_allow_html=True)

ok, message = check_connection()
if not ok:
    st.error(f"{message}\n\nStart PostgreSQL and check `DATABASE_URL` in `.env`, then run "
             f"`python scripts/init_db.py`.", icon=":material/database:")
    st.stop()

user = auth.current_user()
if user is None:
    _, mid, _ = st.columns([1, 1.2, 1])
    with mid:
        auth.login_form()
    st.stop()

with st.sidebar:
    st.markdown(f"**{config.APP_TITLE}**")
    st.caption(f"Signed in as **{user['username']}** ({user['role']})")
    if st.button("Log out", icon=":material/logout:", width="stretch"):
        auth.logout("You have been logged out.")
        st.rerun()

pages = {
    "Dashboards": [
        st.Page("views/overview.py", title="Overview", icon=":material/dashboard:", default=True),
        st.Page("views/hotspot_analysis.py", title="Geographic Hotspots", icon=":material/location_on:"),
        st.Page("views/temporal_analysis.py", title="Temporal Analysis", icon=":material/schedule:"),
        st.Page("views/category_analysis.py", title="Crime Categories", icon=":material/category:"),
        st.Page("views/advanced_analytics.py", title="Advanced Analytics", icon=":material/insights:"),
    ],
    "Official statistics": [
        st.Page("views/karnataka_statistics.py", title="Karnataka Crime Review", icon=":material/table_chart:"),
    ],
    "Output": [
        st.Page("views/reports.py", title="Reports & Exports", icon=":material/description:"),
    ],
}
if user["role"] == "admin":
    pages["Administration"] = [
        st.Page("views/data_management.py", title="Data Management", icon=":material/upload_file:"),
    ]

st.navigation(pages).run()
